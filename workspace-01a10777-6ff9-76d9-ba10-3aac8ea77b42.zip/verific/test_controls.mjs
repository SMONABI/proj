// ═══ آزمون جهت کنترل‌ها ═══
// تعریف درست: W باید بازیکن را «دور از دوربین» ببرد (هم‌جهت نگاه دوربین)،
// D باید او را به «راستِ صفحه» ببرد.
import puppeteer from 'puppeteer'

const SPOT = { x: 330, z: 40 }
const YAW = 0.7          // زاویه‌ی غیرهم‌محور تا آزمون واقعی باشد
const HOLD = 1400        // میلی‌ثانیه

let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
// پنجره‌ی کوچک + کمترین کیفیت گرافیکی: رندر نرم‌افزاری این محیط کند است و
// با فریم‌های کم، dt روی 1/20 سقف می‌خورد و جابه‌جاییِ اندازه‌گیری‌شده ناچیز می‌شود.
await page.setViewport({ width: 360, height: 240 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await sleep(6000)

// شروع بازی
await page.evaluate(() => {
  const b = [...document.querySelectorAll('button')].find((x) => /آغاز ماجراجویی/.test(x.textContent || ''))
  b?.click()
})
await sleep(3500)

// کیفیت گرافیکی را به پایین‌ترین درجه ببر و نرخ فریم را بسنج
const perf = await page.evaluate(async () => {
  const g = window.__eldoria
  g.engine.quality = 2
  g.engine.applyQuality()
  g.engine.resize()
  let frames = 0
  const t0 = performance.now()
  await new Promise((res) => {
    const tick = () => { frames++; performance.now() - t0 < 1000 ? requestAnimationFrame(tick) : res() }
    requestAnimationFrame(tick)
  })
  return { fps: frames, quality: g.engine.quality }
})
console.log(`نرخ فریم محیط آزمون: ~${perf.fps} fps (کیفیت ${perf.quality})`)

const ready = await page.evaluate(() => !!window.__eldoria?.player && !!window.__eldoriaTouch)
if (!ready) { console.log('❌ بازی یا قلاب دیباگ آماده نشد'); await browser.close(); process.exit(1) }

/** یک اندازه‌گیری: صحنه را تمیز می‌کند، ورودی می‌دهد، جابه‌جایی را برمی‌گرداند */
async function measure({ label, keys = [], touch: tv = null }) {
  await page.evaluate(({ spot, yaw }) => {
    const g = window.__eldoria
    g.enemies.enemies.forEach((e) => { e.dead = true })   // اندازه‌گیری تمیز
    g.player.teleport(spot.x, spot.z)
    g.player.vel.set(0, 0, 0)
    g.player.camYaw = yaw
    g.player.state = 'idle'
    const t = window.__eldoriaTouch
    t.mx = 0; t.mz = 0; t.sprint = false
  }, { spot: SPOT, yaw: YAW })

  if (tv) await page.evaluate((t) => { Object.assign(window.__eldoriaTouch, t) }, tv)
  await sleep(180)

  const before = await page.evaluate(() => {
    const p = window.__eldoria.player
    return { x: p.pos.x, z: p.pos.z, y: p.pos.y }
  })
  for (const k of keys) await page.keyboard.down(k)
  await sleep(HOLD)
  // جهت سرعت هنگام نگه‌داشتن کلید — در فریم‌های کم هم دقیق است
  const vel = await page.evaluate(() => {
    const p = window.__eldoria.player
    return { x: p.vel.x, z: p.vel.z }
  })
  for (const k of keys) await page.keyboard.up(k)
  const after = await page.evaluate(() => {
    const p = window.__eldoria.player
    return { x: p.pos.x, z: p.pos.z, y: p.pos.y, camYaw: p.camYaw }
  })
  await page.evaluate(() => { const t = window.__eldoriaTouch; t.mx = 0; t.mz = 0 })
  await sleep(120)

  const dx = after.x - before.x, dz = after.z - before.z
  const dist = Math.hypot(dx, dz)
  const speed = Math.hypot(vel.x, vel.z)
  return { label, dx, dz, dist, velX: vel.x, velZ: vel.z, speed, before, after }
}

/** جهت‌های مرجع بر پایه‌ی زاویه‌ی دوربین */
const F = { x: Math.sin(YAW), z: Math.cos(YAW) }        // جلو = جهت نگاه دوربین روی زمین
const R = { x: -Math.cos(YAW), z: Math.sin(YAW) }       // راستِ صفحه

const along = (m, d) => m.dist < 0.05 ? 0 : (m.dx * d.x + m.dz * d.z) / m.dist   // از -۱ تا +۱

console.log(`\nمرجع: جلو = (${F.x.toFixed(2)}, ${F.z.toFixed(2)}) · راست = (${R.x.toFixed(2)}, ${R.z.toFixed(2)}) · camYaw = ${YAW}`)
console.log('یک مقدار مثبت یعنی همان جهت، منفی یعنی کاملاً برعکس.\n')

const cases = [
  { label: 'W (جلو)',           keys: ['w'], exp: F,  name: 'جلو' },
  { label: 'S (عقب)',           keys: ['s'], exp: { x: -F.x, z: -F.z }, name: 'عقب' },
  { label: 'D (راست)',          keys: ['d'], exp: R,  name: 'راست صفحه' },
  { label: 'A (چپ)',            keys: ['a'], exp: { x: -R.x, z: -R.z }, name: 'چپ صفحه' },
  { label: 'جوی‌استیک به بالا', touch: { mz: -1 }, exp: F, name: 'جلو' },
  { label: 'جوی‌استیک به راست', touch: { mx: 1 },  exp: R, name: 'راست صفحه' },
  { label: 'جوی‌استیک به پایین', touch: { mz: 1 }, exp: { x: -F.x, z: -F.z }, name: 'عقب' },
]

const results = []
for (const c of cases) {
  const m = await measure(c)
  // هم‌جهتی سرعت = سیگنال اصلی؛ هم‌جهتی جابه‌جایی = شاهد
  const dotV = m.speed < 0.05 ? 0 : (m.velX * c.exp.x + m.velZ * c.exp.z) / m.speed
  const dotP = along(m, c.exp)
  results.push({ ...c, ...m, dot: dotV, dotP })
  const verdict = dotV > 0.7 ? 'درست' : dotV < -0.7 ? '🔁 برعکس' : '؟؟؟ نامشخص'
  console.log(`${c.label.padEnd(22)} سرعت ${m.speed.toFixed(2)} واحد/ث  ·  هم‌جهتی سرعت با «${c.name}»: ${dotV >= 0 ? '+' : ''}${dotV.toFixed(2)}  ·  جابه‌جایی ${m.dist.toFixed(2)}  →  ${verdict}`)
}

console.log('')
for (const c of results) {
  const ok = c.dot > 0.7
  check(`${c.label} → ${c.name}`, ok,
    ok ? `سرعت ${c.speed.toFixed(1)} واحد/ث، جابه‌جایی ${c.dist.toFixed(1)} واحد`
       : `هم‌جهتی سرعت ${c.dot.toFixed(2)} (${c.dot < -0.7 ? '🔁 برعکس' : 'نامشخص'})`)
}

await browser.close()
console.log(`\n${'─'.repeat(60)}\nنتیجه: ${pass} درست، ${fail} خراب`)
process.exit(fail ? 1 : 0)
