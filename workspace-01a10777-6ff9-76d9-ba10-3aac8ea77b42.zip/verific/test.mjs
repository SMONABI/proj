import puppeteer from 'puppeteer'

const URL = 'http://127.0.0.1:3000/'
let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=swiftshader',
         '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})

async function run(label, { blockStorage }) {
  console.log(`\n${'═'.repeat(60)}\n${label}\n${'═'.repeat(60)}`)
  const page = await browser.newPage()
  await page.setViewport({ width: 1280, height: 800 })

  const errors = []
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message))
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()) })

  if (blockStorage) {
    // دقیقاً شرایط iframe سندباکس‌شده: دسترسی به localStorage استثنا پرتاب می‌کند
    await page.evaluateOnNewDocument(() => {
      Object.defineProperty(window, 'localStorage', {
        configurable: true,
        get() { throw new DOMException('Access is denied for this document.', 'SecurityError') },
      })
    })
  }

  await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 60000 })
  await new Promise((r) => setTimeout(r, 6000))

  // آیا چیزی رندر شده یا صفحه سفید است؟
  const info = await page.evaluate(() => {
    const root = document.getElementById('root')
    const canvas = document.querySelector('canvas')
    // پیکسل‌ها را از بوم واقعی می‌خوانیم تا مطمئن شویم چیزی کشیده شده
    let painted = false, pixel = null
    try {
      const gl = canvas?.getContext('webgl2') || canvas?.getContext('webgl')
      if (gl) {
        const px = new Uint8Array(4)
        gl.readPixels(Math.floor(gl.drawingBufferWidth / 2), Math.floor(gl.drawingBufferHeight / 2),
                      1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px)
        pixel = [px[0], px[1], px[2]]
        painted = px[0] + px[1] + px[2] > 0
      }
    } catch { /* نادیده */ }
    return {
      rootChildren: root ? root.children.length : -1,
      rootText: (root?.textContent ?? '').trim().slice(0, 120),
      hasCanvas: !!canvas,
      canvasSize: canvas ? `${canvas.width}x${canvas.height}` : null,
      painted, pixel,
      bodyText: (document.body.innerText || '').trim().split('\n').filter(Boolean).slice(0, 8),
      errorScreenVisible: !!document.body.innerText.match(/خطا|مشکل|مرورگر از گرافیک/),
    }
  })

  console.log('محتوای ریشه:      ', info.rootChildren, 'فرزند')
  console.log('بوم سه‌بعدی:      ', info.hasCanvas ? info.canvasSize : '—')
  console.log('پیکسل وسط بوم:   ', info.pixel ? `rgb(${info.pixel.join(',')})` : 'خوانده نشد')
  console.log('متن روی صفحه:    ', info.bodyText.length ? JSON.stringify(info.bodyText) : '«خالی»')
  console.log('وضعیت فارسی:      ', info.rootText || '—')
  if (errors.length) { console.log('خطاهای ضبط‌شده:'); errors.slice(0, 6).forEach((e) => console.log('   ', e.slice(0, 180))) }

  const isWhite = info.rootChildren === 0 || (info.bodyText.length === 0 && !info.painted)
  check('صفحه سفید نیست', !isWhite, isWhite ? 'صفحه خالی است!' : '')
  check('صفحه‌ی عنوان بازی رندر شد', info.bodyText.some((t) => /الدوریا|ماجراجویی|جنگجو/.test(t)),
        info.bodyText[0] ?? '')
  check('بوم سه‌بعدی چیزی کشیده', info.painted, info.pixel ? `rgb(${info.pixel.join(',')})` : '')

  await page.close()
  return errors
}

const e1 = await run('۱) حالت عادی (localStorage سالم)', { blockStorage: false })
const e2 = await run('۲) شبیه‌سازی سندباکس (localStorage مسدود)', { blockStorage: true })

await browser.close()
console.log(`\n${'─'.repeat(60)}\nنتیجه: ${pass} تست موفق، ${fail} ناموفق`)
process.exit(fail ? 1 : 0)
