import puppeteer from 'puppeteer'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
const page = await browser.newPage()
await page.setViewport({ width: 360, height: 240 })
const errs = []
page.on('pageerror', (e) => errs.push('pageerror: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 150)) })

await page.evaluateOnNewDocument(() => {
  const state = { axes: [0,0,0,0], buttons: Array.from({length:17},()=>({pressed:false,value:0})),
    id: 'Xbox Wireless Controller (STANDARD GAMEPAD Vendor: 045e Product: 02fd)', mapping: 'standard', connected: true }
  const padObj = { get axes(){return state.axes}, get buttons(){return state.buttons}, get id(){return state.id},
    get index(){return 0}, get mapping(){return state.mapping}, get connected(){return state.connected},
    get vibrationActuator(){ return { playEffect: () => Promise.resolve('complete') } } }
  Object.defineProperty(navigator, 'getGamepads', { configurable: true, value: () => [padObj] })
  window.__pad = { press:(i)=>{state.buttons[i].pressed=true;state.buttons[i].value=1},
                   release:(i)=>{state.buttons[i].pressed=false;state.buttons[i].value=0} }
})
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await sleep(6000)

const snap = async (label) => {
  const d = await page.evaluate(() => {
    const p = window.__eldoriaPad
    const s = window.__eldoriaStore.getState()
    const g = window.__eldoria
    return {
      connected: p.connected, kind: p.kind,
      buttons: p.buttons.map((b,i)=>b?i:null).filter(x=>x!==null),
      maps: p.map,
      heldDRight: p.held('dright'),
      heldDLeft: p.held('dleft'),
      justA: p.just('a'),
      phase: s.phase, titleClass: s.titleClass, inputMode: s.inputMode, padConnected: s.padConnected,
      padNavT: g.padNavT,
    }
  })
  console.log(`${label}:`, JSON.stringify(d))
  return d
}

await snap('وضعیت اولیه')
await page.evaluate(() => window.__pad.press(15))
await sleep(600)
await snap('بعد از فشردن D-pad راست')
await sleep(600)
await snap('۶۰۰ms بعد')
await page.evaluate(() => window.__pad.release(15))
await sleep(500)
await snap('بعد از رها کردن')

console.log('\nخطاها:', errs.length ? errs.slice(0,5) : 'هیچ')
await browser.close()
