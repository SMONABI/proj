// اسکرین‌شات با دسته‌ی متصل، برای دیدن برچسب دکمه‌ها روی نوار مهارت
import puppeteer from 'puppeteer'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
const page = await browser.newPage()
await page.setViewport({ width: 1000, height: 640 })
await page.evaluateOnNewDocument(() => {
  const state = { axes:[0,0,0,0], buttons: Array.from({length:17},()=>({pressed:false,value:0})),
    id: 'DualSense Wireless Controller', mapping: 'standard', connected: true }
  const padObj = { get axes(){return state.axes}, get buttons(){return state.buttons}, get id(){return state.id},
    get index(){return 0}, get mapping(){return state.mapping}, get connected(){return state.connected},
    get vibrationActuator(){ return { playEffect: () => Promise.resolve('complete') } } }
  Object.defineProperty(navigator, 'getGamepads', { configurable: true, value: () => [padObj] })
  window.__pad = { press:(i)=>{state.buttons[i].pressed=true;state.buttons[i].value=1},
                   release:(i)=>{state.buttons[i].pressed=false;state.buttons[i].value=0},
                   axes:(a)=>{state.axes=a} }
})
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await sleep(6500)

// تیتراژ با دسته‌ی متصل (راهنمای دسته باید دیده شود)
await page.evaluate(() => { window.__pad.press(15); window.__pad.axes([0,-1,0,0]) })
await sleep(900)
await page.evaluate(() => { window.__pad.release(15) })
await sleep(1200)
await page.screenshot({ path: '/tmp/pad_title.png' })
console.log('✓ اسکرین‌شات تیتراژ')

// شروع بازی با A و نگه‌داشتن استیک برای دویدن
await page.evaluate(() => { window.__pad.press(0) })
await sleep(1200)
await page.evaluate(() => { window.__pad.release(0) })
await sleep(3000)
await page.evaluate(() => { const g = window.__eldoria; g.engine.quality = 1; g.engine.applyQuality(); g.engine.resize() })
await page.evaluate(() => window.__pad.axes([0.6, -0.8, 0, 0]))
await sleep(2500)
await page.screenshot({ path: '/tmp/pad_play.png' })
const st = await page.evaluate(() => ({ mode: window.__eldoriaStore.getState().inputMode, kind: window.__eldoriaStore.getState().padKind, phase: window.__eldoriaStore.getState().phase }))
console.log('✓ اسکرین‌شات بازی —', JSON.stringify(st))
await browser.close()
