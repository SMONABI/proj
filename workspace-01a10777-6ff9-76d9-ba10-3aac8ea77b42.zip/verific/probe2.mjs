import puppeteer from 'puppeteer'
import fs from 'node:fs'

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
await page.setViewport({ width: 1400, height: 500 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await new Promise((r) => setTimeout(r, 5000))

// سه کار: ۱) خود بافت واقعیِ اسپرایت «میدان شهر» را بزرگ بکش
//          ۲) یک بافت تازه با همان کد بساز تا مقایسه شود
//          ۳) جهت متن را در canvas بررسی کن
const res = await page.evaluate(() => {
  const g = window.__eldoria
  let target = null
  g.engine.scene.traverse((o) => {
    if (o.isSprite && o.material?.map?.image?.width) {
      const p = o.getWorldPosition(new (o.position.constructor)())
      if (Math.abs(p.x) < 0.01 && Math.abs(p.z) < 0.01) target = o
    }
  })
  if (!target) return { error: 'اسپرایت پیدا نشد' }
  const src = target.material.map.image   // همان canvas اصلی

  document.body.innerHTML = ''
  document.body.style.cssText = 'background:#222;margin:0;padding:14px;font:13px monospace;color:#fff'
  const info = document.createElement('div')
  info.textContent = `بافت واقعی اسپرایت — اندازه‌ی کانواس: ${src.width}×${src.height}`
  info.style.cssText = 'margin-bottom:8px;color:#8f8'
  document.body.appendChild(info)

  // بازکشی بزرگ‌شده‌ی بافت واقعی
  const big = document.createElement('canvas')
  big.width = src.width * 3; big.height = src.height * 3
  const bc = big.getContext('2d')
  bc.imageSmoothingEnabled = false
  bc.drawImage(src, 0, 0, big.width, big.height)
  big.style.cssText = 'border:2px solid #f80;display:block;margin-bottom:16px'
  document.body.appendChild(big)

  // آزمایش جهت متن در canvas داخل سند RTL
  const t = document.createElement('canvas')
  t.width = 420; t.height = 70
  const tc = t.getContext('2d')
  tc.fillStyle = '#111'; tc.fillRect(0, 0, 420, 70)
  tc.fillStyle = '#fff'; tc.textAlign = 'left'; tc.textBaseline = 'middle'
  tc.font = '700 30px sans-serif'
  tc.fillText('میدان شهر ABC', 10, 35)
  const lbl = document.createElement('div')
  lbl.textContent = 'آزمایش مستقیم: fillText با textAlign=left (متن باید از چپ شروع شود)'
  lbl.style.cssText = 'margin:6px 0;color:#8cf'
  document.body.appendChild(lbl)
  t.style.cssText = 'border:2px solid #08f;display:block;margin-bottom:12px'
  document.body.appendChild(t)

  return {
    srcW: src.width, srcH: src.height,
    dirHint: getComputedStyle(document.documentElement).direction,
    ctxDir: (() => { const c = document.createElement('canvas').getContext('2d'); return c.direction })(),
  }
})
console.log('اندازه‌ی بافت واقعی:', res.srcW, '×', res.srcH)
console.log('direction سند:', res.dirHint, '| direction پیش‌فرض کانتکست:', res.ctxDir)
await page.screenshot({ path: '/tmp/texture.png', fullPage: true })
console.log('اسکرین‌شات بافت در /tmp/texture.png')
await browser.close()
