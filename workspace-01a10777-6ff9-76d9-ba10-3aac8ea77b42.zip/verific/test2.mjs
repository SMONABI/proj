import puppeteer from 'puppeteer'
import { PNG } from 'pngjs'
import fs from 'node:fs'

const URL = 'http://127.0.0.1:3000/'
let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }

// تحلیل اسکرین‌شات واقعی: آیا بوم فقط سیاه است یا صحنه‌ی سه‌بعدی کشیده شده؟
function analyze(file) {
  const png = PNG.sync.read(fs.readFileSync(file))
  let nonBlack = 0, colorful = 0, sum = [0, 0, 0]
  const colors = new Set()
  for (let i = 0; i < png.data.length; i += 4) {
    const [r, g, b] = [png.data[i], png.data[i + 1], png.data[i + 2]]
    if (r + g + b > 24) nonBlack++
    if (Math.max(r, g, b) - Math.min(r, g, b) > 18) colorful++
    sum[0] += r; sum[1] += g; sum[2] += b
    if (colors.size < 5000) colors.add((r >> 3) << 10 | (g >> 3) << 5 | (b >> 3))
  }
  const n = png.data.length / 4
  return {
    w: png.width, h: png.height,
    nonBlackPct: (nonBlack / n * 100),
    colorfulPct: (colorful / n * 100),
    distinctColors: colors.size,
    avg: sum.map((s) => Math.round(s / n)),
  }
}

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})

async function run(label, opts) {
  console.log(`\n${'═'.repeat(64)}\n${label}\n${'═'.repeat(64)}`)
  const page = await browser.newPage()
  await page.setViewport({ width: 1000, height: 640 })

  const errors = []
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message))
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 150)) })

  if (opts.blockStorage) {
    await page.evaluateOnNewDocument(() => {
      Object.defineProperty(window, 'localStorage', {
        configurable: true, get() { throw new DOMException('denied', 'SecurityError') },
      })
    })
  }

  await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 60000 })
  await new Promise((r) => setTimeout(r, 7000))

  // ── ۱) وضعیت WebGL در این محیط ──
  const gl = await page.evaluate(() => {
    try {
      const c = document.createElement('canvas')
      const g = c.getContext('webgl2') || c.getContext('webgl')
      if (!g) return { ok: false, reason: 'بدون کانتکست' }
      const d = g.getExtension('WEBGL_debug_renderer_info')
      return { ok: true, renderer: d ? g.getParameter(d.UNMASKED_RENDERER_WEBGL) : g.getParameter(g.RENDERER) }
    } catch (e) { return { ok: false, reason: String(e) } }
  })
  console.log('WebGL:', gl.ok ? `در دسترس — ${gl.renderer}` : `❌ ${gl.reason}`)

  const titleState = await page.evaluate(() => ({
    text: (document.body.innerText || '').trim().split('\n').filter(Boolean).slice(0, 4),
    isErrorScreen: /خطای غیرمنتظره|پشتیبانی نمی‌کند|بارگذاری نشد/.test(document.body.innerText || ''),
  }))
  console.log('متن روی صفحه:', JSON.stringify(titleState.text))

  await page.screenshot({ path: '/tmp/title.png' })
  const a1 = analyze('/tmp/title.png')
  console.log(`اسکرین‌شات تیتراژ → ${a1.nonBlackPct.toFixed(1)}% پیکسل روشن، ${a1.colorfulPct.toFixed(1)}% رنگی، ${a1.distinctColors} رنگ متمایز، میانگین rgb(${a1.avg.join(',')})`)

  check('صفحه سفید نیست', titleState.text.length > 0 && !titleState.isErrorScreen, titleState.text[0] ?? '')
  check('خطای وب‌سوکت HMR برطرف شد', !errors.some((e) => /websocket/i.test(e)),
        errors.filter((e) => /websocket/i.test(e)).length + ' خطای وب‌سوکت')
  check('صحنه‌ی سه‌بعدی پشت تیتراژ رندر می‌شود', a1.nonBlackPct > 40 && a1.distinctColors > 300,
        `${a1.nonBlackPct.toFixed(1)}% روشن / ${a1.distinctColors} رنگ`)

  // ── ۲) شروع بازی: کلیک روی «آغاز ماجراجویی» ──
  const clicked = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /آغاز ماجراجویی/.test(x.textContent || ''))
    if (!b) return false
    b.click(); return true
  })
  check('دکمه‌ی «آغاز ماجراجویی» پیدا و کلیک شد', clicked)

  if (clicked) {
    await new Promise((r) => setTimeout(r, 8000))
    await page.screenshot({ path: '/tmp/play.png' })
    const a2 = analyze('/tmp/play.png')
    const playState = await page.evaluate(() => ({
      text: (document.body.innerText || '').trim().split('\n').filter(Boolean).slice(0, 6),
      isErrorScreen: /خطای غیرمنتظره|پشتیبانی نمی‌کند|بارگذاری نشد|افتادی/.test(document.body.innerText || ''),
    }))
    console.log(`اسکرین‌شات بازی → ${a2.nonBlackPct.toFixed(1)}% پیکسل روشن، ${a2.colorfulPct.toFixed(1)}% رنگی، ${a2.distinctColors} رنگ متمایز`)
    console.log('متن HUD:', JSON.stringify(playState.text))
    check('بازی شروع شد و HUD نمایش داده می‌شود', /الدوریا|طلا|همراه/.test(playState.text.join(' ')), playState.text.slice(0, 3).join(' | '))
    check('صحنه‌ی بازی زنده رندر می‌شود', a2.nonBlackPct > 40 && a2.distinctColors > 300,
          `${a2.nonBlackPct.toFixed(1)}% روشن / ${a2.distinctColors} رنگ`)
    check('حین بازی خطای مهلک رخ نداد', !playState.isErrorScreen)
  }

  if (errors.length) { console.log('\nخطاهای ضبط‌شده:'); errors.slice(0, 5).forEach((e) => console.log('   ', e)) }
  await page.close()
}

await run('۱) حالت عادی', { blockStorage: false })
await run('۲) شبیه‌سازی iframe سندباکس‌شده (localStorage مسدود)', { blockStorage: true })

await browser.close()
console.log(`\n${'─'.repeat(64)}\nنتیجه: ${pass} موفق، ${fail} ناموفق`)
process.exit(fail ? 1 : 0)
