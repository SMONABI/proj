import puppeteer from 'puppeteer'
import fs from 'node:fs'

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
await page.setViewport({ width: 1000, height: 640 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await new Promise((r) => setTimeout(r, 6000))

// متن ABC را روی بافت یک اسپرایت واقعیِ داخل صحنه می‌نویسیم و بزرگش می‌کنیم.
// چون اسپرایت همیشه رو به دوربین است، تصویر نتیجه باید دقیقاً همان بافت باشد.
const info = await page.evaluate(() => {
  const g = window.__eldoria
  const found = []
  g.engine.scene.traverse((o) => {
    if (!o.isSprite || !o.material?.map?.image) return
    const p = o.getWorldPosition(new (o.position.constructor)())
    if (Math.abs(p.x) > 0.01 || Math.abs(p.z) > 0.01) return
    found.push(o)
  })
  if (!found.length) return { error: 'برچسبی در مرکز پیدا نشد' }
  const spr = found[0]
  const cv = spr.material.map.image
  const c = cv.getContext('2d')
  c.setTransform(1, 0, 0, 1, 0, 0)
  c.fillStyle = '#000'
  c.fillRect(0, 0, cv.width, cv.height)
  c.fillStyle = '#0f0'
  c.font = '700 30px monospace'
  c.textAlign = 'left'
  c.textBaseline = 'middle'
  c.fillText('ABC', 16, 32)        // حروف لاتین: هرگز نباید CBA دیده شود
  spr.material.map.needsUpdate = true
  // بزرگ و رو‌به‌دوربین: در ارتفاع مرکز مدار دوربین تیتراژ
  spr.scale.set(16, 5, 1)
  spr.position.set(0, 9, 0)
  return { srcW: cv.width, srcH: cv.height, scale: [spr.scale.x, spr.scale.y] }
})
console.log('وضعیت اسپرایت:', JSON.stringify(info))
await new Promise((r) => setTimeout(r, 1200))
await page.screenshot({ path: '/tmp/live_label.png' })
await browser.close()
