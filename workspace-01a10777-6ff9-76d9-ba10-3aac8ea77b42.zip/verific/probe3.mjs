import puppeteer from 'puppeteer'
import { PNG } from 'pngjs'
import fs from 'node:fs'

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
await page.setViewport({ width: 900, height: 620 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await new Promise((r) => setTimeout(r, 5000))

// آزمون قطعی با حروف لاتین: ABC هرگز نباید CBA دیده شود
const out = await page.evaluate(() => {
  const draw = (text) => {
    const pad = 18, fs = 34
    const c = document.createElement('canvas')
    const ctx = c.getContext('2d')
    ctx.font = `700 ${fs}px sans-serif`
    const w = Math.ceil(ctx.measureText(text).width) + pad * 2
    c.width = w; c.height = 64
    const x = c.getContext('2d')
    x.fillStyle = '#000'; x.fillRect(0, 0, w, 64)
    x.font = `700 ${fs}px sans-serif`
    x.textAlign = 'center'; x.textBaseline = 'middle'
    x.fillStyle = '#fff'
    x.fillText(text, w / 2, 33)
    return c
  }
  const labels = ['ABC', 'میدان شهر']
  const shots = labels.map((t) => {
    const c = draw(t)
    return { text: t, url: c.toDataURL(), w: c.width, h: c.height }
  })
  // ساخت صفحه‌ی مقایسه: هر بافت + قرینه‌ی افقی‌اش برای چشم
  document.body.innerHTML = ''
  document.body.style.cssText = 'background:#1a1a1a;margin:0;padding:16px;direction:ltr'
  for (const s of shots) {
    const wrap = document.createElement('div')
    wrap.style.cssText = 'margin-bottom:20px'
    const lbl = document.createElement('div')
    lbl.textContent = `متن: «${s.text}»  (${s.w}×${s.h})`
    lbl.style.cssText = 'color:#8cf;font:13px monospace;margin-bottom:6px'
    wrap.appendChild(lbl)
    const img = new Image()
    img.src = s.url
    img.style.cssText = 'display:block;border:2px solid #f80;image-rendering:pixelated;width:' + s.w * 2 + 'px'
    wrap.appendChild(img)
    // نسخه‌ی قرینه‌شده برای مقایسه
    const mirror = document.createElement('canvas')
    mirror.width = s.w; mirror.height = s.h
    const mc = mirror.getContext('2d')
    mc.translate(s.w, 0); mc.scale(-1, 1)
    mc.drawImage(img, 0, 0)
    const out2 = document.createElement('canvas')
    out2.width = s.w; out2.height = s.h
    out2.getContext('2d').drawImage(img, 0, 0)
    const m2 = document.createElement('canvas')
    m2.width = s.w; m2.height = s.h
    const c2 = m2.getContext('2d')
    c2.translate(s.w, 0); c2.scale(-1, 1); c2.drawImage(out2, 0, 0)
    const mlbl = document.createElement('div')
    mlbl.textContent = 'همان متن، به‌صورت آینه‌ای (برای مقایسه)'
    mlbl.style.cssText = 'color:#f88;font:13px monospace;margin:8px 0 6px'
    wrap.appendChild(mlbl)
    m2.style.cssText = 'display:block;border:2px solid #08f;image-rendering:pixelated;width:' + s.w * 2 + 'px'
    wrap.appendChild(m2)
    document.body.appendChild(wrap)
    void mc
  }
  return shots.map((s) => ({ text: s.text, w: s.w }))
})
console.log('بافت‌های ساخته‌شده:', JSON.stringify(out))
await page.screenshot({ path: '/tmp/compare.png', fullPage: true })
await browser.close()
