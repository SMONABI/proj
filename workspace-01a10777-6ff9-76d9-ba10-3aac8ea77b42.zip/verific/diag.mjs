import puppeteer from 'puppeteer'
const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
const page = await browser.newPage()
const errs = []
page.on('pageerror', (e) => errs.push('pageerror: ' + e.message))
page.on('console', (m) => errs.push(`console.${m.type()}: ` + m.text().slice(0, 200)))
await page.goto('file:///home/user/eldoria/Eldoria-3D.html', { waitUntil: 'domcontentloaded', timeout: 60000 })
await new Promise((r) => setTimeout(r, 4000))
const d = await page.evaluate(() => {
  const scripts = [...document.querySelectorAll('script')]
  return {
    readyState: document.readyState,
    scriptCount: scripts.length,
    scriptTypes: scripts.map((s) => ({ type: s.type || '(کلاسیک)', len: (s.textContent || '').length, src: s.src || null })),
    headChildren: [...document.head.children].map((c) => c.tagName).join(','),
    bodyChildren: [...document.body.children].map((c) => c.tagName + (c.id ? '#' + c.id : '')).join(','),
    rootHTML: document.getElementById('root')?.innerHTML.slice(0, 100) ?? '(بدون root)',
    markers: {
      reactRefresh: typeof window.$RefreshReg$,
      viteClient: typeof window.__vite_plugin_react_preamble_installed__,
      inlineRan: window.__inlineRan,
    },
    styleSheets: document.styleSheets.length,
  }
})
console.log(JSON.stringify(d, null, 2))
console.log('\nرویدادها:', errs.length ? errs.slice(0, 8) : 'هیچ رویدادی ثبت نشد')
// بررسی می‌کنیم متن اسکریپت اول همان چیزی است که انتظار داریم
const head = await page.evaluate(() => document.querySelector('script')?.textContent?.slice(0, 120))
console.log('\nابتدای متن اسکریپت اول:', JSON.stringify(head))
await browser.close()
