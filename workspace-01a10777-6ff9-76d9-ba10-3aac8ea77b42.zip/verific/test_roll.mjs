// ═══ آزمون جهت مهارت «غلت» (فقط کماندار) ═══
// مسیر کد roll هم مثل حرکت عادی از ورودی صفحه استفاده می‌کند و اصلاح شده است.
import puppeteer from 'puppeteer'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }

const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--disable-dev-shm-usage'] })
const page = await browser.newPage()
await page.setViewport({ width: 360, height: 240 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await sleep(6000)

// انتخاب کلاس کماندار و شروع بازی
const picked = await page.evaluate(() => {
  const card = [...document.querySelectorAll('button')].find((b) => /کماندار/.test(b.textContent || ''))
  if (!card) return false
  card.click()
  return true
})
await sleep(600)
await page.evaluate(() => {
  const b = [...document.querySelectorAll('button')].find((x) => /آغاز ماجراجویی/.test(x.textContent || ''))
  b?.click()
})
await sleep(3500)
const cls = await page.evaluate(() => window.__eldoria?.cls?.id)
check('کلاس کماندار انتخاب شد', picked && cls === 'ranger', `کلاس فعال: ${cls}`)
await page.evaluate(() => { const g = window.__eldoria; g.engine.quality = 2; g.engine.applyQuality(); g.engine.resize() })

const YAW = 0.7
const F = { x: Math.sin(YAW), z: Math.cos(YAW) }
const R = { x: -Math.cos(YAW), z: Math.sin(YAW) }

async function rollTest(label, input, expected, name) {
  await page.evaluate(({ yaw }) => {
    const g = window.__eldoria
    g.enemies.enemies.forEach((e) => { e.dead = true })
    g.player.teleport(330, 40)
    g.player.vel.set(0, 0, 0)
    g.player.camYaw = yaw
    g.player.rollT = 0
    g.player.state = 'idle'
    g.player.iframes = 0
    const t = window.__eldoriaTouch
    t.mx = 0; t.mz = 0
    const st = g.constructor // بی‌استفاده
    void st
  }, { yaw: YAW })
  await sleep(300)
  // شارژ مجدد مانا تا آزمون مستقل باشد
  await page.evaluate(() => { const g = window.__eldoria; g.mana = 999; g.cds = [0,0,0,0] })

  if (input.touch) await page.evaluate((t) => Object.assign(window.__eldoriaTouch, t), input.touch)
  for (const k of input.keys || []) await page.keyboard.down(k)
  await sleep(400)

  await page.evaluate(() => { const g = window.__eldoria; g.castSkill(2) })   // ۳ = غلت
  // بیشترین سرعت را در طول غلت نمونه‌برداری کن
  let best = { x: 0, z: 0, s: 0 }, rolled = false
  for (let i = 0; i < 24; i++) {
    const v = await page.evaluate(() => {
      const p = window.__eldoria.player
      return { x: p.vel.x, z: p.vel.z, s: Math.hypot(p.vel.x, p.vel.z), rolling: p.rollT > 0 }
    })
    if (v.rolling) rolled = true
    if (v.s > best.s) best = v
    if (!v.rolling && i > 4) break
    await sleep(80)
  }
  for (const k of input.keys || []) await page.keyboard.up(k)
  await page.evaluate(() => { const t = window.__eldoriaTouch; t.mx = 0; t.mz = 0 })
  await sleep(200)

  const dot = best.s < 0.3 ? 0 : (best.x * expected.x + best.z * expected.z) / best.s
  const ok = rolled && dot > 0.7
  check(`${label} → غلت به «${name}»`, ok,
    `سرعت اوج ${best.s.toFixed(1)} واحد/ث · هم‌جهتی ${dot >= 0 ? '+' : ''}${dot.toFixed(2)}${rolled ? '' : ' · غلت اجرا نشد'}`)
}

await rollTest('جوی‌استیک به بالا', { touch: { mz: -1 } }, F, 'جلو')
await rollTest('کلید D', { keys: ['d'] }, R, 'راست صفحه')
await rollTest('جوی‌استیک به چپ', { touch: { mx: -1 } }, { x: -R.x, z: -R.z }, 'چپ صفحه')

await browser.close()
console.log(`\nنتیجه: ${pass} درست، ${fail} خراب`)
process.exit(fail ? 1 : 0)
