import puppeteer from 'puppeteer'

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
await page.setViewport({ width: 1000, height: 640 })
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await new Promise((r) => setTimeout(r, 6000))

const report = await page.evaluate(() => {
  const g = window.__eldoria
  if (!g) return { error: 'قلاب دیباگ در دسترس نیست' }
  const cam = g.engine.camera
  const out = []
  // همه‌ی اسپرایت‌های صحنه را پیدا کن، به مختصات صفحه تبدیل کن
  g.engine.scene.traverse((o) => {
    if (!o.isSprite) return
    const p = o.getWorldPosition(new (o.position.constructor)())
    const v = p.clone().project(cam)
    const sx = (v.x * 0.5 + 0.5) * window.innerWidth
    const sy = (-v.y * 0.5 + 0.5) * window.innerHeight
    const s = o.getWorldScale(new (o.position.constructor)())
    out.push({
      px: Math.round(sx), py: Math.round(sy), inFront: v.z <= 1,
      x: +p.x.toFixed(1), y: +p.y.toFixed(1), z: +p.z.toFixed(1),
      sx: +s.x.toFixed(2), sy: +s.y.toFixed(2),
      visible: o.visible, parentVisible: o.parent?.visible,
      // متن روی بافت
      text: o.material?.map?.image ? '(بافت)' : '(بدون بافت)',
      scaleNeg: s.x < 0 || s.y < 0,
      rot: +o.material.rotation.toFixed(3),
    })
  })
  return {
    screen: [window.innerWidth, window.innerHeight],
    camPos: [+cam.position.x.toFixed(1), +cam.position.y.toFixed(1), +cam.position.z.toFixed(1)],
    camFov: cam.fov,
    sprites: out.filter((s) => s.inFront && s.px > -200 && s.px < 1400 && s.py > -200 && s.py < 900),
  }
})

console.log('اندازه‌ی صفحه:', report.screen)
console.log('دوربین:', report.camPos, '| fov:', report.camFov)
console.log('\nاسپرایت‌های دیده‌شده روی صفحه (موقعیت صفحه → موقعیت جهان):')
console.log('─'.repeat(88))
for (const s of report.sprites.sort((a, b) => b.sx * b.sy - a.sx * a.sy)) {
  console.log(`صفحه (${String(s.px).padStart(4)}, ${String(s.py).padStart(3)})  اندازه‌ی صفحه: ${String(Math.round(s.sx * 614.8 / Math.max(1, Math.hypot(s.x - report.camPos[0], s.y - report.camPos[1], s.z - report.camPos[2])))).padStart(4)}px  |  جهان (${s.x}, ${s.y}, ${s.z})  مقیاس ${s.sx}×${s.sy}  ${s.scaleNeg ? '⚠ مقیاس منفی' : ''} ${s.visible ? '' : 'مخفی '}`)
}
await browser.close()
