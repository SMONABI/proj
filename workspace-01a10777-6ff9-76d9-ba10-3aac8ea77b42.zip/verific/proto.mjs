import puppeteer from 'puppeteer'
const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
for (const f of ['a_module', 'b_classic', 'c_external']) {
  const page = await browser.newPage()
  const errs = []
  page.on('pageerror', (e) => errs.push(e.message))
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 120)) })
  await page.goto(`file:///tmp/fproto/${f}.html`, { waitUntil: 'domcontentloaded' })
  await new Promise((r) => setTimeout(r, 1500))
  const txt = await page.evaluate(() => document.getElementById('root').textContent)
  console.log(`${f.padEnd(14)} → "${txt}"   ${errs.length ? 'خطا: ' + errs.join(' | ') : 'بدون خطا'}`)
  await page.close()
}
await browser.close()
