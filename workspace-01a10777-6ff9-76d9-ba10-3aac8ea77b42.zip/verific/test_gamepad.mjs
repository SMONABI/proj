// ═══ آزمون پشتیبانی از دسته‌بازی ═══
// یک «دسته‌ی مجازی» به navigator.getGamepads تزریق می‌شود — یعنی همان رابطی که
// خود بازی می‌خواند، پس آزمون واقعی است.
//
// ⚠️ نکته‌ی مهم: محیط آزمون با رندر نرم‌افزاری زیر ۲ فریم بر ثانیه کار می‌کند،
// پس انتظار «زمانی» ناپایدار است. همه‌ی انتظارها فریم‌محور هستند.
import puppeteer from 'puppeteer'

let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})
const page = await browser.newPage()
await page.setViewport({ width: 360, height: 240 })
const errors = []
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 130)) })

await page.evaluateOnNewDocument(() => {
  const state = {
    axes: [0, 0, 0, 0],
    buttons: Array.from({ length: 17 }, () => ({ pressed: false, value: 0 })),
    id: 'Xbox Wireless Controller (STANDARD GAMEPAD Vendor: 045e Product: 02fd)',
    mapping: 'standard', connected: true, rumbleCalls: [],
  }
  const padObj = {
    get axes() { return state.axes },
    get buttons() { return state.buttons },
    get id() { return state.id },
    get index() { return 0 },
    get mapping() { return state.mapping },
    get connected() { return state.connected },
    get vibrationActuator() {
      return { playEffect: (type, p) => { state.rumbleCalls.push({ type, ...p }); return Promise.resolve('complete') } }
    },
  }
  Object.defineProperty(navigator, 'getGamepads', { configurable: true, value: () => [padObj] })
  window.__pad = {
    state,
    setAxes: (a) => { state.axes = a },
    press: (i) => { state.buttons[i].pressed = true; state.buttons[i].value = 1 },
    release: (i) => { state.buttons[i].pressed = false; state.buttons[i].value = 0 },
    releaseAll: () => state.buttons.forEach((b) => { b.pressed = false; b.value = 0 }),
    setId: (v) => { state.id = v },
    setMapping: (v) => { state.mapping = v },
    setConnected: (v) => { state.connected = v },
    rumbleCalls: () => state.rumbleCalls.slice(),
    clearRumble: () => { state.rumbleCalls.length = 0 },
  }
})

await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })

// ─── کمکی‌ها: انتظار فریم‌محور ───
const frames = (n = 3) => page.evaluate((count) => new Promise((res) => {
  let i = 0
  const tick = () => { if (++i >= count) res(); else requestAnimationFrame(tick) }
  requestAnimationFrame(tick)
}), n)
const press = async (i, n = 5) => {
  await page.evaluate((x) => window.__pad.press(x), i)
  await frames(n)
  await page.evaluate((x) => window.__pad.release(x), i)
  await frames(2)
}
const setAxes = async (a, n = 5) => { await page.evaluate((x) => window.__pad.setAxes(x), a); await frames(n) }
const reset = () => page.evaluate(() => { window.__pad.setAxes([0, 0, 0, 0]); window.__pad.releaseAll() })
const S = () => page.evaluate(() => window.__eldoriaStore.getState())
const G = () => page.evaluate(() => {
  const g = window.__eldoria, p = g.player
  return { phase: window.__eldoriaStore.getState().phase, state: p?.state, vel: { x: p?.vel.x, y: p?.vel.y, z: p?.vel.z }, camYaw: p?.camYaw, camPitch: p?.camPitch, hp: g.hp, cds: [...g.cds] }
})

await frames(20)

console.log('─'.repeat(66))
console.log('۱) شناسایی دسته')
console.log('─'.repeat(66))
const c1 = await page.evaluate(() => ({ connected: window.__eldoriaPad.connected, kind: window.__eldoriaPad.kind }))
check('دسته با نظرسنجی شناسایی شد (بدون رویداد اتصال)', c1.connected === true)
check('نوع دسته از شناسه تشخیص داده شد', c1.kind === 'xbox', `نوع: ${c1.kind}`)
check('وضعیت اتصال به استور رسید', (await S()).padConnected === true)

console.log('\n' + '─'.repeat(66))
console.log('۲) صفحه‌ی عنوان: ناوبری و شروع')
console.log('─'.repeat(66))
const classA = (await S()).titleClass
await press(15)                       // D-pad راست
const classB = (await S()).titleClass
check('D-pad راست کلاس را عوض می‌کند', classA !== classB, `${classA} → ${classB}`)
await press(14)                       // D-pad چپ
const classC = (await S()).titleClass
check('D-pad چپ برمی‌گرداند', classC === classA, `${classB} → ${classC}`)

await press(0)                        // A = شروع
check('دکمه A بازی را شروع می‌کند', (await S()).phase === 'playing', `phase = ${(await S()).phase}`)
await page.evaluate(() => { const g = window.__eldoria; g.engine.quality = 2; g.engine.applyQuality(); g.engine.resize() })
await frames(5)

const YAW = 0.7
const F = { x: Math.sin(YAW), z: Math.cos(YAW) }
const R = { x: -Math.cos(YAW), z: Math.sin(YAW) }
const park = async (yaw = YAW) => {
  await reset()
  await page.evaluate(({ y }) => {
    const g = window.__eldoria
    g.enemies.enemies.forEach((e) => { e.dead = true })
    g.player.teleport(330, 40)
    g.player.vel.set(0, 0, 0); g.player.camYaw = y; g.player.state = 'idle'
  }, { y: yaw })
  await frames(3)
}

console.log('\n' + '─'.repeat(66))
console.log('۳) حرکت با استیک چپ (دوربین با زاویه‌ی غیرهم‌محور)')
console.log('─'.repeat(66))
for (const [label, axes, exp, name] of [
  ['استیک چپ به بالا', [0, -1, 0, 0], F, 'جلو'],
  ['استیک چپ به راست', [1, 0, 0, 0], R, 'راست صفحه'],
  ['استیک چپ به پایین', [0, 1, 0, 0], { x: -F.x, z: -F.z }, 'عقب'],
  ['استیک چپ به چپ', [-1, 0, 0, 0], { x: -R.x, z: -R.z }, 'چپ صفحه'],
]) {
  await park()
  await setAxes(axes)
  const g = await G()
  const s = Math.hypot(g.vel.x, g.vel.z)
  const dot = s < 0.05 ? 0 : (g.vel.x * exp.x + g.vel.z * exp.z) / s
  check(`${label} → ${name}`, dot > 0.7, `سرعت ${s.toFixed(2)} واحد/ث · هم‌جهتی ${dot >= 0 ? '+' : ''}${dot.toFixed(2)}`)
}
await park()
await setAxes([0, -1, 0, 0])
const sprinting = await page.evaluate(() => window.__eldoria.player.sprinting)
check('فشار کامل استیک = دویدن', sprinting === true)
await reset()

console.log('\n' + '─'.repeat(66))
console.log('۴) منطقه‌ی مرده')
console.log('─'.repeat(66))
await park()
await setAxes([0.12, -0.12, 0, 0])
const dzV = await G()
check('لرزش کوچک استیک حرکتی ایجاد نمی‌کند', Math.hypot(dzV.vel.x, dzV.vel.z) < 0.05,
      `سرعت ${Math.hypot(dzV.vel.x, dzV.vel.z).toFixed(3)} واحد/ث`)
await reset()

console.log('\n' + '─'.repeat(66))
console.log('۵) دوربین با استیک راست')
console.log('─'.repeat(66))
await park()
await setAxes([0, 0, 1, 0])
const yawA = (await G()).camYaw
check('استیک راست به راست → چرخش به راست', yawA < YAW - 0.1, `ΔcamYaw = ${(yawA - YAW).toFixed(3)} (منفی = راست)`)
await reset()
await page.evaluate(() => { window.__eldoria.player.camPitch = 0.32 })
await setAxes([0, 0, 0, 1])
const pitchA = (await G()).camPitch
check('استیک راست به پایین → نگاه به پایین', pitchA > 0.34, `camPitch: 0.32 → ${pitchA.toFixed(3)}`)
await reset()

console.log('\n' + '─'.repeat(66))
console.log('۶) دکمه‌های عمل (X حمله · A پرش · B معجون · Y تعامل)')
console.log('─'.repeat(66))
await park()
await page.evaluate(() => window.__pad.press(2))    // X
await frames(3)
const attacking = await G()
await page.evaluate(() => window.__pad.release(2))
check('X = حمله', attacking.state === 'attack' || attacking.state === 'cast', `وضعیت بازیکن: ${attacking.state}`)

await park()
await page.evaluate(() => { const g = window.__eldoria; g.player.grounded = true; g.player.vel.y = 0 })
await page.evaluate(() => window.__pad.press(0))    // A
await frames(3)
const jumped = await G()
await page.evaluate(() => window.__pad.release(0))
check('A = پرش', (jumped.vel?.y ?? 0) > 2, `سرعت عمودی: ${(jumped.vel?.y ?? 0).toFixed(2)}`)

await park()
await page.evaluate(() => { window.__eldoria.hp = 10; window.__eldoriaStore.getState().set({ potions: 3 }) })
await press(1)                                       // B
const afterPotion = await page.evaluate(() => ({ hp: window.__eldoria.hp, potions: window.__eldoriaStore.getState().potions }))
check('B = نوشیدن معجون', afterPotion.potions === 2 && afterPotion.hp > 10,
      `معجون: ۳ → ${afterPotion.potions} · جان: ۱۰ → ${Math.round(afterPotion.hp)}`)

// تعامل: کنار NPC «کاپیتان روریک» در (10, 14)
await reset()
await page.evaluate(() => {
  const g = window.__eldoria
  g.player.teleport(10, 15.5); g.player.vel.set(0, 0, 0); g.player.state = 'idle'
})
await frames(4)
await press(3)                                       // Y
const dlg = await page.evaluate(() => !!window.__eldoriaStore.getState().dialog)
check('Y = گفت‌وگو با NPC', dlg === true)
await press(1)                                       // B = بستن دیالوگ
check('B دیالوگ را می‌بندد', !(await page.evaluate(() => !!window.__eldoriaStore.getState().dialog)))

console.log('\n' + '─'.repeat(66))
console.log('۷) مهارت‌ها روی شانه‌ها و تریگرها')
console.log('─'.repeat(66))
for (const [btn, idx, name] of [[4, 0, 'LB = مهارت ۱'], [5, 1, 'RB = مهارت ۲'], [6, 2, 'LT = مهارت ۳'], [7, 3, 'RT = مهارت ۴']]) {
  await park()
  await page.evaluate(() => { const g = window.__eldoria; g.mana = 999; g.cds = [0, 0, 0, 0] })
  await press(btn)
  const cds = (await G()).cds
  check(name, cds[idx] > 0, `کول‌داون اسلات ${idx + 1}: ${cds[idx].toFixed(2)}ث`)
}

console.log('\n' + '─'.repeat(66))
console.log('۸) بازخورد لمسی (لرزش)')
console.log('─'.repeat(66))
await page.evaluate(() => window.__pad.clearRumble())
await park()
await page.evaluate(() => { const g = window.__eldoria; g.playerHurt(15, g.player.pos) })
await frames(3)
const rumble = await page.evaluate(() => window.__pad.rumbleCalls())
check('آسیب دیدن → لرزش دسته', rumble.length > 0 && rumble[0].type === 'dual-rumble',
      rumble[0] ? `قدرت ${rumble[0].strongMagnitude} برای ${rumble[0].duration}ms` : 'فراخوانی نشد')

console.log('\n' + '─'.repeat(66))
console.log('۹) دسته‌های غیراستاندارد و قطع اتصال')
console.log('─'.repeat(66))
await page.evaluate(() => { window.__pad.setId('Generic USB Joystick'); window.__pad.setMapping('') })
await frames(4)
const generic = await page.evaluate(() => ({ kind: window.__eldoriaPad.kind, map: window.__eldoriaPad.map }))
check('دسته‌ی ناشناس → نوع «generic»', generic.kind === 'generic')
check('نگاشت جایگزین ساخته شد', generic.map && generic.map.a === 0 && generic.map.dright === 15,
      `تعداد دکمه‌های نگاشت‌شده: ${Object.keys(generic.map || {}).length}`)
await park()
await page.evaluate(() => window.__pad.press(2))
await frames(3)
const genAtk = await G()
await page.evaluate(() => window.__pad.release(2))
check('حمله با دسته‌ی غیراستاندارد هم کار می‌کند', genAtk.state === 'attack' || genAtk.state === 'cast', `وضعیت: ${genAtk.state}`)

await page.evaluate(() => window.__pad.setConnected(false))
await frames(6)
const disc = await page.evaluate(() => ({ connected: window.__eldoriaPad.connected, store: window.__eldoriaStore.getState().padConnected, toast: window.__eldoriaStore.getState().toast }))
check('قطع اتصال تشخیص داده می‌شود', disc.connected === false && disc.store === false)
check('پیام قطع اتصال نمایش داده می‌شود', !!disc.toast && /قطع/.test(disc.toast || ''), disc.toast || '—')

console.log('\n' + '─'.repeat(66))
check('بدون خطای زمان اجرا', errors.length === 0, errors.slice(0, 3).join(' | ') || 'هیچ')
await browser.close()
console.log(`\nنتیجه: ${pass} موفق، ${fail} ناموفق`)
process.exit(fail ? 1 : 0)
