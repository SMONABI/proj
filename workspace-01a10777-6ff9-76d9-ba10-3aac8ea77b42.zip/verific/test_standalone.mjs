import puppeteer from 'puppeteer'
import { PNG } from 'pngjs'
import fs from 'node:fs'

const FILE = 'file:///home/user/eldoria/Eldoria-3D.html'
let pass = 0, fail = 0
const check = (n, ok, x = '') => { console.log(`${ok ? '✅' : '❌'} ${n}${x ? '  →  ' + x : ''}`); ok ? pass++ : fail++ }

function analyze(file) {
  const png = PNG.sync.read(fs.readFileSync(file))
  let nonBlack = 0, colorful = 0
  const colors = new Set()
  for (let i = 0; i < png.data.length; i += 4) {
    const [r, g, b] = [png.data[i], png.data[i + 1], png.data[i + 2]]
    if (r + g + b > 24) nonBlack++
    if (Math.max(r, g, b) - Math.min(r, g, b) > 18) colorful++
    if (colors.size < 6000) colors.add((r >> 3) << 10 | (g >> 3) << 5 | (b >> 3))
  }
  const n = png.data.length / 4
  return { nonBlackPct: nonBlack / n * 100, colorfulPct: colorful / n * 100, colors: colors.size }
}

const browser = await puppeteer.launch({
  headless: 'shell',
  args: ['--no-sandbox', '--disable-setuid-sandbox', '--use-gl=angle',
         '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage'],
})

console.log('═'.repeat(64))
console.log('آزمون فایل مستقل از طریق file://  (دقیقاً «دابل‌کلیک روی HTML»)')
console.log('═'.repeat(64))

const page = await browser.newPage()
await page.setViewport({ width: 1000, height: 640 })
const errors = []
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message))
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 140)) })
page.on('requestfailed', (r) => errors.push('requestfailed: ' + r.url().slice(0, 90)))

await page.goto(FILE, { waitUntil: 'domcontentloaded', timeout: 90000 })
await new Promise((r) => setTimeout(r, 8000))

const st = await page.evaluate(() => ({
  proto: location.protocol,
  rootChildren: document.getElementById('root')?.children.length ?? -1,
  text: (document.body.innerText || '').trim().split('\n').filter(Boolean).slice(0, 5),
  hasCanvas: !!document.querySelector('canvas'),
  storageOk: (() => { try { localStorage.setItem('t', '1'); localStorage.removeItem('t'); return true } catch { return false } })(),
}))
console.log('پروتکل:', st.proto, '| localStorage در file://:', st.storageOk ? 'کار می‌کند' : 'مسدود (بازی باید بی‌ذخیره ادامه دهد)')
console.log('متن صفحه:', JSON.stringify(st.text))

await page.screenshot({ path: '/tmp/sa_title.png' })
const a1 = analyze('/tmp/sa_title.png')
console.log(`تیتراژ → ${a1.nonBlackPct.toFixed(1)}% روشن، ${a1.colorfulPct.toFixed(1)}% رنگی، ${a1.colors} رنگ`)
check('فایل مستقل بدون سرور بارگذاری شد', st.rootChildren > 0, `${st.rootChildren} فرزند`)
check('صفحه سفید نیست — تیتراژ دیده می‌شود', /الدوریا|ماجراجویی/.test(st.text.join(' ')), st.text[0] ?? '')
check('صحنه‌ی سه‌بعدی رندر شد', a1.nonBlackPct > 40 && a1.colors > 300, `${a1.colors} رنگ`)

const clicked = await page.evaluate(() => {
  const b = [...document.querySelectorAll('button')].find((x) => /آغاز ماجراجویی/.test(x.textContent || ''))
  if (!b) return false
  b.click(); return true
})
check('دکمه‌ی شروع کار می‌کند', clicked)
if (clicked) {
  await new Promise((r) => setTimeout(r, 8000))
  await page.screenshot({ path: '/tmp/sa_play.png' })
  const a2 = analyze('/tmp/sa_play.png')
  const hud = await page.evaluate(() => (document.body.innerText || '').trim().split('\n').filter(Boolean).slice(0, 4))
  console.log(`بازی → ${a2.nonBlackPct.toFixed(1)}% روشن، ${a2.colorfulPct.toFixed(1)}% رنگی، ${a2.colors} رنگ`)
  console.log('HUD:', JSON.stringify(hud))
  check('بازی شروع شد', /الدوریا|طلا/.test(hud.join(' ')), hud.slice(0, 2).join(' | '))
  check('صحنه‌ی بازی زنده است', a2.nonBlackPct > 40 && a2.colors > 300, `${a2.colors} رنگ`)
}

if (errors.length) { console.log('\nخطاها:'); errors.slice(0, 6).forEach((e) => console.log('   ', e)) }
check('بدون خطای مهلک', errors.filter((e) => !/fonts\.googleapis|fonts\.gstatic/.test(e)).length === 0,
      `${errors.length} خطا (شامل فونت آفلاین)`)

await browser.close()
console.log(`\n${'─'.repeat(64)}\nنتیجه: ${pass} موفق، ${fail} ناموفق`)
process.exit(fail ? 1 : 0)
