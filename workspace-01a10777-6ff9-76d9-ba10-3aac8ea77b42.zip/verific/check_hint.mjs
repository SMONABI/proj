import puppeteer from 'puppeteer'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const browser = await puppeteer.launch({ headless: 'shell',
  args: ['--no-sandbox','--disable-setuid-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'] })
const page = await browser.newPage()
await page.setViewport({ width: 1000, height: 900 })
await page.evaluateOnNewDocument(() => {
  const state = { axes:[0,0,0,0], buttons: Array.from({length:17},()=>({pressed:false,value:0})),
    id: 'Xbox Wireless Controller', mapping: 'standard', connected: true }
  const padObj = { get axes(){return state.axes}, get buttons(){return state.buttons}, get id(){return state.id},
    get index(){return 0}, get mapping(){return state.mapping}, get connected(){return state.connected},
    get vibrationActuator(){ return { playEffect: () => Promise.resolve('complete') } } }
  Object.defineProperty(navigator, 'getGamepads', { configurable: true, value: () => [padObj] })
})
await page.goto('http://127.0.0.1:3000/', { waitUntil: 'domcontentloaded', timeout: 60000 })
await sleep(7000)
const t = await page.evaluate(() => {
  const txt = document.body.innerText
  return {
    padHint: /🎮/.test(txt),
    padHintLine: (txt.split('\n').find((l) => /🎮/.test(l)) || '').trim(),
    hasStart: /A شروع|✕ شروع/.test(txt) || /شروع/.test(txt),
  }
})
console.log('راهنمای متصل بودن دسته در تیتراژ:', t.padHint ? '✅ دیده می‌شود' : '❌ نیست')
console.log('متن:', t.padHintLine || '—')
await page.screenshot({ path: '/tmp/hint.png' })
await browser.close()
