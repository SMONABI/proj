// ═══ ساخت نسخه‌ی تک‌فایلی: Eldoria-3D.html ═══
// چرا: اگر index.html را مستقیم با دابل‌کلیک باز کنید، مرورگر نمی‌تواند
// /src/main.tsx (TypeScript) را اجرا کند و صفحه سفید می‌بینید. این اسکریپت
// بیلد را می‌گیرد و HTML+CSS+JS را در یک فایل واحد جمع می‌کند که با file://
// هم بدون هیچ سروری کار می‌کند.
import fs from 'node:fs'
import path from 'node:path'

const dist = path.resolve('dist')
const htmlPath = path.join(dist, 'index.html')
if (!fs.existsSync(htmlPath)) {
  console.error('❌ پوشه‌ی dist پیدا نشد. اول «npm run build» را اجرا کنید.')
  process.exit(1)
}
let html = fs.readFileSync(htmlPath, 'utf8')

const assets = (ext) => {
  const dir = path.join(dist, 'assets')
  return fs.readdirSync(dir).filter((f) => f.endsWith(ext)).map((f) => path.join(dir, f))
}

const css = assets('.css').map((f) => fs.readFileSync(f, 'utf8')).join('\n')
const js = assets('.js').map((f) => fs.readFileSync(f, 'utf8')).join('\n')

// ⚠️ نکته‌ی حیاتی: همیشه از «تابع» به‌عنوان جایگزین استفاده کنید، نه رشته.
// در حالت رشته‌ای، الگوهایی مثل $&، $`، $' و $1 معنی خاص دارند و چون باندل
// شامل کدهایی مثل .replace(/[…]/g, '\\$&') است، متنِ تگ اسکریپت جای $& می‌نشیند
// و کد بی‌سروصدا خراب می‌شود — که خودش منجر به صفحه‌ی سفید می‌شود.
const rep = (re, fn) => { html = html.replace(re, fn) }

// فونت گوگل آفلاین در دسترس نیست → حذفش کنیم تا به فونت سیستمی سقوط کند
rep(/<link[^>]*fonts\.googleapis[^>]*>\s*/g, () => '')
rep(/<link[^>]*fonts\.gstatic[^>]*>\s*/g, () => '')

// CSS درون فایل
rep(/<link[^>]*rel="stylesheet"[^>]*href="[^"]*\.css"[^>]*>/g, () => `<style>\n${css}\n</style>`)

// JS درون فایل — `</script>` داخل رشته‌ها باید escape شود
const safeJs = js.replace(/<\/script>/gi, () => '<\\/script>')

// همه‌ی تگ‌های اسکریپتِ ماژولار (شامل preloadها) با نسخه‌ی درون‌ریز عوض می‌شوند
let firstScriptDone = false
rep(/<script\b[^>]*\bsrc="[^"]*\.js"[^>]*>\s*<\/script>/g, () => {
  if (firstScriptDone) return ''
  firstScriptDone = true
  return `<script type="module">\n${safeJs}\n</script>`
})
rep(/<link[^>]*rel="modulepreload"[^>]*>\s*/g, () => '')

const out = path.resolve('..', 'Eldoria-3D.html')
fs.writeFileSync(out, html)

const kb = (n) => (n / 1024).toFixed(0) + ' KB'
console.log('✅ نسخه‌ی تک‌فایلی ساخته شد')
console.log('   مسیر:', out)
console.log('   CSS:', kb(css.length), '| JS:', kb(js.length), '| کل:', kb(html.length))

// ─── راستی‌آزمایی: نباید هیچ ارجاع بیرونی یا جایگزینی خراب باقی بماند ───
const problems = []
const tags = html.match(/<(link|script)\b[^>]*>/g) || []
for (const t of tags) {
  if (/\bsrc="[^"]*\.js"/.test(t)) problems.push(`تگ اسکریپت بیرونی باقی مانده: ${t.slice(0, 80)}`)
  if (/href="[^"]*\.css"/.test(t)) problems.push(`تگ استایل بیرونی باقی مانده: ${t.slice(0, 80)}`)
}
if (!firstScriptDone) problems.push('هیچ اسکریپتی درون‌ریز نشد!')
if (!/<\/script>/.test(html)) problems.push('تگ پایانی اسکریپت پیدا نشد')
// نشانه‌ی فساد جایگزینی رشته‌ای
if (html.includes('src="./assets/')) problems.push('نشانه‌ی جایگزینی خراب $& در باندل')

if (problems.length) {
  console.error('\n❌ راستی‌آزمایی شکست خورد:')
  problems.forEach((p) => console.error('   -', p))
  process.exit(1)
}
console.log('   ✓ هیچ ارجاع بیرونی نمانده')
console.log('   ✓ نشانه‌ای از فساد درون‌ریزی دیده نمی‌شود')
