// ═══ هسته رندر: رندرر، پست‌پروسسینگ، کیفیت تطبیقی ═══
import * as THREE from 'three'
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js'
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js'

export type QualityTier = 0 | 1 | 2 // 0=بالا 1=متوسط 2=پایین

export class Engine {
  renderer: THREE.WebGLRenderer
  scene: THREE.Scene
  camera: THREE.PerspectiveCamera
  composer: EffectComposer
  bloom: UnrealBloomPass
  clock = new THREE.Clock()
  quality: QualityTier
  isMobile: boolean
  private fpsAcc = 0
  private fpsN = 0
  private fpsTimer = 0
  timeScale = 1
  private hitstopT = 0

  constructor(canvas: HTMLCanvasElement) {
    this.isMobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || window.innerWidth < 820
    this.quality = this.isMobile ? 1 : 0

    this.renderer = new THREE.WebGLRenderer({
      canvas, antialias: true, powerPreference: 'high-performance', stencil: false,
    })
    this.renderer.shadowMap.enabled = true
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping
    this.renderer.toneMappingExposure = 1.12
    this.renderer.outputColorSpace = THREE.SRGBColorSpace

    this.scene = new THREE.Scene()
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 900)
    this.camera.position.set(0, 3, 8)

    this.composer = new EffectComposer(this.renderer)
    this.composer.addPass(new RenderPass(this.scene, this.camera))
    this.bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.42, 0.65, 0.82)
    this.composer.addPass(this.bloom)
    this.composer.addPass(new OutputPass())

    this.applyQuality()
    this.resize()
    window.addEventListener('resize', () => this.resize())
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight
    this.camera.aspect = w / h
    this.camera.updateProjectionMatrix()
    const pr = this.pixelRatio()
    this.renderer.setPixelRatio(pr)
    this.renderer.setSize(w, h)
    this.composer.setPixelRatio(pr)
    this.composer.setSize(w, h)
  }

  pixelRatio(): number {
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    if (this.quality === 0) return Math.min(dpr, 1.75)
    if (this.quality === 1) return Math.min(dpr, 1.25)
    return 1
  }

  applyQuality() {
    const q = this.quality
    this.bloom.enabled = q < 2
    this.renderer.shadowMap.enabled = q < 2
  }

  hitstop(dur = 0.06, scale = 0.12) {
    this.hitstopT = dur
    this.timeScale = scale
  }

  /** گام زمانی فریم؛ مدیریت hitstop و محدودکردن dt */
  tick(): number {
    let dt = Math.min(this.clock.getDelta(), 1 / 20)
    if (this.hitstopT > 0) {
      this.hitstopT -= dt
      if (this.hitstopT <= 0) this.timeScale = 1
    }
    dt *= this.timeScale
    // پایش نرخ فریم و تنزل خودکار کیفیت
    this.fpsAcc += dt; this.fpsN++
    this.fpsTimer += dt
    if (this.fpsTimer > 3 && this.fpsN > 30) {
      const avg = this.fpsN / this.fpsAcc
      if (avg < 42 && this.quality < 2) {
        this.quality = (this.quality + 1) as QualityTier
        this.applyQuality()
        this.resize()
      }
      this.fpsAcc = 0; this.fpsN = 0; this.fpsTimer = 0
    }
    return dt
  }

  render() {
    this.composer.render()
  }
}
