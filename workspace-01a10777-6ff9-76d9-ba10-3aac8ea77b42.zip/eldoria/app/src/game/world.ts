// ═══ جهان: زمین، بایوم‌ها، پراکندگی نمونه‌ای، شهر الدوریا، آب و گدازه ═══
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { BIOMES } from './data'
import type { BiomeDef, BiomeId } from './data'
import { mulberry32, fbm, clamp, lerp, smoothstep } from './noise'

export interface CircleCollider { x: number; z: number; r: number }
export interface BoxCollider { minX: number; maxX: number; minZ: number; maxZ: number }

const CHUNK = 80
const ACTIVE_R = 2 // شعاع چانک‌های فعال (۲ => شبکه ۵×۵)

export const uTime = { value: 0 }

function paint(geo: THREE.BufferGeometry, c: THREE.Color | number, jitter = 0): THREE.BufferGeometry {
  const col = c instanceof THREE.Color ? c : new THREE.Color(c)
  const n = geo.attributes.position.count
  const arr = new Float32Array(n * 3)
  for (let i = 0; i < n; i++) {
    const j = jitter ? (Math.random() - 0.5) * jitter : 0
    arr[i * 3] = clamp(col.r + j, 0, 1)
    arr[i * 3 + 1] = clamp(col.g + j, 0, 1)
    arr[i * 3 + 2] = clamp(col.b + j, 0, 1)
  }
  geo.setAttribute('color', new THREE.BufferAttribute(arr, 3))
  return geo
}

// ادغام امن: هندسه‌های indexed و غیر-indexed را همگن می‌کند
function mergeAll(parts: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const normed = parts.map(p => (p.index ? p.toNonIndexed() : p))
  return mergeGeometries(normed)!
}

function swayify<T extends THREE.Material>(mat: T, strength = 1, hMax = 3): T {
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = uTime
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', `#include <common>\nuniform float uTime;\nvarying vec2 vUvSway;`)
      .replace('#include <begin_vertex>', `
        #include <begin_vertex>
        #ifdef USE_INSTANCING
          vec3 ipos = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
          float hFac = pow(clamp(position.y / ${hMax.toFixed(1)}, 0.0, 1.0), 1.6);
          float ph = ipos.x * 0.31 + ipos.z * 0.47;
          transformed.x += sin(uTime * 1.7 + ph) * hFac * ${(0.14 * strength).toFixed(3)};
          transformed.z += cos(uTime * 1.3 + ph * 1.3) * hFac * ${(0.11 * strength).toFixed(3)};
        #endif
      `)
  }
  return mat
}

// ═══ سازنده‌های هندسه ═══
function pineGeo(snowy: boolean): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const trunk = new THREE.CylinderGeometry(0.16, 0.3, 1.6, 6)
  trunk.translate(0, 0.8, 0)
  parts.push(paint(trunk, 0x5a4030, 0.04))
  const layers = [[1.5, 1.9, 1.5], [1.1, 1.6, 2.7], [0.68, 1.4, 3.8]]
  for (const [r, h, y] of layers) {
    const cone = new THREE.ConeGeometry(r, h, 7)
    cone.translate(0, y, 0)
    const c = new THREE.Color(0x1e4023)
    if (snowy) c.lerp(new THREE.Color(0xdde8f2), 0.55 + (y / 5) * 0.3)
    parts.push(paint(cone, c, 0.05))
  }
  return mergeAll(parts)
}

function broadleafGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const trunk = new THREE.CylinderGeometry(0.22, 0.42, 2.2, 6)
  trunk.translate(0, 1.1, 0)
  parts.push(paint(trunk, 0x6a4c34, 0.05))
  const blob = (x: number, y: number, z: number, r: number) => {
    const g = new THREE.IcosahedronGeometry(r, 1)
    g.scale(1, 0.82, 1)
    g.translate(x, y, z)
    parts.push(paint(g, new THREE.Color(0x2c5c28).offsetHSL(Math.random() * 0.03, 0, Math.random() * 0.05), 0.06))
  }
  blob(0, 3.1, 0, 1.6); blob(0.9, 2.6, 0.4, 1.05); blob(-0.8, 2.7, -0.4, 0.95)
  return mergeAll(parts)
}

function deadTreeGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const trunk = new THREE.CylinderGeometry(0.14, 0.4, 3.4, 5)
  trunk.translate(0, 1.7, 0)
  parts.push(paint(trunk, 0x3a3230, 0.05))
  for (let i = 0; i < 4; i++) {
    const br = new THREE.CylinderGeometry(0.05, 0.12, 1.6, 4)
    br.translate(0, 0.8, 0)
    br.rotateZ(0.7 + Math.random() * 0.7)
    br.rotateY(i * 1.7)
    br.translate(0, 1.9 + Math.random() * 1.2, 0)
    parts.push(paint(br, 0x38302c, 0.05))
  }
  return mergeAll(parts)
}

function mangroveGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const trunk = new THREE.CylinderGeometry(0.34, 0.55, 2.6, 6)
  trunk.translate(0, 1.3, 0)
  parts.push(paint(trunk, 0x4a3d30, 0.05))
  for (let i = 0; i < 5; i++) {
    const root = new THREE.CylinderGeometry(0.06, 0.14, 1.4, 4)
    root.translate(0, -0.5, 0)
    root.rotateZ(0.6)
    root.rotateY((i / 5) * Math.PI * 2)
    root.translate(0, 0.6, 0)
    parts.push(paint(root, 0x453a2e, 0.04))
  }
  const canopy = new THREE.IcosahedronGeometry(1.5, 1)
  canopy.scale(1.25, 0.55, 1.25); canopy.translate(0, 2.9, 0)
  parts.push(paint(canopy, 0x39543a, 0.06))
  return mergeAll(parts)
}

function rockGeo(): THREE.BufferGeometry {
  const g = new THREE.IcosahedronGeometry(1, 1)
  const pos = g.attributes.position
  for (let i = 0; i < pos.count; i++) {
    const v = new THREE.Vector3().fromBufferAttribute(pos as THREE.BufferAttribute, i)
    const n = fbm(v.x * 0.8 + 9, v.y * 0.8 + v.z, 2) * 0.45
    v.multiplyScalar(0.8 + n)
    pos.setXYZ(i, v.x, v.y * 0.75, v.z)
  }
  g.computeVertexNormals()
  return paint(g, 0x777474, 0.09)
}

function bushGeo(): THREE.BufferGeometry {
  const g = new THREE.IcosahedronGeometry(0.7, 1)
  g.scale(1.2, 0.7, 1.2); g.translate(0, 0.4, 0)
  return paint(g, 0x2c5526, 0.07)
}

function mushroomGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const stem = new THREE.CylinderGeometry(0.09, 0.14, 0.5, 5); stem.translate(0, 0.25, 0)
  parts.push(paint(stem, 0xd8cfae, 0.04))
  const cap = new THREE.SphereGeometry(0.36, 8, 5, 0, Math.PI * 2, 0, Math.PI / 2)
  cap.translate(0, 0.45, 0)
  parts.push(paint(cap, 0x8a4a86, 0.08))
  return mergeAll(parts)
}

function flowerGeo(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = []
  const stem = new THREE.CylinderGeometry(0.02, 0.03, 0.5, 4); stem.translate(0, 0.25, 0)
  parts.push(paint(stem, 0x3c6a2c))
  const head = new THREE.IcosahedronGeometry(0.12, 0); head.translate(0, 0.55, 0)
  parts.push(paint(head, 0xffffff))
  return mergeAll(parts)
}

function crystalGeo(): THREE.BufferGeometry {
  const g = new THREE.OctahedronGeometry(0.7, 0)
  g.scale(0.55, 1.8, 0.55); g.translate(0, 0.9, 0)
  return paint(g, 0xffffff)
}

function grassTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas'); c.width = 64; c.height = 64
  const ctx = c.getContext('2d')!
  ctx.clearRect(0, 0, 64, 64)
  for (let i = 0; i < 9; i++) {
    const x = 6 + i * 6 + Math.random() * 3
    const w = 2.4 + Math.random() * 1.6
    const h = 30 + Math.random() * 30
    const grd = ctx.createLinearGradient(0, 64, 0, 64 - h)
    grd.addColorStop(0, 'rgba(30,60,22,1)')
    grd.addColorStop(1, 'rgba(90,140,60,1)')
    ctx.fillStyle = grd
    ctx.beginPath()
    ctx.moveTo(x - w, 64)
    ctx.quadraticCurveTo(x - w * 0.3, 64 - h * 0.6, x + (Math.random() - 0.5) * 8, 64 - h)
    ctx.quadraticCurveTo(x + w * 0.3, 64 - h * 0.6, x + w, 64)
    ctx.fill()
  }
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

// ═══ آب ═══
const waterVert = /* glsl */ `
varying vec3 vWorld;
varying vec2 vUv;
void main() {
  vUv = uv;
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`
const waterFrag = /* glsl */ `
varying vec3 vWorld;
varying vec2 vUv;
uniform float uTime;
uniform vec3 uDeep;
uniform vec3 uShallow;
uniform vec3 uSky;
uniform vec3 uCam;
uniform float uNight;
void main() {
  vec2 p = vWorld.xz * 0.35;
  float w = sin(p.x * 1.4 + uTime * 1.1) * 0.5 + sin(p.y * 1.9 - uTime * 0.9) * 0.35 + sin((p.x + p.y) * 0.8 + uTime * 0.6) * 0.4;
  float w2 = sin(p.x * 3.1 - uTime * 1.7) * sin(p.y * 2.7 + uTime * 1.3);
  vec3 col = mix(uDeep, uShallow, smoothstep(-0.6, 1.0, w));
  col = mix(col, uSky, 0.22 + 0.1 * w2);
  vec3 V = normalize(uCam - vWorld);
  float fres = pow(1.0 - max(V.y, 0.0), 2.0);
  col = mix(col, uSky, fres * 0.55);
  float sparkle = smoothstep(0.965, 1.0, sin(p.x * 9.0 + uTime * 2.0) * sin(p.y * 8.0 - uTime * 1.6));
  col += vec3(1.0, 0.98, 0.9) * sparkle * (0.35 + uNight * 0.4);
  gl_FragColor = vec4(col, 0.88);
}
`

const lavaFrag = /* glsl */ `
varying vec3 vWorld;
uniform float uTime;
float h21(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn(vec2 p){
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}
void main() {
  vec2 p = vWorld.xz * 0.16;
  float n = vn(p + vec2(uTime * 0.05, uTime * 0.03)) * 0.6 + vn(p * 2.3 - vec2(uTime * 0.04, 0.0)) * 0.4;
  float pulse = 0.85 + 0.15 * sin(uTime * 1.8 + vWorld.x * 0.2);
  vec3 hot = vec3(1.0, 0.62, 0.15);
  vec3 mid = vec3(0.9, 0.28, 0.05);
  vec3 crust = vec3(0.12, 0.05, 0.03);
  vec3 col = mix(mid, hot, smoothstep(0.45, 0.85, n)) * pulse;
  col = mix(crust, col, smoothstep(0.2, 0.5, n));
  gl_FragColor = vec4(col * 1.9, 1.0);
}
`

interface ScatterItem { x: number; y: number; z: number; ry: number; s: number; tint: number }
interface Chunk {
  key: string
  cx: number; cz: number
  items: Map<string, ScatterItem[]>
  colliders: CircleCollider[]
  slots: Map<string, number[]>
}

interface Pool {
  mesh: THREE.InstancedMesh
  free: number[]
  mat4: THREE.Matrix4
}

const ZERO_M = new THREE.Matrix4().makeScale(0, 0, 0)

export class World {
  group = new THREE.Group()
  terrain!: THREE.Mesh
  waterMat!: THREE.ShaderMaterial
  lavaMat!: THREE.ShaderMaterial
  oceanMat!: THREE.ShaderMaterial
  windowMat!: THREE.MeshBasicMaterial
  lampGlowMat!: THREE.MeshBasicMaterial
  bannerMat!: THREE.MeshStandardMaterial
  lamps: THREE.Vector3[] = []
  /**
   * شعاع منطقه‌ی امن شهر الدوریا.
   * هیولاها هرگز وارد این دایره نمی‌شوند (در Enemy.update اعمال می‌شود) و
   * بازیکن داخل آن جانِ خود را بازیابی می‌کند — پس = ۵۰ با شرطِ رزنتِ
   * weight('city') > 0.4 هم‌تراز است تا «وارد شهر شدم» و «درمان شدم» یکی باشند.
   */
  readonly citySafeR = 50
  boxColliders: BoxCollider[] = []
  spawnPads: { biome: BiomeId; x: number; z: number; kind: string }[] = []
  private chunks = new Map<string, Chunk>()
  private activeKeys = new Set<string>()
  private pools = new Map<string, Pool>()
  private dummy = new THREE.Object3D()
  size = 1100

  lavaPos = new THREE.Vector3()

  constructor(scene: THREE.Scene) {
    this.buildTerrain()
    this.buildScatterPools()
    this.buildCity()
    this.buildWaterLava()
    this.planSpawns()
    scene.add(this.group)
  }

  // ─── ارتفاع زمین ───
  height(x: number, z: number): number {
    const r = Math.sqrt(x * x + z * z)
    let h = (fbm(x * 0.008 + 3.7, z * 0.008 + 9.1, 4) - 0.5) * 16
    h += (fbm(x * 0.03, z * 0.03, 2) - 0.5) * 2.2

    // کوهستان: رشته‌کوه‌های تیز
    const wm = this.weight('mountains', x, z)
    if (wm > 0) {
      const ridge = 1 - Math.abs(fbm(x * 0.012 + 40, z * 0.012, 3) * 2 - 1)
      h += ridge * ridge * 34 * wm + 6 * wm
    }
    // باتلاق: فرورفتگی زیر آب
    const ws = this.weight('swamp', x, z)
    if (ws > 0) h = lerp(h, -2.4 + (fbm(x * 0.05, z * 0.05, 2) - 0.5) * 1.4, ws * 0.92)
    // سوخته: زمین ناهموار و دهانه‌ها
    const wb = this.weight('blasted', x, z)
    if (wb > 0) h += (fbm(x * 0.02 + 80, z * 0.02, 3) - 0.5) * 9 * wb + 2 * wb
    // یخی: هموارتر و مرتفع‌تر
    const wf = this.weight('frozen', x, z)
    if (wf > 0) h = lerp(h, h * 0.6 + 3.5, wf)
    // شهر: هموار
    const wc = this.weight('city', x, z)
    if (wc > 0) h = lerp(h, 0, smoothstep(0.25, 0.85, wc))
    // لبه جهان: فرود به دریا
    if (r > 430) h = lerp(h, -7, smoothstep(440, 500, r))
    return h
  }

  weight(biome: BiomeId, x: number, z: number): number {
    const b = BIOMES.find((b) => b.id === biome)!
    const d = Math.sqrt((x - b.center[0]) ** 2 + (z - b.center[1]) ** 2)
    return smoothstep(b.radius, b.radius * 0.45, d)
  }

  dominantBiome(x: number, z: number): BiomeDef {
    let best: BiomeDef = BIOMES[0]
    let bw = 0
    for (const b of BIOMES) {
      const d = Math.sqrt((x - b.center[0]) ** 2 + (z - b.center[1]) ** 2)
      const w = b.id === 'city'
        ? smoothstep(b.radius, b.radius * 0.5, d)
        : smoothstep(b.radius, b.radius * 0.4, d)
      if (w > bw) { bw = w; best = b }
    }
    if (bw < 0.35) {
      // بین بایوم‌ها: چمنزار
      return { ...BIOMES[1], id: 'meadow' as BiomeId, name: 'چمنزارهای الدوریا', sub: 'سرزمین باز', danger: false, level: 1 }
    }
    return best
  }

  private buildTerrain() {
    const S = this.size, SEG = 236
    const geo = new THREE.PlaneGeometry(S, S, SEG, SEG)
    geo.rotateX(-Math.PI / 2)
    const pos = geo.attributes.position as THREE.BufferAttribute
    const colors = new Float32Array(pos.count * 3)
    const cGround = new THREE.Color()
    const dirt = new THREE.Color(0x8a6c4c)
    const meadow = new THREE.Color(0x34662a)
    const paths: [number, number, number, number][] = []
    for (const b of BIOMES) {
      if (b.id === 'city') continue
      paths.push([0, 0, b.center[0], b.center[1]])
    }
    const distToSeg = (px: number, pz: number, x1: number, z1: number, x2: number, z2: number) => {
      const dx = x2 - x1, dz = z2 - z1
      const t = clamp(((px - x1) * dx + (pz - z1) * dz) / (dx * dx + dz * dz), 0, 1)
      const cx = x1 + dx * t, cz = z1 + dz * t
      return Math.sqrt((px - cx) ** 2 + (pz - cz) ** 2)
    }
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i)
      const h = this.height(x, z)
      pos.setY(i, h)
      // رنگ زمین بر اساس بایوم
      cGround.copy(meadow)
      let tw = 0
      for (const b of BIOMES) {
        const w = this.weight(b.id, x, z)
        if (w > 0.01) {
          const bc = new THREE.Color(b.ground[0], b.ground[1], b.ground[2])
          if (b.id === 'city') {
            const n = fbm(x * 0.35, z * 0.35, 2)
            bc.offsetHSL(0, 0, (n - 0.5) * 0.1)
          }
          cGround.lerp(bc, Math.min(1, w * 1.15))
          tw = Math.max(tw, w)
        }
      }
      if (tw < 0.4) {
        const n = fbm(x * 0.05 + 20, z * 0.05, 2)
        cGround.lerp(new THREE.Color(0x50703a), n * 0.5)
      }
      // مسیرهای خاکی
      let pd = 1e9
      for (const p of paths) pd = Math.min(pd, distToSeg(x, z, p[0], p[1], p[2], p[3]))
      const r = Math.sqrt(x * x + z * z)
      if (r < 58) pd = Math.min(pd, r < 52 ? Math.abs(r - 40) : 1e9) // رینگ دور شهر
      const pw = smoothstep(4.2, 1.2, pd) * (0.55 + fbm(x * 0.2, z * 0.2, 2) * 0.45)
      if (pw > 0) cGround.lerp(dirt, pw * 0.75)
      const nv = (fbm(x * 0.14 + 55, z * 0.14, 2) - 0.5) * 0.09
      colors[i * 3] = clamp(cGround.r + nv, 0, 1)
      colors[i * 3 + 1] = clamp(cGround.g + nv, 0, 1)
      colors[i * 3 + 2] = clamp(cGround.b + nv, 0, 1)
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    geo.computeVertexNormals()
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.94, metalness: 0 })
    this.terrain = new THREE.Mesh(geo, mat)
    this.terrain.receiveShadow = true
    this.group.add(this.terrain)
  }

  // ─── استخرهای نمونه‌سازی ───
  private makePool(key: string, geo: THREE.BufferGeometry, mat: THREE.Material, cap: number, shadow = true) {
    const mesh = new THREE.InstancedMesh(geo, mat, cap)
    mesh.castShadow = shadow
    mesh.receiveShadow = false
    mesh.frustumCulled = false
    for (let i = 0; i < cap; i++) mesh.setMatrixAt(i, ZERO_M)
    mesh.instanceMatrix.needsUpdate = true
    this.group.add(mesh)
    this.pools.set(key, { mesh, free: Array.from({ length: cap }, (_, i) => cap - 1 - i), mat4: new THREE.Matrix4() })
  }

  private buildScatterPools() {
    const treeMat = swayify(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true }), 1, 4)
    const rockMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.96, flatShading: true })
    const bushMat = swayify(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true }), 1.6, 1)
    const grassMat = swayify(new THREE.MeshStandardMaterial({
      map: grassTexture(), alphaTest: 0.42, side: THREE.DoubleSide, roughness: 1,
    }), 2.6, 0.7)
    const crystalMat = new THREE.MeshStandardMaterial({
      color: 0x8ad8ff, emissive: 0x3aa8e8, emissiveIntensity: 0.9, roughness: 0.15, metalness: 0.1, transparent: true, opacity: 0.92,
    })
    const flowerMat = swayify(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8 }), 2, 0.6)

    const grassPlane = new THREE.PlaneGeometry(0.85, 0.7)
    grassPlane.translate(0, 0.35, 0)
    const g2 = grassPlane.clone(); g2.rotateY(Math.PI / 2)
    const grassGeo = mergeAll([grassPlane, g2])

    this.makePool('pine', pineGeo(false), treeMat, 480)
    this.makePool('snowpine', pineGeo(true), treeMat, 260)
    this.makePool('broad', broadleafGeo(), treeMat, 260)
    this.makePool('dead', deadTreeGeo(), treeMat, 190)
    this.makePool('mangrove', mangroveGeo(), treeMat, 170)
    this.makePool('rock', rockGeo(), rockMat, 340)
    this.makePool('bush', bushGeo(), bushMat, 300, false)
    this.makePool('mushroom', mushroomGeo(), bushMat, 130, false)
    this.makePool('flower', flowerGeo(), flowerMat, 200, false)
    this.makePool('crystal', crystalGeo(), crystalMat, 80, false)
    this.makePool('grass', grassGeo, grassMat, 4200, false)
  }

  // ─── تولید محتوای چانک ───
  private chunkContent(cx: number, cz: number): Chunk {
    const key = `${cx},${cz}`
    let ch = this.chunks.get(key)
    if (ch) return ch
    ch = { key, cx, cz, items: new Map(), colliders: [], slots: new Map() }
    const rng = mulberry32((cx * 73856093) ^ (cz * 19349663) ^ 0x9e3779b9)
    const x0 = cx * CHUNK, z0 = cz * CHUNK
    const add = (type: string, it: ScatterItem) => {
      if (!ch!.items.has(type)) ch!.items.set(type, [])
      ch!.items.get(type)!.push(it)
    }
    const tryPlace = (type: string, n: number, minH = -1.5, maxH = 60, colR = 0, sMin = 0.8, sMax = 1.3) => {
      for (let i = 0; i < n; i++) {
        const x = x0 + rng() * CHUNK, z = z0 + rng() * CHUNK
        if (this.weight('city', x, z) > 0.12) continue
        if (Math.sqrt(x * x + z * z) > 440) continue
        const h = this.height(x, z)
        if (h < minH || h > maxH) continue
        add(type, { x, y: h, z, ry: rng() * Math.PI * 2, s: sMin + rng() * (sMax - sMin), tint: 0.82 + rng() * 0.18 })
        if (colR > 0) ch!.colliders.push({ x, z, r: colR })
      }
    }
    // چگالی هر بایوم
    const areaDensity = (biome: BiomeId, type: string, perChunk: number, colR = 0, sMin = 0.8, sMax = 1.3, minH = -1.5) => {
      const wsum = this.weight(biome, x0 + CHUNK / 2, z0 + CHUNK / 2)
      if (wsum < 0.2) return
      tryPlace(type, Math.round(perChunk * wsum), minH, 60, colR, sMin, sMax)
    }
    areaDensity('woods', 'broad', 26, 0.55, 0.9, 1.5)
    areaDensity('woods', 'pine', 12, 0.5, 0.9, 1.4)
    areaDensity('woods', 'bush', 16, 0, 0.8, 1.4)
    areaDensity('woods', 'flower', 10)
    areaDensity('swamp', 'mangrove', 20, 0.6, 0.9, 1.5, -3)
    areaDensity('swamp', 'mushroom', 12, 0, 0.9, 1.8, -3)
    areaDensity('swamp', 'dead', 6, 0.4, 0.8, 1.2, -3)
    areaDensity('mountains', 'rock', 26, 0.8, 0.7, 2.2)
    areaDensity('mountains', 'pine', 8, 0.5, 0.8, 1.2)
    areaDensity('mountains', 'crystal', 5, 0.5, 0.7, 1.5)
    areaDensity('blasted', 'dead', 14, 0.45, 0.9, 1.6)
    areaDensity('blasted', 'rock', 16, 0.8, 0.8, 1.8)
    areaDensity('frozen', 'snowpine', 24, 0.55, 0.9, 1.6)
    areaDensity('frozen', 'rock', 10, 0.8, 0.7, 1.6)
    areaDensity('frozen', 'crystal', 4, 0.5, 0.8, 1.6)
    // چمنزار بین بایوم‌ها
    const wc = this.weight('city', x0 + CHUNK / 2, z0 + CHUNK / 2)
    let wild = 1
    for (const b of BIOMES) wild -= this.weight(b.id, x0 + CHUNK / 2, z0 + CHUNK / 2) * 0.9
    if (wild > 0.3 && wc < 0.3) {
      tryPlace('broad', Math.round(8 * wild), -1.5, 40, 0.55, 0.9, 1.5)
      tryPlace('bush', Math.round(10 * wild))
      tryPlace('flower', Math.round(8 * wild))
      tryPlace('rock', Math.round(4 * wild), -1.5, 40, 0.7, 0.6, 1.4)
    }
    // چمن همه‌جا
    const swampy = this.weight('swamp', x0 + CHUNK / 2, z0 + CHUNK / 2)
    const blast = this.weight('blasted', x0 + CHUNK / 2, z0 + CHUNK / 2)
    const froz = this.weight('frozen', x0 + CHUNK / 2, z0 + CHUNK / 2)
    const gn = Math.round(150 * (1 - blast) * (1 - froz * 0.85) * (1 - swampy * 0.7) * (1 - wc))
    tryPlace('grass', gn, -0.9, 40)
    this.chunks.set(key, ch)
    return ch
  }

  private activateChunk(cx: number, cz: number) {
    const ch = this.chunkContent(cx, cz)
    for (const [type, items] of ch.items) {
      const pool = this.pools.get(type)
      if (!pool) continue
      const slots: number[] = []
      for (const it of items) {
        const slot = pool.free.pop()
        if (slot === undefined) break
        this.dummy.position.set(it.x, it.y, it.z)
        this.dummy.rotation.set(0, it.ry, 0)
        this.dummy.scale.setScalar(it.s)
        this.dummy.updateMatrix()
        pool.mesh.setMatrixAt(slot, this.dummy.matrix)
        slots.push(slot)
      }
      ch.slots.set(type, slots)
      pool.mesh.instanceMatrix.needsUpdate = true
    }
    this.activeKeys.add(ch.key)
  }

  private deactivateChunk(key: string) {
    const ch = this.chunks.get(key)
    if (!ch) return
    for (const [type, slots] of ch.slots) {
      const pool = this.pools.get(type)
      if (!pool) continue
      for (const s of slots) {
        pool.mesh.setMatrixAt(s, ZERO_M)
        pool.free.push(s)
      }
      pool.mesh.instanceMatrix.needsUpdate = true
    }
    ch.slots.clear()
    this.activeKeys.delete(key)
  }

  update(px: number, pz: number) {
    const pcx = Math.floor(px / CHUNK), pcz = Math.floor(pz / CHUNK)
    const want = new Set<string>()
    for (let dx = -ACTIVE_R; dx <= ACTIVE_R; dx++)
      for (let dz = -ACTIVE_R; dz <= ACTIVE_R; dz++) want.add(`${pcx + dx},${pcz + dz}`)
    for (const key of [...this.activeKeys]) if (!want.has(key)) this.deactivateChunk(key)
    for (const key of want) {
      if (!this.activeKeys.has(key)) {
        const [cx, cz] = key.split(',').map(Number)
        this.activateChunk(cx, cz)
      }
    }
  }

  collidersNear(x: number, z: number, out: CircleCollider[]): CircleCollider[] {
    out.length = 0
    const cx = Math.floor(x / CHUNK), cz = Math.floor(z / CHUNK)
    for (let dx = -1; dx <= 1; dx++)
      for (let dz = -1; dz <= 1; dz++) {
        const ch = this.chunks.get(`${cx + dx},${cz + dz}`)
        if (ch && this.activeKeys.has(ch.key)) out.push(...ch.colliders)
      }
    return out
  }

  // ─── آب و گدازه ═══
  private buildWaterLava() {
    this.waterMat = new THREE.ShaderMaterial({
      vertexShader: waterVert, fragmentShader: waterFrag, transparent: true, depthWrite: false,
      uniforms: {
        uTime, uDeep: { value: new THREE.Color(0x14302a) }, uShallow: { value: new THREE.Color(0x2c5540) },
        uSky: { value: new THREE.Color(0x9fb8cc) }, uCam: { value: new THREE.Vector3() }, uNight: { value: 0 },
      },
    })
    const sw = BIOMES.find((b) => b.id === 'swamp')!
    const pond = new THREE.Mesh(new THREE.CircleGeometry(sw.radius * 0.9, 40), this.waterMat)
    pond.rotation.x = -Math.PI / 2
    pond.position.set(sw.center[0], -0.85, sw.center[1])
    this.group.add(pond)

    this.oceanMat = this.waterMat.clone()
    this.oceanMat.uniforms.uTime = uTime
    ;(this.oceanMat.uniforms.uDeep.value as THREE.Color).set(0x0c2438)
    ;(this.oceanMat.uniforms.uShallow.value as THREE.Color).set(0x1c4660)
    const ocean = new THREE.Mesh(new THREE.CircleGeometry(1200, 48), this.oceanMat)
    ocean.rotation.x = -Math.PI / 2
    ocean.position.y = -3.4
    this.group.add(ocean)

    this.lavaMat = new THREE.ShaderMaterial({
      vertexShader: waterVert, fragmentShader: lavaFrag,
      uniforms: { uTime },
    })
    const bl = BIOMES.find((b) => b.id === 'blasted')!
    const lava = new THREE.Mesh(new THREE.CircleGeometry(26, 32), this.lavaMat)
    lava.rotation.x = -Math.PI / 2
    const lh = this.height(bl.center[0] + 20, bl.center[1] + 15)
    lava.position.set(bl.center[0] + 20, lh - 0.7, bl.center[1] + 15)
    lava.userData.isLava = true
    this.group.add(lava)
    this.lavaPos = new THREE.Vector3(bl.center[0] + 20, lh, bl.center[1] + 15)
    // جریان گدازه دوم
    const lava2 = new THREE.Mesh(new THREE.CircleGeometry(14, 24), this.lavaMat)
    lava2.rotation.x = -Math.PI / 2
    const lx = bl.center[0] - 40, lz = bl.center[1] + 45
    lava2.position.set(lx, this.height(lx, lz) - 0.6, lz)
    this.group.add(lava2)
  }

  private planSpawns() {
    const spec: [BiomeId, string, number][] = [
      ['woods', 'wolf', 10], ['woods', 'spider', 7], ['woods', 'troll', 1],
      ['swamp', 'slime', 12], ['swamp', 'broodmother', 1],
      ['mountains', 'orc', 9], ['mountains', 'golem', 7], ['mountains', 'ettin', 1],
      ['blasted', 'firelizard', 9], ['blasted', 'drake', 6], ['blasted', 'lavagolem', 1],
      ['frozen', 'bear', 8], ['frozen', 'frost', 7], ['frozen', 'frostgiant', 1],
    ]
    const rng = mulberry32(1234567)
    for (const [biome, kind, n] of spec) {
      const b = BIOMES.find((x) => x.id === biome)!
      for (let i = 0; i < n; i++) {
        const a = rng() * Math.PI * 2
        const r = b.radius * (0.25 + rng() * 0.6)
        const x = b.center[0] + Math.cos(a) * r
        const z = b.center[1] + Math.sin(a) * r
        if (this.height(x, z) < -1.2) { i--; continue }
        this.spawnPads.push({ biome, x, z, kind })
      }
    }
  }

  // ═══ شهر الدوریا ═══
  private buildCity() {
    const city = new THREE.Group()
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x9a8f7c, roughness: 0.9, flatShading: true })
    const plasterMat = new THREE.MeshStandardMaterial({ color: 0xcfc3a4, roughness: 0.92, flatShading: true })
    const timberMat = new THREE.MeshStandardMaterial({ color: 0x4a3826, roughness: 0.9, flatShading: true })
    const roofRed = new THREE.MeshStandardMaterial({ color: 0x8a3b2a, roughness: 0.85, flatShading: true })
    const roofBlue = new THREE.MeshStandardMaterial({ color: 0x3d5470, roughness: 0.85, flatShading: true })
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x7a5c38, roughness: 0.9, flatShading: true })
    this.windowMat = new THREE.MeshBasicMaterial({ color: 0xffc46a, transparent: true, opacity: 0 })
    this.lampGlowMat = new THREE.MeshBasicMaterial({ color: 0xffd890, transparent: true, opacity: 0.25 })

    const stoneParts: THREE.BufferGeometry[] = []
    const plasterParts: THREE.BufferGeometry[] = []
    const timberParts: THREE.BufferGeometry[] = []
    const roofRParts: THREE.BufferGeometry[] = []
    const roofBParts: THREE.BufferGeometry[] = []
    const woodParts: THREE.BufferGeometry[] = []
    const windowParts: THREE.BufferGeometry[] = []

    const box = (arr: THREE.BufferGeometry[], w: number, h: number, d: number, x: number, y: number, z: number, ry = 0) => {
      const g = new THREE.BoxGeometry(w, h, d)
      g.rotateY(ry); g.translate(x, y, z)
      arr.push(g)
    }
    const prism = (arr: THREE.BufferGeometry[], w: number, h: number, d: number, x: number, y: number, z: number, ry = 0) => {
      const shape = new THREE.Shape()
      shape.moveTo(-w / 2, 0); shape.lineTo(w / 2, 0); shape.lineTo(0, h); shape.closePath()
      const g = new THREE.ExtrudeGeometry(shape, { depth: d, bevelEnabled: false })
      g.translate(0, 0, -d / 2)
      g.rotateY(ry); g.translate(x, y, z)
      arr.push(g)
    }

    const house = (x: number, z: number, ry: number, w: number, d: number, hh: number, blue: boolean) => {
      const y = this.height(x, z)
      const walls: THREE.BufferGeometry[] = []
      box(walls, w, hh, d, 0, hh / 2, 0)
      const roofArr = blue ? roofBParts : roofRParts
      const rParts: THREE.BufferGeometry[] = []
      prism(rParts, w + 0.9, hh * 0.62, d + 0.9, 0, hh, 0)
      const tParts: THREE.BufferGeometry[] = []
      box(tParts, w + 0.12, 0.22, 0.22, 0, hh * 0.45, d / 2 + 0.01)
      box(tParts, w + 0.12, 0.22, 0.22, 0, hh * 0.9, d / 2 + 0.01)
      box(tParts, 0.22, hh, 0.22, -w / 2 + 0.1, hh / 2, d / 2 + 0.01)
      box(tParts, 0.22, hh, 0.22, w / 2 - 0.1, hh / 2, d / 2 + 0.01)
      box(tParts, 1.1, 1.9, 0.24, w * 0.18, 0.95, d / 2 + 0.02)
      const wParts: THREE.BufferGeometry[] = []
      box(wParts, 0.8, 0.8, 0.1, -w * 0.25, hh * 0.62, d / 2 + 0.03)
      box(wParts, 0.7, 0.7, 0.1, w * 0.3, hh * 0.62, -d / 2 - 0.03)
      const rot = new THREE.Matrix4().makeRotationY(ry)
      const tr = new THREE.Matrix4().makeTranslation(x, y, z)
      const m = tr.multiply(rot)
      for (const g of walls) { g.applyMatrix4(m); plasterParts.push(g) }
      for (const g of rParts) { g.applyMatrix4(m); roofArr.push(g) }
      for (const g of tParts) { g.applyMatrix4(m); timberParts.push(g) }
      for (const g of wParts) { g.applyMatrix4(m); windowParts.push(g) }
      this.boxColliders.push(this.aabbOf(x, z, w, d, ry))
    }

    // حلقه خانه‌ها
    const ringSpec: [number, number, number, number, number, number, boolean][] = [
      [-14, 26, 0.3, 7, 6, 4.5, false], [14, 27, -0.4, 6, 6, 4.2, false],
      [-26, 14, 1.1, 6, 5, 4, true], [-28, -6, 1.6, 7, 6, 4.6, false],
      [-22, -22, 2.2, 6, 6, 4.2, false], [24, -24, -2.2, 7, 5, 4.4, true],
      [28, 6, -1.5, 6, 6, 4.2, false], [-6, 34, 0.05, 8, 6, 5, false],
      [30, -12, -1.2, 5, 5, 3.8, false], [-32, 20, 0.9, 5, 5, 3.8, true],
    ]
    for (const [x, z, ry, w, d, hh, blue] of ringSpec) house(x, z, ry, w, d, hh, blue)

    // تالار گیلد (شمال)
    {
      const y = this.height(0, 34)
      const w = 13, d = 9, hh = 7
      const p: THREE.BufferGeometry[] = []
      box(p, w, hh, d, 0, hh / 2, 0)
      for (const g of p) { g.translate(0, y, 34); plasterParts.push(g) }
      const rp: THREE.BufferGeometry[] = []
      prism(rp, w + 1.4, 4, d + 1.4, 0, 0, 0)
      for (const g of rp) { g.translate(0, y + hh, 34); roofBParts.push(g) }
      for (const cx of [-w / 2 + 1, 0, w / 2 - 1]) {
        const col = new THREE.CylinderGeometry(0.4, 0.45, hh, 8)
        col.translate(cx, y + hh / 2, 34 - d / 2 - 0.8)
        stoneParts.push(col)
      }
      this.boxColliders.push({ minX: -w / 2 - 1, maxX: w / 2 + 1, minZ: 34 - d / 2 - 1.4, maxZ: 34 + d / 2 })
    }

    // آرنا (جنوب): سکوی دایره‌ای + ستون‌ها
    {
      const ax = 0, az = -44
      const y = this.height(ax, az)
      const base = new THREE.CylinderGeometry(13, 14, 1.2, 22)
      base.translate(ax, y + 0.6, az)
      stoneParts.push(base)
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2
        const col = new THREE.CylinderGeometry(0.5, 0.6, 5, 7)
        col.translate(ax + Math.cos(a) * 12, y + 3.6, az + Math.sin(a) * 12)
        stoneParts.push(col)
        const cap = new THREE.BoxGeometry(1.6, 0.5, 1.6)
        cap.translate(ax + Math.cos(a) * 12, y + 6.3, az + Math.sin(a) * 12)
        stoneParts.push(cap)
      }
      this.boxColliders.push({ minX: ax - 14.5, maxX: ax - 12.5, minZ: az - 14.5, maxZ: az + 14.5 })
      this.boxColliders.push({ minX: ax + 12.5, maxX: ax + 14.5, minZ: az - 14.5, maxZ: az + 14.5 })
      this.boxColliders.push({ minX: ax - 14.5, maxX: ax + 14.5, minZ: az - 14.5, maxZ: az - 12.5 })
      this.boxColliders.push({ minX: ax - 14.5, maxX: ax + 14.5, minZ: az + 12.5, maxZ: az + 14.5 })
    }

    // فواره مرکزی
    {
      const basin = new THREE.CylinderGeometry(3.4, 3.8, 1, 14)
      basin.translate(0, 0.5, 0)
      stoneParts.push(basin)
      const inner = new THREE.CylinderGeometry(0.5, 0.7, 2.2, 8)
      inner.translate(0, 1.6, 0)
      stoneParts.push(inner)
      const top = new THREE.CylinderGeometry(1.2, 1.2, 0.3, 10)
      top.translate(0, 2.8, 0)
      stoneParts.push(top)
      this.boxColliders.push({ minX: -3.6, maxX: 3.6, minZ: -3.6, maxZ: 3.6 })
    }

    // غرفه‌های بازار
    const stall = (x: number, z: number, ry: number, colorA: THREE.BufferGeometry[], colorB: THREE.BufferGeometry[]) => {
      const y = this.height(x, z)
      const parts: THREE.BufferGeometry[] = []
      for (const [dx, dz] of [[-1.6, -1.1], [1.6, -1.1], [-1.6, 1.1], [1.6, 1.1]]) {
        const p = new THREE.CylinderGeometry(0.09, 0.11, 2.4, 5)
        p.translate(dx, 1.2, dz)
        parts.push(p)
      }
      const counter = new THREE.BoxGeometry(3.4, 0.8, 1.6)
      counter.translate(0, 0.5, 0.4)
      parts.push(counter)
      const awn = new THREE.BoxGeometry(4, 0.12, 2.8)
      awn.rotateX(-0.18)
      awn.translate(0, 2.5, 0)
      const rot = new THREE.Matrix4().makeRotationY(ry)
      const tr = new THREE.Matrix4().makeTranslation(x, y, z)
      const m = tr.multiply(rot)
      for (const g of parts) { g.applyMatrix4(m); colorA.push(g) }
      awn.applyMatrix4(m); colorB.push(awn)
      this.boxColliders.push(this.aabbOf(x, z, 3.6, 2.4, ry))
    }
    const awnRed: THREE.BufferGeometry[] = []
    const awnBlue: THREE.BufferGeometry[] = []
    stall(9, -14, 0.5, woodParts, awnRed)
    stall(13, -11, 1.1, woodParts, awnBlue)
    stall(9, -19, -0.3, woodParts, awnRed)

    // چراغ‌های شهر
    const lampPosts: [number, number][] = [[6, 6], [-6, 6], [6, -6], [-6, -6], [18, 0], [-18, 0], [0, 18], [0, -18], [12, 20], [-12, 20], [20, -18], [-20, -14]]
    for (const [x, z] of lampPosts) {
      const y = this.height(x, z)
      const post = new THREE.CylinderGeometry(0.09, 0.13, 3.4, 6)
      post.translate(x, y + 1.7, z)
      timberParts.push(post)
      const lamp = new THREE.SphereGeometry(0.26, 8, 6)
      lamp.translate(x, y + 3.5, z)
      windowParts.push(lamp)
      this.lamps.push(new THREE.Vector3(x, y + 3.5, z))
    }

    // پرچم‌ها
    this.bannerMat = swayify(new THREE.MeshStandardMaterial({ color: 0x8a2e2e, roughness: 0.8, side: THREE.DoubleSide }), 3.2, 2.2)
    const banners = new THREE.Group()
    for (const [x, z] of [[4, 30], [-4, 30], [14, 12], [-14, -12]]) {
      const y = this.height(x, z)
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 5.4, 6), timberMat)
      pole.position.set(x, y + 2.7, z)
      pole.castShadow = true
      const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 2.2, 6, 4), this.bannerMat)
      flag.position.set(x + 0.9, y + 4.2, z)
      banners.add(pole, flag)
    }
    city.add(banners)

    const addMerged = (parts: THREE.BufferGeometry[], mat: THREE.Material, shadow = true) => {
      if (!parts.length) return
      const g = mergeAll(parts)
      const mesh = new THREE.Mesh(g, mat)
      mesh.castShadow = shadow
      mesh.receiveShadow = true
      city.add(mesh)
    }
    addMerged(stoneParts, stoneMat)
    addMerged(plasterParts, plasterMat)
    addMerged(timberParts, timberMat)
    addMerged(roofRParts, roofRed)
    addMerged(roofBParts, roofBlue)
    addMerged(woodParts, woodMat)
    addMerged(awnRed, new THREE.MeshStandardMaterial({ color: 0xa03c30, roughness: 0.9, side: THREE.DoubleSide }))
    addMerged(awnBlue, new THREE.MeshStandardMaterial({ color: 0x3a5a80, roughness: 0.9, side: THREE.DoubleSide }))
    addMerged(windowParts, this.windowMat, false)

    this.group.add(city)
    this.buildCityLabels(city)
  }

  private aabbOf(x: number, z: number, w: number, d: number, ry: number): BoxCollider {
    const c = Math.abs(Math.cos(ry)), s = Math.abs(Math.sin(ry))
    const hw = (w * c + d * s) / 2 + 0.2
    const hd = (w * s + d * c) / 2 + 0.2
    return { minX: x - hw, maxX: x + hw, minZ: z - hd, maxZ: z + hd }
  }

  private buildCityLabels(parent: THREE.Group) {
    const labels: [string, number, number, number][] = [
      ['تالار گیلد', 0, 43, 12.4], ['آرنای قهرمانان', 0, -44, 9.5], ['بازار', 11, -15, 4.6],
      ['مسافرخانه ماجراجوی خسته', -8, -19, 6.4], ['میدان شهر', 0, 0, 5.4],
    ]
    for (const [text, x, z, y] of labels) {
      const spr = makeLabel(text, '#f4ecd8', 'rgba(20,16,10,0.72)')
      spr.position.set(x, y, z)
      parent.add(spr)
    }
  }

  setNight(night: number) {
    this.windowMat.opacity = night
    this.lampGlowMat.opacity = 0.15 + night * 0.5
    ;(this.waterMat.uniforms.uNight as { value: number }).value = night
  }
}

export function makeLabel(text: string, fg = '#f4ecd8', bg = 'rgba(20,16,10,0.7)', scale = 1): THREE.Sprite {
  const pad = 18
  const c = document.createElement('canvas')
  const ctx = c.getContext('2d')!
  const fs = 34
  ctx.font = `700 ${fs}px Vazirmatn, sans-serif`
  const w = Math.ceil(ctx.measureText(text).width) + pad * 2
  c.width = w; c.height = 64
  const ctx2 = c.getContext('2d')!
  ctx2.fillStyle = bg
  ctx2.beginPath()
  ctx2.roundRect(0, 6, w, 52, 12)
  ctx2.fill()
  ctx2.strokeStyle = 'rgba(232,182,74,0.55)'
  ctx2.lineWidth = 2
  ctx2.stroke()
  ctx2.font = `700 ${fs}px Vazirmatn, sans-serif`
  ctx2.textAlign = 'center'
  ctx2.textBaseline = 'middle'
  ctx2.fillStyle = fg
  ctx2.fillText(text, w / 2, 33)
  const tex = new THREE.CanvasTexture(c)
  tex.colorSpace = THREE.SRGBColorSpace
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false })
  const spr = new THREE.Sprite(mat)
  spr.scale.set((w / 64) * 1.35 * scale, 1.35 * scale, 1)
  return spr
}
