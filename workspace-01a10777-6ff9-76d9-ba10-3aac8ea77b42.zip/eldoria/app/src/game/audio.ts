// ═══ صدا: سنتز WebAudio — افکت‌ها و موسیقی محیطی ═══

export class AudioSys {
  ctx: AudioContext | null = null
  master!: GainNode
  sfxGain!: GainNode
  musicGain!: GainNode
  muted = false
  private started = false

  /** اگر WebAudio در دسترس نباشد، بازی باید بی‌صدا ولی سالم ادامه پیدا کند */
  private broken = false

  init() {
    if (this.ctx || this.broken) return
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!AC) { this.broken = true; return }
      this.ctx = new AC()
      this.master = this.ctx.createGain()
      this.master.gain.value = 0.8
      this.master.connect(this.ctx.destination)
      this.sfxGain = this.ctx.createGain()
      this.sfxGain.gain.value = 0.9
      this.sfxGain.connect(this.master)
      this.musicGain = this.ctx.createGain()
      this.musicGain.gain.value = 0.32
      this.musicGain.connect(this.master)
    } catch {
      this.broken = true
      this.ctx = null
    }
  }

  start() {
    if (this.started) return
    this.started = true
    try {
      this.init()
      if (!this.ctx) return
      void this.ctx.resume()
      this.startWind()
      this.startMusic()
    } catch {
      this.broken = true
    }
  }

  setMuted(m: boolean) {
    this.muted = m
    if (this.ctx) this.master.gain.value = m ? 0 : 0.8
  }

  private noiseBuffer(dur = 2): AudioBuffer {
    const ctx = this.ctx!
    const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate)
    const d = buf.getChannelData(0)
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1
    return buf
  }

  private startWind() {
    const ctx = this.ctx!
    const src = ctx.createBufferSource()
    src.buffer = this.noiseBuffer(4)
    src.loop = true
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.value = 320
    const g = ctx.createGain()
    g.gain.value = 0.05
    const lfo = ctx.createOscillator()
    lfo.frequency.value = 0.13
    const lfoG = ctx.createGain()
    lfoG.gain.value = 0.025
    lfo.connect(lfoG)
    lfoG.connect(g.gain)
    src.connect(lp); lp.connect(g); g.connect(this.musicGain)
    src.start(); lfo.start()
  }

  private startMusic() {
    const ctx = this.ctx!
    // پد مولد: آکوردهای مینور آرام
    const chords = [
      [110, 130.8, 164.8], // Am
      [87.3, 110, 130.8], // F
      [98, 123.5, 146.8], // G
      [82.4, 98, 123.5],  // Em
    ]
    let step = 0
    const playChord = () => {
      if (!this.ctx || this.muted) { step++; return }
      const chord = chords[step % chords.length]
      step++
      const now = ctx.currentTime
      for (const f of chord) {
        for (const det of [0, 3]) {
          const o = ctx.createOscillator()
          o.type = 'triangle'
          o.frequency.value = f
          o.detune.value = det - 1.5
          const g = ctx.createGain()
          g.gain.setValueAtTime(0, now)
          g.gain.linearRampToValueAtTime(0.045, now + 2.2)
          g.gain.linearRampToValueAtTime(0, now + 6.4)
          const lp = ctx.createBiquadFilter()
          lp.type = 'lowpass'
          lp.frequency.value = 900
          o.connect(g); g.connect(lp); lp.connect(this.musicGain)
          o.start(now); o.stop(now + 6.6)
        }
      }
    }
    playChord()
    window.setInterval(playChord, 6200)
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0) {
    if (!this.ctx || this.muted) return
    const ctx = this.ctx
    const now = ctx.currentTime + delay
    const o = ctx.createOscillator()
    o.type = type
    o.frequency.setValueAtTime(freq, now)
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 20), now + dur)
    const g = ctx.createGain()
    g.gain.setValueAtTime(vol, now)
    g.gain.exponentialRampToValueAtTime(0.001, now + dur)
    o.connect(g); g.connect(this.sfxGain)
    o.start(now); o.stop(now + dur + 0.05)
  }

  private noise(dur: number, vol: number, filterFreq: number, type: BiquadFilterType = 'bandpass', slideTo?: number) {
    if (!this.ctx || this.muted) return
    const ctx = this.ctx
    const now = ctx.currentTime
    const src = ctx.createBufferSource()
    src.buffer = this.noiseBuffer(Math.max(dur, 0.2))
    const f = ctx.createBiquadFilter()
    f.type = type
    f.frequency.setValueAtTime(filterFreq, now)
    if (slideTo) f.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 30), now + dur)
    f.Q.value = 1.1
    const g = ctx.createGain()
    g.gain.setValueAtTime(vol, now)
    g.gain.exponentialRampToValueAtTime(0.001, now + dur)
    src.connect(f); f.connect(g); g.connect(this.sfxGain)
    src.start(now); src.stop(now + dur + 0.05)
  }

  swing() { this.noise(0.16, 0.3, 2400, 'bandpass', 500) }
  shoot() { this.noise(0.14, 0.22, 3200, 'highpass'); this.tone(880, 0.1, 'sine', 0.12, 320) }
  hit() { this.noise(0.12, 0.42, 300, 'lowpass'); this.tone(140, 0.12, 'square', 0.16, 60) }
  crit() { this.noise(0.2, 0.5, 380, 'lowpass'); this.tone(220, 0.2, 'sawtooth', 0.2, 55); this.tone(1240, 0.09, 'square', 0.07, 900, 0.01) }
  hurt() { this.tone(190, 0.22, 'sawtooth', 0.22, 80); this.noise(0.18, 0.3, 260, 'lowpass') }
  fireball() { this.noise(0.5, 0.3, 900, 'bandpass', 160); this.tone(320, 0.4, 'sawtooth', 0.1, 90) }
  frost() { this.noise(0.4, 0.26, 5200, 'highpass'); this.tone(1480, 0.32, 'sine', 0.1, 520) }
  bolt() { this.noise(0.22, 0.34, 4200, 'highpass', 900); this.tone(1720, 0.14, 'square', 0.06, 300) }
  boom() { this.noise(0.7, 0.55, 220, 'lowpass'); this.tone(90, 0.6, 'sine', 0.4, 32) }
  coin() { this.tone(1320, 0.08, 'square', 0.09); this.tone(1760, 0.14, 'square', 0.08, undefined, 0.07) }
  potion() { this.tone(520, 0.1, 'sine', 0.12, 760); this.tone(760, 0.14, 'sine', 0.1, 1040, 0.09) }
  levelup() { [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.34, 'triangle', 0.16, undefined, i * 0.11)) }
  quest() { [392, 523, 659].forEach((f, i) => this.tone(f, 0.3, 'triangle', 0.13, undefined, i * 0.13)) }
  die() { this.tone(160, 0.5, 'sawtooth', 0.2, 40); this.noise(0.5, 0.3, 200, 'lowpass') }
  growl() { this.tone(95, 0.4, 'sawtooth', 0.14, 60); this.noise(0.35, 0.14, 240, 'lowpass') }
  click() { this.tone(660, 0.06, 'square', 0.08, 520) }
  dash() { this.noise(0.24, 0.2, 1600, 'bandpass', 300) }
  step(run: boolean) { this.noise(0.07, run ? 0.09 : 0.05, 400 + Math.random() * 300, 'lowpass') }
  buff() { this.tone(440, 0.3, 'triangle', 0.12, 880); this.tone(660, 0.34, 'triangle', 0.1, 1320, 0.1) }
}
