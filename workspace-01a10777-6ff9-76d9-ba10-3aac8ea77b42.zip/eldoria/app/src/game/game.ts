// ═══ ارکستر اصلی بازی ═══
import * as THREE from 'three'
import { Engine } from './engine'
import { Sky } from './sky'
import { World, uTime } from './world'
import { Player, screenDirToWorld } from './player'
import { EnemyManager, Enemy, Companion } from './enemies'
import { VFX } from './vfx'
import { AudioSys } from './audio'
import { CLASSES, QUESTS, NPCS, TIPS, xpForLevel, SAVE_KEY } from './data'
import type { ClassDef, ClassId } from './data'
import { useGame } from './state'
import type { QuestState } from './state'
import { damp, lerp, faNum } from './noise'
import { buildNPC, disposeObject, std } from './charactergfx'
import { makeLabel } from './world'
import { loadRaw, saveRaw, loadJson, persistentStorage } from './storage'
import { pad } from './gamepad'

export const touch = { mx: 0, mz: 0, sprint: false }

// بردارها/رنگ‌های بازاستفاده‌شدنی (بدون تخصیص در هر فریم)
const MOVE_VEC = new THREE.Vector2()
const ZERO_MOVE = new THREE.Vector2(0, 0)
const _fogC = new THREE.Color()
const _nightC = new THREE.Color(0x0c1420)
const _whiteC = new THREE.Color(0xffffff)
const _lampOrder: THREE.Vector3[] = []
const ROLL_IN = new THREE.Vector2()
const ROLL_DIR = new THREE.Vector3()

interface Projectile {
  alive: boolean
  mesh: THREE.Mesh
  pos: THREE.Vector3
  dir: THREE.Vector3
  speed: number
  dmg: number
  aoe: number
  color: number
  life: number
  gravity: number
  heavy: boolean
}

interface Pickup {
  mesh: THREE.Mesh
  kind: 'gold' | 'potion' | 'xp'
  value: number
  vel: THREE.Vector3
  t: number
  magnet: boolean
}

/** شکل داده‌ی ذخیره‌شده — همه‌ی فیلدها اختیاری‌اند چون فایل ذخیره می‌تواند کهنه یا ناقص باشد */
interface SavedGame {
  classId?: ClassId
  level?: number
  xp?: number
  gold?: number
  potions?: number
  kills?: number
  quests?: { id: string; count: number; status: QuestState['status'] }[]
  pos?: [number, number]
}

interface NpcEnt {
  id: string
  name: string
  role: string
  group: THREE.Group
  body: THREE.Group
  pos: THREE.Vector3
  questIds: string[]
  marker: THREE.Sprite
  greet: string
}

export class Game {
  engine: Engine
  sky: Sky
  world: World
  vfx: VFX
  audio = new AudioSys()
  player!: Player
  enemies: EnemyManager
  companion: Companion | null = null
  cls: ClassDef = CLASSES[0]

  private keys = new Set<string>()
  private projectiles: Projectile[] = []
  private pickups: Pickup[] = []
  private npcs: NpcEnt[] = []
  private lampLights: THREE.PointLight[] = []
  private playerLight: THREE.PointLight
  private flashLight: THREE.PointLight
  private fog: THREE.Fog
  private camOrbitT = 0
  private lastBiome = ''
  private saveTimer = 0
  private cdPush = 0
  private interactTarget: NpcEnt | null = null
  private potionCd = 0
  private buffT = 0
  private atkBuff = 1
  private pendingMeteors: { pos: THREE.Vector3; t: number }[] = []
  private volleys: { pos: THREE.Vector3; t: number; n: number }[] = []
  private lastTarget: Enemy | null = null
  private dragging = false
  private dragMoved = 0
  private lastTouchLook = { x: 0, y: 0 }
  // ⚡ منبع حقیقتِ جان و مانا اینجاست (نه در استور).
  // استور فقط یک «نما» برای HUD است و با نرخ محدود همگام می‌شود تا
  // رندر مجدد React در هر فریم رخ ندهد.
  private hp = 100
  private mana = 50
  private hpMax = 100
  private manaMax = 50
  private vitalAcc = 0
  private cds = [0, 0, 0, 0]
  private cdDirty = false
  paused = false
  running = false
  private canvas: HTMLCanvasElement

  constructor(canvas: HTMLCanvasElement, dmgLayer: HTMLDivElement) {
    this.canvas = canvas
    this.engine = new Engine(canvas)
    this.world = new World(this.engine.scene)
    this.sky = new Sky(this.engine.scene)
    this.vfx = new VFX(this.engine.scene, dmgLayer, this.engine.isMobile)
    this.fog = new THREE.Fog(0xb8c8dc, 60, 380)
    this.engine.scene.fog = this.fog

    this.playerLight = new THREE.PointLight(0xffc890, 0, 14, 1.6)
    this.engine.scene.add(this.playerLight)
    this.flashLight = new THREE.PointLight(0xffa050, 0, 18, 1.4)
    this.engine.scene.add(this.flashLight)
    for (let i = 0; i < 4; i++) {
      const l = new THREE.PointLight(0xffb866, 0, 13, 1.7)
      this.lampLights.push(l)
      this.engine.scene.add(l)
    }

    this.enemies = new EnemyManager({
      world: this.world,
      vfx: this.vfx,
      onPlayerHit: (dmg, from) => this.playerHurt(dmg, from),
      onKill: (e) => this.onEnemyKill(e),
      onAggro: (e) => { if (e.def.boss) this.audio.growl() },
    }, this.engine.scene)

    this.bindInput()
    this.buildNpcs()
    this.engine.scene.background = new THREE.Color(0x0d0b08)
    // ⚠️ این خط پیش‌تر بدون محافظ بود و در iframe سندباکس‌شده استثنا پرتاب
    // می‌کرد که به صفحه‌ی سفید منتهی می‌شد.
    useGame.getState().set({ hasSave: !!loadRaw(SAVE_KEY) })
    if (!persistentStorage) {
      useGame.getState().set({ toast: 'ذخیره‌سازی در این مرورگر ممکن نیست — پیشرفت نگه داشته نمی‌شود.' })
    }
  }

  // ═══ ورودی ═══
  private bindInput() {
    window.addEventListener('keydown', (e) => {
      if (e.repeat) return
      const k = e.key.toLowerCase()
      this.keys.add(k)
      this.markInput('kb')
      const st = useGame.getState()
      if (st.phase !== 'playing') return
      if (k === ' ') { e.preventDefault(); this.keys.add('jump') }
      if (k === 'e') this.tryInteract()
      if (k === 'h' || k === 'q') this.drinkPotion()
      if (k === 'm') this.toggleMute()
      if (k === 'escape') { if (st.dialog) st.set({ dialog: null }) }
      const sk = { '1': 0, '2': 1, '3': 2, '4': 3 }[k]
      if (sk !== undefined) this.castSkill(sk)
    })
    window.addEventListener('keyup', (e) => {
      const k = e.key.toLowerCase()
      this.keys.delete(k)
      if (k === ' ') this.keys.delete('jump')
    })
    this.canvas.addEventListener('mousedown', (e) => {
      this.dragging = true
      this.dragMoved = 0
      this.audio.start()
      e.preventDefault()
    })
    window.addEventListener('mousemove', (e) => {
      if (!this.dragging || useGame.getState().phase !== 'playing') return
      this.player?.look(e.movementX, e.movementY)
      this.dragMoved += Math.abs(e.movementX) + Math.abs(e.movementY)
    })
    window.addEventListener('mouseup', () => {
      if (this.dragging && this.dragMoved < 7 && useGame.getState().phase === 'playing') {
        this.audio.start()
        this.attack()
      }
      this.dragging = false
    })
    this.canvas.addEventListener('wheel', (e) => {
      this.player?.zoom(e.deltaY * 0.004)
    }, { passive: true })
    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault())
    // لمس: نیمه راست صفحه = دوربین
    this.canvas.addEventListener('touchstart', (e) => {
      this.audio.start()
      for (const t of Array.from(e.changedTouches)) {
        if (t.clientX > window.innerWidth * 0.42) {
          this.lastTouchLook = { x: t.clientX, y: t.clientY }
        }
      }
    }, { passive: true })
    this.canvas.addEventListener('touchmove', (e) => {
      if (useGame.getState().phase !== 'playing') return
      for (const t of Array.from(e.changedTouches)) {
        if (t.clientX > window.innerWidth * 0.42) {
          const dx = t.clientX - this.lastTouchLook.x
          const dy = t.clientY - this.lastTouchLook.y
          this.player?.look(dx * 1.9, dy * 1.9)
          this.lastTouchLook = { x: t.clientX, y: t.clientY }
        }
      }
    }, { passive: true })
    window.addEventListener('blur', () => this.keys.clear())
  }

  // ═══ شروع بازی ═══
  start(classId: ClassId, fromSave: boolean) {
    this.cls = CLASSES.find((c) => c.id === classId)!
    const st = useGame.getState()
    if (this.player) this.engine.scene.remove(this.player.rig.group)

    this.player = new Player(this.cls, {
      world: this.world,
      vfx: this.vfx,
      camera: this.engine.camera,
      onMeleeHit: (combo) => this.meleeHit(combo),
      onRangedShot: (from, dir, heavy) => this.shootBolt(from, dir, heavy),
      onStep: (run) => this.audio.step(run),
      isBuffed: () => this.buffT > 0,
    }, this.engine.scene)

    // وضعیت پایه
    let level = 1, xp = 0, gold = 30, potions = 3, kills = 0
    let quests: QuestState[] = QUESTS.map((q) => ({ def: q, count: 0, status: 'available' as const }))
    let pos: [number, number] = [0, 4]

    if (fromSave) {
      try {
        const s = loadJson<SavedGame>(SAVE_KEY) ?? {}
        if (s.classId === classId) {
          level = s.level ?? 1; xp = s.xp ?? 0; gold = s.gold ?? 30
          potions = s.potions ?? 3; kills = s.kills ?? 0
          const savedQuests = s.quests
          if (Array.isArray(savedQuests)) {
            quests = QUESTS.map((q) => {
              const sq = savedQuests.find((x) => x.id === q.id)
              return { def: q, count: sq?.count ?? 0, status: sq?.status ?? 'available' as const }
            })
          }
          if (Array.isArray(s.pos)) pos = s.pos
        }
      } catch { /* نادیده */ }
    }

    this.hpMax = this.hpMaxFor(level)
    this.manaMax = this.manaMaxFor(level)
    this.hp = this.hpMax
    this.mana = this.manaMax
    this.vitalAcc = 0
    this.cds = [0, 0, 0, 0]
    this.cdDirty = false
    this.buffT = 0
    this.atkBuff = 1
    this.player.teleport(pos[0], pos[1])
    this.player.camYaw = Math.PI
    this.player.yaw = Math.PI

    // جلوگیری از نشتی: همراه و دشمنانِ نشست قبلی آزاد می‌شوند
    if (this.companion) { this.companion.dispose(); this.companion = null }
    this.enemies.clear()
    this.companion = new Companion({ world: this.world, vfx: this.vfx }, this.engine.scene)
    this.companion.pos.copy(this.player.pos).add(new THREE.Vector3(2, 0, 2))

    st.set({
      phase: 'playing',
      classId,
      level, xp, xpNext: xpForLevel(level),
      hp: this.hp, hpMax: this.hpMax, mana: this.mana, manaMax: this.manaMax,
      gold, potions, kills,
      attack: this.atkFor(level),
      quests,
      dialog: null,
      cooldowns: [0, 0, 0, 0],
      buffT: 0,
      bossName: null,
      zoneName: '', zoneTick: 0,
      lowHp: false,
      toast: null,
      companionTier: level >= 35 ? 2 : level >= 15 ? 1 : 0,
      companionName: level >= 35 ? 'گرگ آلفا' : level >= 15 ? 'گرگ جوان' : 'توله گرگ',
    })
    this.companion.setTier(level >= 35 ? 2 : level >= 15 ? 1 : 0)
    this.lastBiome = ''
    this.running = true
    this.audio.start()
    this.save()
  }

  /**
   * ورودی خام بازیکن از کلیدها، جوی‌استیک لمسی و دسته‌بازی.
   * قرارداد: `x` = راستِ صفحه (مثبت)، `y` = جلو دور از دوربین (مثبت).
   *   • W / ↑ و کشیدن جوی‌استیک/استیک به بالا → y مثبت
   *   • D / → و کشیدن جوی‌استیک/استیک به راست → x مثبت
   * توجه: `touch.mx` با کشیدن به راست مثبت می‌شود و `touch.mz` با کشیدن به
   * پایین مثبت می‌شود، پس مؤلفه‌ی «جلو» برابر `-touch.mz` است. `pad` هم
   * از قبل با همین قرارداد نرمال شده است.
   */
  private inputVector(out: THREE.Vector2): THREE.Vector2 {
    const k = this.keys
    const right = (k.has('d') || k.has('arrowright') ? 1 : 0) - (k.has('a') || k.has('arrowleft') ? 1 : 0)
    const fwd = (k.has('w') || k.has('arrowup') ? 1 : 0) - (k.has('s') || k.has('arrowdown') ? 1 : 0)
    return out.set(right + touch.mx + pad.moveX, fwd - touch.mz + pad.moveY)
  }

  // ═══ ورودی دسته‌بازی ═══
  /** تشخیص حالت ورودی: راهنماهای HUD بر این اساس عوض می‌شوند */
  private markInput(mode: 'kb' | 'pad') {
    const st = useGame.getState()
    if (st.inputMode !== mode) st.set({ inputMode: mode })
  }

  private padAtkRepeat = 0
  private padNavT = 0

  /**
   * پردازش ورودی دسته — هر فریم، پیش از به‌روزرسانی بازیکن.
   * دسته همه‌ی حالت‌ها را پوشش می‌دهد: عنوان، بازی، دیالوگ و مرگ؛
   * وگرنه بازیکن با دسته حتی نمی‌توانست بازی را شروع کند.
   */
  private updatePad(dt: number) {
    const st = useGame.getState()

    // پیام اتصال/قطع
    for (const n of pad.drainNotices()) st.set({ toast: n })
    if (st.padConnected !== pad.connected) st.set({ padConnected: pad.connected })
    if (st.padKind !== pad.kind) st.set({ padKind: pad.kind })
    if (!pad.connected) return

    if (performance.now() - pad.lastActivity < 250) this.markInput('pad')

    // ── دوربین با استیک راست ── (تبدیل به معادل پیکسلیِ حرکت ماوس)
    if (st.phase === 'playing' && !st.dialog && this.player) {
      if (pad.lookX || pad.lookY) {
        const k = 520 * dt
        this.player.look(pad.lookX * k, pad.lookY * k)
      }
    }

    switch (st.phase) {
      // ═══ صفحه‌ی عنوان: انتخاب کلاس و شروع ═══
      case 'title': {
        const order: ClassId[] = ['warrior', 'mage', 'ranger']
        let i = order.indexOf(st.titleClass)
        if (i < 0) i = 0
        // با نگاه‌داشتن جهت، انتخاب پشت‌سرهم جلو می‌رود (با درنگ طبیعی)
        this.padNavT -= dt
        const dir = (pad.held('dright') ? 1 : 0) - (pad.held('dleft') ? 1 : 0)
        if (dir === 0) this.padNavT = 0
        else if (this.padNavT <= 0) {
          this.padNavT = 0.22
          const next = order[(i + dir + order.length) % order.length]
          st.set({ titleClass: next })
          this.audio.click()
        }
        if (pad.just('a') || pad.just('start')) {
          this.audio.click()
          this.start(st.titleClass, false)
        } else if (pad.just('y') && st.hasSave) {
          this.audio.click()
          this.start(st.titleClass, true)
        }
        break
      }

      // ═══ بازی ═══
      case 'playing': {
        // دیالوگ باز است: دکمه‌ها نقش تأیید/بستن می‌گیرند
        if (st.dialog) {
          if (pad.just('a') || pad.just('y')) {
            if (st.dialog.canComplete) this.completeQuest()
            else if (st.dialog.canAccept) this.acceptQuest()
            else this.closeDialog()
          }
          if (pad.just('b')) this.closeDialog()
          break
        }

        if (pad.just('a')) this.markPadJump()
        if (pad.just('x')) { this.attack(); this.padAtkRepeat = 0.5 }
        if (pad.just('b')) this.drinkPotion()
        if (pad.just('y')) this.tryInteract()
        // مهارت‌ها روی شانه‌ها و تریگرها — بدون تعارض با حمله
        if (pad.just('lb')) this.castSkill(0)
        if (pad.just('rb')) this.castSkill(1)
        if (pad.just('lt')) this.castSkill(2)
        if (pad.just('rt')) this.castSkill(3)
        if (pad.just('start')) st.set({ showHelp: !st.showHelp })
        if (pad.just('back')) this.toggleMute()

        // حمله‌ی پیوسته با نگه‌داشتن دکمه
        if (pad.held('x')) {
          this.padAtkRepeat -= dt
          if (this.padAtkRepeat <= 0) {
            this.attack()
            this.padAtkRepeat = 0.52
          }
        } else this.padAtkRepeat = 0
        break
      }

      // ═══ مرگ: بازگشت با دکمه ═══
      case 'dead': {
        if (pad.just('a') || pad.just('start')) this.respawn()
        break
      }
    }
  }

  /** دکمه‌ی پرش دسته را چند لحظه در مجموعه‌ی کلیدها می‌گذارد */
  private padJumpT = 0
  private markPadJump() {
    this.padJumpT = 0.14
  }

  private hpMaxFor(level: number) { return Math.round(this.cls.hp + (level - 1) * 16) }
  private manaMaxFor(level: number) { return Math.round(this.cls.mana + (level - 1) * 8) }
  private atkFor(level: number) { return Math.round((this.cls.atk + (level - 1) * 2.4) * 10) / 10 }

  /** همگام‌سازی فوری جان/مانا با استور (برای رویدادهای گسسته مثل ضربه یا معجون) */
  private syncVitals() {
    useGame.getState().set({
      hp: this.hp, mana: this.mana, hpMax: this.hpMax, manaMax: this.manaMax,
      lowHp: this.hp / this.hpMax < 0.28,
    })
  }

  save() {
    const st = useGame.getState()
    if (st.phase !== 'playing' || !st.classId) return
    saveRaw(SAVE_KEY, JSON.stringify({
      classId: st.classId, level: st.level, xp: st.xp, gold: st.gold,
      potions: st.potions, kills: st.kills,
      quests: st.quests.map((q) => ({ id: q.def.id, count: q.count, status: q.status })),
      pos: [Math.round(this.player.pos.x), Math.round(this.player.pos.z)],
    }))
    st.set({ hasSave: true })
  }

  toggleMute() {
    const st = useGame.getState()
    this.audio.setMuted(!st.muted)
    st.set({ muted: !st.muted })
  }

  // ═══ مبارزه ═══
  attack() {
    if (this.paused || !this.player) return
    if (this.player.tryAttack()) {
      if (this.cls.id === 'warrior') this.audio.swing()
      else this.audio.shoot()
    }
  }

  private facingTarget(): THREE.Vector3 | null {
    const fwd = new THREE.Vector3(Math.sin(this.player.camYaw), 0, Math.cos(this.player.camYaw))
    const t = this.enemies.nearest(this.player.pos, this.cls.range + 6, fwd, 0.25)
    if (t) {
      this.lastTarget = t
      return t.pos.clone().setY(t.pos.y + t.rig.hitY * 0.6).sub(this.player.muzzlePos()).normalize()
    }
    return null
  }

  private meleeHit(combo: number) {
    const st = useGame.getState()
    const dir = new THREE.Vector3(Math.sin(this.player.yaw), 0, Math.cos(this.player.yaw))
    const range = this.cls.range
    const targets = this.enemies.inCone(this.player.pos, dir, range, 0.34)
    const base = st.attack * this.atkBuff * (combo === 2 ? 1.9 : combo === 1 ? 1.15 : 1)
    let hitAny = false
    for (const e of targets) {
      const crit = Math.random() < 0.14
      const dmg = Math.round(base * (0.85 + Math.random() * 0.3) * (crit ? 1.8 : 1))
      this.lastTarget = e
      const died = e.takeDamage(dmg, this.player.pos, combo === 2 ? 7 : 3)
      const hitPos = e.pos.clone().setY(e.pos.y + e.rig.hitY * 0.65)
      this.vfx.hit(hitPos, crit ? 0xffe25c : 0xffd890, crit || combo === 2)
      this.vfx.blood(hitPos)
      this.vfx.damageNumber(hitPos, faNum(dmg), crit ? 'crit text-amber-300' : 'text-orange-100', this.engine.camera)
      this.audio[crit ? 'crit' : 'hit']()
      hitAny = true
      if (died) this.audio.die()
    }
    if (hitAny) {
      this.engine.hitstop(combo === 2 ? 0.09 : 0.045, 0.15)
      if (combo === 2) this.vfx.ring(this.player.pos, this.cls.trim, 3.2, 0.4)
      // بازخورد لمسی: ضربه‌ی سوم سنگین‌تر
      pad.rumble(combo === 2 ? 0.55 : 0.28, combo === 2 ? 0.4 : 0.2, combo === 2 ? 110 : 60)
    }
  }

  private shootBolt(from: THREE.Vector3, dir: THREE.Vector3, heavy: boolean, opts: Partial<Projectile> = {}) {
    const st = useGame.getState()
    const p = this.projectiles.find((x) => !x.alive) ?? this.makeProjectile()
    p.alive = true
    p.pos.copy(from)
    p.dir.copy(dir).normalize()
    p.speed = this.cls.id === 'ranger' ? 34 : 24
    p.dmg = st.attack * this.atkBuff * (heavy ? 1.5 : 1)
    p.aoe = heavy ? 3.2 : 0
    p.color = this.cls.id === 'mage' ? 0x9cd2ff : 0xd8e8a8
    p.life = 1.6
    p.gravity = this.cls.id === 'ranger' ? 4 : 0
    p.heavy = heavy
    p.mesh.visible = true
    ;(p.mesh.material as THREE.MeshBasicMaterial).color.set(p.color)
    p.mesh.scale.setScalar(heavy ? 1.7 : 1)
    Object.assign(p, opts)
  }

  private makeProjectile(): Projectile {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.11, 8, 6),
      new THREE.MeshBasicMaterial({ color: 0xffffff }),
    )
    this.engine.scene.add(mesh)
    const p: Projectile = {
      alive: false, mesh, pos: new THREE.Vector3(), dir: new THREE.Vector3(),
      speed: 20, dmg: 10, aoe: 0, color: 0xffffff, life: 0, gravity: 0, heavy: false,
    }
    this.projectiles.push(p)
    return p
  }

  castSkill(i: number) {
    const st = useGame.getState()
    if (st.phase !== 'playing' || st.dialog || this.paused || this.player.state === 'dead') return
    const skill = this.cls.skills[i]
    if (!skill) return
    if (this.cds[i] > 0 || this.mana < skill.mana) {
      if (this.mana < skill.mana) st.set({ toast: 'مانا کافی نیست!' })
      return
    }
    this.mana -= skill.mana
    this.cds[i] = skill.cd
    this.cdDirty = true
    st.set({ cooldowns: [...this.cds] })
    this.syncVitals()
    const p = this.player
    const v = this.vfx
    const facing = this.facingTarget()

    switch (skill.id) {
      case 'whirlwind': {
        p.playCastAnim(0.6)
        this.audio.swing()
        const targets = this.enemies.inCone(p.pos, new THREE.Vector3(1, 0, 0), 4.4, -2)
        for (const e of targets) this.damageEnemy(e, st.attack * 1.7, p.pos, 6)
        v.ring(p.pos, 0xffe0a0, 4.4, 0.5)
        v.shake(0.25)
        this.engine.hitstop(0.07, 0.2)
        break
      }
      case 'charge': {
        const dir = facing ?? new THREE.Vector3(Math.sin(p.yaw), 0, Math.cos(p.yaw))
        p.vel.x = dir.x * 26; p.vel.z = dir.z * 26
        p.iframes = 0.3
        p.playCastAnim(0.35)
        this.audio.dash()
        const hit = this.enemies.nearest(p.pos.clone().addScaledVector(dir, 4), 3.4)
        if (hit) this.damageEnemy(hit, st.attack * 2.1, p.pos, 9)
        v.dust(p.pos, 10)
        break
      }
      case 'slam': {
        p.playCastAnim(0.55)
        this.audio.boom()
        const targets = this.enemies.inCone(p.pos, new THREE.Vector3(1, 0, 0), 5.2, -2)
        for (const e of targets) this.damageEnemy(e, st.attack * 2, p.pos, 10)
        v.ring(p.pos, 0xffb060, 5.4, 0.65)
        v.dust(p.pos, 16)
        v.shake(0.5)
        this.engine.hitstop(0.1, 0.12)
        break
      }
      case 'warcry': {
        p.playCastAnim(0.5)
        this.buffT = 8
        this.atkBuff = 1.4
        this.audio.buff()
        v.ring(p.pos, this.cls.trim, 3, 0.8)
        st.set({ buffT: 8 })
        break
      }
      case 'fireball': {
        p.playCastAnim(0.4)
        this.audio.fireball()
        const dir = facing ?? p.aimDir(null)
        this.shootBolt(p.muzzlePos(), dir, true, { color: 0xff8a2c, dmg: st.attack * this.atkBuff * 1.6, aoe: 2.8, speed: 26, gravity: 0 })
        break
      }
      case 'frostnova': {
        p.playCastAnim(0.5)
        this.audio.frost()
        const targets = this.enemies.inCone(p.pos, new THREE.Vector3(1, 0, 0), 5.4, -2)
        for (const e of targets) {
          this.damageEnemy(e, st.attack * 1.25, p.pos, 4)
          e.slow = 3
        }
        v.ring(p.pos, 0x7ad4ff, 5.4, 0.7)
        break
      }
      case 'chain': {
        p.playCastAnim(0.45)
        this.audio.bolt()
        let from = p.muzzlePos()
        let cur = this.enemies.nearest(p.pos, 15, new THREE.Vector3(Math.sin(p.camYaw), 0, Math.cos(p.camYaw)), 0.1)
        const hitSet = new Set<Enemy>()
        for (let n = 0; n < 3 && cur; n++) {
          this.lightningPath(from, cur.pos.clone().setY(cur.pos.y + cur.rig.hitY * 0.6))
          this.damageEnemy(cur, st.attack * this.atkBuff * 1.35, p.pos, 2)
          hitSet.add(cur)
          from = cur.pos.clone().setY(cur.pos.y + cur.rig.hitY * 0.6)
          const next = this.enemies.nearest(cur.pos, 8)
          cur = next && !hitSet.has(next) ? next : null
        }
        if (hitSet.size === 0) st.set({ toast: 'دشمنی در دید نیست' })
        break
      }
      case 'meteor': {
        p.playCastAnim(0.7)
        const t = this.enemies.nearest(p.pos, 20)
        const pos = t ? t.pos.clone() : p.pos.clone().addScaledVector(new THREE.Vector3(Math.sin(p.camYaw), 0, Math.cos(p.camYaw)), 10)
        this.pendingMeteors.push({ pos, t: 0.9 })
        v.ring(pos, 0xff5a3c, 5, 0.9)
        this.audio.fireball()
        break
      }
      case 'multishot': {
        p.playCastAnim(0.35)
        this.audio.shoot()
        const base = facing ? Math.atan2(facing.x, facing.z) : p.yaw
        for (let k = -2; k <= 2; k++) {
          const a = base + k * 0.14
          this.shootBolt(p.muzzlePos(), new THREE.Vector3(Math.sin(a), 0.02, Math.cos(a)), false, { dmg: st.attack * this.atkBuff * 0.7 })
        }
        break
      }
      case 'volley': {
        p.playCastAnim(0.5)
        const t = this.enemies.nearest(p.pos, 20)
        const pos = t ? t.pos.clone() : p.pos.clone().addScaledVector(new THREE.Vector3(Math.sin(p.camYaw), 0, Math.cos(p.camYaw)), 9)
        this.volleys.push({ pos, t: 0, n: 10 })
        v.ring(pos, 0xd8e8a8, 4, 0.8)
        this.audio.shoot()
        break
      }
      case 'roll': {
        // همان قراردادِ حرکت: بدون ورودی، غلت در جهت نگاه مدل انجام می‌شود
        const iv = this.inputVector(ROLL_IN)
        const camRel = iv.lengthSq() > 0.01
          ? screenDirToWorld(iv.x, iv.y, p.camYaw, ROLL_DIR).normalize()
          : new THREE.Vector3(Math.sin(p.yaw), 0, Math.cos(p.yaw))
        if (p.tryRoll(camRel)) this.audio.dash()
        break
      }
      case 'explosive': {
        p.playCastAnim(0.45)
        this.audio.shoot()
        const dir = facing ?? p.aimDir(null)
        this.shootBolt(p.muzzlePos(), dir, true, { color: 0xffa03c, dmg: st.attack * this.atkBuff * 2.3, aoe: 3.6, speed: 28 })
        break
      }
    }
  }

  private lightningPath(a: THREE.Vector3, b: THREE.Vector3) {
    const seg = 9
    for (let i = 0; i <= seg; i++) {
      const p = a.clone().lerp(b, i / seg)
      if (i > 0 && i < seg) {
        p.x += (Math.random() - 0.5) * 0.5
        p.y += (Math.random() - 0.5) * 0.5
        p.z += (Math.random() - 0.5) * 0.5
      }
      this.vfx.trail(p, 0x9cd2ff, 1.5, 0.32)
    }
  }

  damageEnemy(e: Enemy, raw: number, from: THREE.Vector3, knock = 3) {
    const crit = Math.random() < 0.14
    const dmg = Math.round(raw * (0.85 + Math.random() * 0.3) * (crit ? 1.8 : 1))
    this.lastTarget = e
    const died = e.takeDamage(dmg, from, knock)
    const hitPos = e.pos.clone().setY(e.pos.y + e.rig.hitY * 0.65)
    this.vfx.hit(hitPos, crit ? 0xffe25c : 0xffd890, crit)
    this.vfx.blood(hitPos)
    this.vfx.damageNumber(hitPos, faNum(dmg), crit ? 'crit text-amber-300' : 'text-orange-100', this.engine.camera)
    this.audio[crit ? 'crit' : 'hit']()
    if (died) this.audio.die()
  }

  playerHurt(dmg: number, _from: THREE.Vector3) {
    const st = useGame.getState()
    if (st.phase !== 'playing' || this.player.iframes > 0 || this.player.state === 'dead') return
    const final = Math.max(1, Math.round(dmg * (this.buffT > 0 ? 0.8 : 1)))
    this.hp = Math.max(0, this.hp - final)
    this.player.iframes = 0.35
    this.vfx.shake(0.4)
    this.audio.hurt()
    this.vfx.damageNumber(this.player.pos.clone().setY(this.player.pos.y + 1.9), faNum(final), 'text-red-400', this.engine.camera)
    st.set({ hurtTick: st.hurtTick + 1 })
    this.syncVitals()
    pad.rumble(0.85, 0.55, 220)   // بازخورد لمسی آسیب
    if (this.hp <= 0) this.onDeath()
  }

  private onDeath() {
    const st = useGame.getState()
    this.player.state = 'dead'
    st.set({ phase: 'dead' })
    this.audio.die()
    pad.rumble(1, 0.7, 600)
  }

  respawn() {
    const st = useGame.getState()
    this.player.teleport(0, 6)
    this.player.state = 'idle'
    this.player.iframes = 2.5 // فرصت نفس‌کشیدن پس از بیدارشدن
    this.hp = this.hpMax
    this.mana = this.manaMax
    st.set({ phase: 'playing', dialog: null })
    this.syncVitals()
    this.vfx.soul(this.player.pos.clone().setY(this.player.pos.y + 1), 0x9cd2ff)
    this.save()
  }

  drinkPotion() {
    const st = useGame.getState()
    if (st.phase !== 'playing' || this.potionCd > 0) return
    if (st.potions <= 0) { st.set({ toast: 'معجونی نداری! از شکار هیولاها جمع کن.' }); return }
    if (this.hp >= this.hpMax) return
    this.potionCd = 1.2
    const heal = Math.round(this.hpMax * 0.45)
    this.hp = Math.min(this.hpMax, this.hp + heal)
    st.set({ potions: st.potions - 1 })
    this.syncVitals()
    this.audio.potion()
    this.vfx.soul(this.player.pos.clone().setY(this.player.pos.y + 1), 0xff6a8a)
    this.vfx.damageNumber(this.player.pos.clone().setY(this.player.pos.y + 2), `+${faNum(heal)}`, 'text-emerald-300', this.engine.camera)
  }

  private onEnemyKill(e: Enemy) {
    const st = useGame.getState()
    const v = this.vfx
    const pos = e.pos.clone().setY(e.pos.y + 0.5)
    v.soul(pos, 0x9ce84a)
    v.puff(pos, 0x4a3a30, 10, 2.4)
    // غنیمت
    const gold = Math.round(lerp(e.def.gold[0], e.def.gold[1], Math.random()))
    this.spawnPickup('gold', gold, pos)
    const orbs = e.def.boss ? 5 : 2 + Math.floor(Math.random() * 2)
    for (let i = 0; i < orbs; i++) this.spawnPickup('xp', Math.ceil(e.def.xp / orbs), pos)
    if (Math.random() < (e.def.boss ? 1 : 0.16)) this.spawnPickup('potion', 1, pos)
    // ماموریت‌ها
    const quests = st.quests.map((q) => {
      if (q.status === 'active' && q.def.target === e.def.kind) {
        const count = q.count + 1
        return { ...q, count, status: (count >= q.def.count ? 'ready' : 'active') as QuestState['status'] }
      }
      return q
    })
    st.set({ quests, kills: st.kills + 1 })
    const ready = quests.find((q) => q.status === 'ready' && q.def.target === e.def.kind)
    if (ready) {
      st.set({ toast: `ماموریت «${ready.def.name}» آماده تحویل است!` })
      this.audio.quest()
    }
  }

  private spawnPickup(kind: Pickup['kind'], value: number, pos: THREE.Vector3) {
    if (this.pickups.length > 44) {
      const old = this.pickups.shift()
      if (old) { this.engine.scene.remove(old.mesh); disposeObject(old.mesh) }
    }
    let mesh: THREE.Mesh
    if (kind === 'gold') {
      mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.05, 10), std(0xe8b64a, { metalness: 0.8, roughness: 0.25, emissive: 0x8a6a1c, emissiveIntensity: 0.5 }))
    } else if (kind === 'potion') {
      mesh = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), std(0xe83a5c, { emissive: 0xa01c3c, emissiveIntensity: 0.9, roughness: 0.3 }))
    } else {
      mesh = new THREE.Mesh(new THREE.OctahedronGeometry(0.15), std(0x9ce84a, { emissive: 0x5cb81c, emissiveIntensity: 1.6 }))
    }
    this.engine.scene.add(mesh)
    const a = Math.random() * Math.PI * 2
    this.pickups.push({
      mesh, kind, value, magnet: false, t: 0,
      vel: new THREE.Vector3(Math.cos(a) * 2.2, 4.5 + Math.random() * 2, Math.sin(a) * 2.2),
    })
    mesh.position.copy(pos)
  }

  // ═══ تعامل و ماموریت ═══
  private buildNpcs() {
    const questMap: Record<string, string[]> = {
      rorik: ['q_wolves', 'q_boss'],
      baldur: ['q_golems'],
      elara: ['q_slimes'],
      mira: [], agustus: [],
    }
    for (const def of NPCS) {
      if (def.id === 'rorik2') continue
      const { group, body, head } = buildNPC(def.color)
      const y = this.world.height(def.pos[0], def.pos[1])
      group.position.set(def.pos[0], y, def.pos[1])
      group.rotation.y = Math.atan2(-def.pos[0], -def.pos[1])
      const label = makeLabel(def.name, '#f4ecd8', 'rgba(20,16,10,0.66)', 0.8)
      label.position.y = 2.35
      group.add(label)
      const marker = makeLabel('!', '#ffd23c', 'rgba(30,24,8,0.8)', 0.55)
      marker.position.y = 3
      marker.visible = false
      group.add(marker)
      this.engine.scene.add(group)
      this.npcs.push({
        id: def.id, name: def.name, role: def.role, group, body,
        pos: new THREE.Vector3(def.pos[0], y, def.pos[1]),
        questIds: questMap[def.id] ?? [],
        marker, greet: def.greet,
      })
      void head
    }
  }

  tryInteract() {
    if (!this.interactTarget) return
    const st = useGame.getState()
    if (st.dialog) { st.set({ dialog: null }); return }
    const npc = this.interactTarget
    this.audio.click()
    // انتخاب ماموریت مرتبط
    let quest: QuestState | undefined
    for (const qid of npc.questIds) {
      const q = st.quests.find((x) => x.def.id === qid)!
      if (q.status === 'ready') { quest = q; break }
      if (q.status === 'active') { quest = q; break }
      if (q.status === 'available') {
        const prevIdx = npc.questIds.indexOf(qid) - 1
        const prevDone = prevIdx < 0 || st.quests.find((x) => x.def.id === npc.questIds[prevIdx])!.status === 'done'
        if (prevDone) { quest = q; break }
      }
    }
    let text = npc.greet
    let canAccept = false, canComplete = false
    if (quest) {
      if (quest.status === 'available') { text = quest.def.brief; canAccept = true }
      else if (quest.status === 'active') text = quest.def.progressText
      else if (quest.status === 'ready') { text = quest.def.doneText; canComplete = true }
      else text = quest.def.doneText
    }
    st.set({
      dialog: {
        npcId: npc.id, npcName: npc.name, npcRole: npc.role,
        text, quest, canAccept, canComplete,
      },
    })
  }

  acceptQuest() {
    const st = useGame.getState()
    const d = st.dialog
    if (!d?.quest) return
    st.set({
      quests: st.quests.map((q) => q.def.id === d.quest!.def.id ? { ...q, status: 'active' } : q),
      dialog: { ...d, text: d.quest.def.acceptText, canAccept: false },
    })
    this.audio.quest()
  }

  completeQuest() {
    const st = useGame.getState()
    const d = st.dialog
    if (!d?.quest) return
    const q = d.quest
    st.set({
      quests: st.quests.map((x) => x.def.id === q.def.id ? { ...x, status: 'done' } : x),
      gold: st.gold + q.def.gold,
      dialog: null,
      toast: `پاداش ماموریت: ${faNum(q.def.gold)} طلا و ${faNum(q.def.xp)} تجربه!`,
    })
    this.audio.coin()
    this.gainXp(q.def.xp)
    this.save()
  }

  closeDialog() {
    useGame.getState().set({ dialog: null })
  }

  gainXp(amount: number) {
    const st = useGame.getState()
    let xp = st.xp + amount
    let level = st.level
    let leveled = false
    // ⚠️ آستانه باید از خودِ سطحِ جاری محاسبه شود. استفاده از st.xpNext (که کهنه است)
    // باعث می‌شد پاداش‌های بزرگ چند سطح اضافه بپرند.
    while (xp >= xpForLevel(level)) {
      xp -= xpForLevel(level)
      level++
      leveled = true
    }
    this.hpMax = this.hpMaxFor(level)
    this.manaMax = this.manaMaxFor(level)
    const patch: Partial<ReturnType<typeof useGame.getState>> = {
      xp, level, xpNext: xpForLevel(level), hpMax: this.hpMax, manaMax: this.manaMax,
      attack: this.atkFor(level),
    }
    if (leveled) {
      this.hp = this.hpMax
      this.mana = this.manaMax
      patch.hp = this.hp
      patch.mana = this.mana
      patch.levelUpTick = st.levelUpTick + 1
      const tier = level >= 35 ? 2 : level >= 15 ? 1 : 0
      if (tier !== st.companionTier) {
        patch.companionTier = tier
        patch.companionName = tier === 2 ? 'گرگ آلفا' : tier === 1 ? 'گرگ جوان' : 'توله گرگ'
        this.companion?.setTier(tier)
        patch.toast = `همراه تو به «${patch.companionName}» تکامل یافت!`
      }
      this.audio.levelup()
      this.vfx.soul(this.player.pos.clone().setY(this.player.pos.y + 1), 0xffe25c)
      this.vfx.ring(this.player.pos, 0xffe25c, 3.4, 0.9)
      pad.rumble(0.3, 0.8, 420)   // ارتعاش کوتاه جشن افزایش سطح
    }
    st.set(patch)
  }

  // ═══ حلقه اصلی ═══
  loop() {
    const dt = this.engine.tick()
    const st = useGame.getState()
    const t = performance.now() / 1000
    uTime.value = t

    // دسته‌بازی هر فریم نظرسنجی می‌شود (API رویداد تغییر وضعیت ندارد).
    // پیش از هر چیز، چون در حالت «عنوان» هم لازم است.
    pad.poll()
    this.updatePad(dt)
    // پرش دسته چند لحظه مثل نگه‌داشتن کلید عمل می‌کند
    if (this.padJumpT > 0) this.padJumpT -= dt

    const camTarget = this.player ? this.player.pos : new THREE.Vector3(0, 0, 0)
    this.sky.update(dt, camTarget)
    this.world.update(camTarget.x, camTarget.z)

    if (st.phase === 'title') {
      // دوربین چرخان دور شهر برای پس‌زمینه تیتراژ
      this.camOrbitT += dt * 0.06
      const r = 34
      const cx = Math.cos(this.camOrbitT) * r
      const cz = Math.sin(this.camOrbitT) * r
      this.engine.camera.position.lerp(new THREE.Vector3(cx, 13 + Math.sin(this.camOrbitT * 0.7) * 3, cz), 0.03)
      this.engine.camera.lookAt(0, 3, 0)
      this.updateEnvironment(dt, camTarget, true)
      this.vfx.update(dt)
      this.animateNpcs(dt, t)
      this.engine.render()
      return
    }

    if (!this.player) { this.engine.render(); return }

    const dialogOpen = !!st.dialog
    this.paused = st.phase === 'dead'

    // ═══ مرگ: جهان متوقف می‌شود اما بازیکن به‌روزرسانی می‌شود
    // تا انیمیشن افتادن و حرکت دوربین اجرا شوند (پیش‌تر قفل می‌شد و قهرمان یخ می‌زد)
    if (this.paused) {
      this.player.update(dt, ZERO_MOVE, false, false, null)
      this.updateEnvironment(dt, this.player.pos, false)
      this.animateNpcs(dt, t)
      this.vfx.update(dt)
      this.updateBossBar()
      this.engine.render()
      return
    }

    // حرکت (قرارداد در inputVector مستند شده است)
    const move = this.inputVector(MOVE_VEC)
    if (dialogOpen) move.set(0, 0)
    const sprint = this.keys.has('shift') || touch.sprint || pad.sprint
    const jump = (this.keys.has('jump') || this.padJumpT > 0) && !dialogOpen
    const facing = this.facingTarget()

    if (!this.paused) {
      this.player.update(dt, move, sprint, jump, facing)
      this.enemies.update(dt, this.player, t)
      // همراه
      if (this.companion) {
        const aggroTarget = this.lastTarget && !this.lastTarget.dead && this.lastTarget.state !== 'idle'
          ? this.lastTarget
          : this.enemies.nearest(this.player.pos, 9)
        this.companion.update(dt, this.player, aggroTarget, (e, dmg) => this.damageEnemy(e, dmg, this.companion!.pos, 2))
      }
      this.updateProjectiles(dt)
      this.updatePickups(dt)
      this.updateSkillsFx(dt)
      this.regen(dt)
      this.updateInteract()
      this.updateQuestMarkers()
      this.potionCd = Math.max(0, this.potionCd - dt)
      if (this.buffT > 0) {
        this.buffT -= dt
        if (this.buffT <= 0) { this.atkBuff = 1; st.set({ buffT: 0 }) }
        else st.set({ buffT: Math.round(this.buffT * 10) / 10 })
      }
      // خسارت گدازه
      const lavaD = Math.hypot(this.player.pos.x - this.world.lavaPos.x, this.player.pos.z - this.world.lavaPos.z)
      if (lavaD < 25 && this.player.pos.y < this.world.lavaPos.y + 1 && this.player.iframes <= 0) {
        this.playerHurt(12, this.player.pos)
      }
      // سقوط در آب اقیانوس
      if (this.player.pos.y < -2.4) {
        const a = Math.atan2(this.player.pos.z, this.player.pos.x)
        this.player.teleport(Math.cos(a) * 420, Math.sin(a) * 420)
      }
      // کول‌داون‌ها — در خود بازی نگه داشته می‌شوند و با نرخ ~۲۰Hz به HUD می‌روند
      let anyCd = false
      for (let i = 0; i < 4; i++) {
        if (this.cds[i] > 0) { this.cds[i] = Math.max(0, this.cds[i] - dt); anyCd = true }
      }
      this.cdPush -= dt
      if (this.cdPush <= 0) {
        this.cdPush = 0.05
        if (anyCd || this.cdDirty) {
          st.set({ cooldowns: [...this.cds] })
          this.cdDirty = false
        }
      }
      // ذخیره خودکار
      this.saveTimer += dt
      if (this.saveTimer > 9) { this.saveTimer = 0; this.save() }
    }

    this.updateEnvironment(dt, this.player.pos, false)
    this.animateNpcs(dt, t)
    this.vfx.update(dt)
    this.updateBossBar()
    this.engine.render()
  }

  private regen(dt: number) {
    const st = useGame.getState()
    this.mana = Math.min(this.manaMax, this.mana + this.manaMax * 0.045 * dt)
    const inCity = this.world.weight('city', this.player.pos.x, this.player.pos.z) > 0.4
    if (inCity || this.buffT > 0) {
      this.hp = Math.min(this.hpMax, this.hp + this.hpMax * (inCity ? 0.035 : 0.02) * dt)
    }
    // استور با نرخ ~۱۵ بار در ثانیه به‌روز می‌شود، نه ۶۰ بار.
    // نوارها با ترنزیشن CSS نرم می‌مانند.
    this.vitalAcc += dt
    if (this.vitalAcc >= 0.066) {
      this.vitalAcc = 0
      if (Math.abs(this.hp - st.hp) > 0.01 || Math.abs(this.mana - st.mana) > 0.01) this.syncVitals()
    }
  }

  private updateProjectiles(dt: number) {
    for (const p of this.projectiles) {
      if (!p.alive) continue
      p.life -= dt
      if (p.life <= 0) { p.alive = false; p.mesh.visible = false; continue }
      p.dir.y -= (p.gravity * dt) / Math.max(p.speed, 1)
      p.pos.addScaledVector(p.dir, p.speed * dt)
      p.mesh.position.copy(p.pos)
      this.vfx.trail(p.pos, p.color, p.heavy ? 1.6 : 1, 0.28)
      // برخورد زمین
      const gh = this.world.height(p.pos.x, p.pos.z)
      if (p.pos.y < gh + 0.1) {
        this.explode(p)
        continue
      }
      // برخورد دشمن
      for (const e of this.enemies.enemies) {
        if (e.dead) continue
        const rr = e.rig.radius + 0.3
        const dx = e.pos.x - p.pos.x, dz = e.pos.z - p.pos.z
        const dy = (e.pos.y + e.rig.hitY * 0.6) - p.pos.y
        if (dx * dx + dz * dz < rr * rr && Math.abs(dy) < e.rig.hitY + 0.4) {
          if (p.aoe > 0) this.explode(p)
          else {
            this.damageEnemy(e, p.dmg, this.player.pos, 3)
            p.alive = false
            p.mesh.visible = false
          }
          break
        }
      }
    }
  }

  private explode(p: Projectile) {
    p.alive = false
    p.mesh.visible = false
    this.vfx.hit(p.pos, p.color, true)
    this.vfx.puff(p.pos, 0x3a3028, 8, 2.6)
    this.vfx.ring(p.pos, p.color, p.aoe || 2, 0.4)
    this.flashLight.position.copy(p.pos).add(new THREE.Vector3(0, 1, 0))
    this.flashLight.intensity = 3
    this.audio.boom()
    if (p.aoe > 0) {
      for (const e of this.enemies.enemies) {
        if (e.dead) continue
        if (e.pos.distanceTo(p.pos) < p.aoe + e.rig.radius) {
          this.damageEnemy(e, p.dmg, p.pos, 6)
        }
      }
    } else {
      const e = this.enemies.nearest(p.pos, 1.6)
      if (e) this.damageEnemy(e, p.dmg, p.pos, 3)
    }
  }

  private updateSkillsFx(dt: number) {
    // شهاب
    for (let i = this.pendingMeteors.length - 1; i >= 0; i--) {
      const m = this.pendingMeteors[i]
      m.t -= dt
      if (Math.random() < dt * 20) {
        this.vfx.trail(m.pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 8, 14 + Math.random() * 4, (Math.random() - 0.5) * 8)), 0xff8a3c, 2, 0.5)
      }
      if (m.t <= 0) {
        this.pendingMeteors.splice(i, 1)
        const pos = m.pos.clone().setY(this.world.height(m.pos.x, m.pos.z) + 0.5)
        this.vfx.hit(pos, 0xff7a2c, true)
        this.vfx.puff(pos, 0x2c2018, 14, 3.4)
        this.vfx.ring(pos, 0xff9a4c, 5.4, 0.7)
        this.vfx.shake(0.55)
        this.flashLight.position.copy(pos).add(new THREE.Vector3(0, 2, 0))
        this.flashLight.intensity = 5
        this.audio.boom()
        this.engine.hitstop(0.1, 0.1)
        const st = useGame.getState()
        for (const e of this.enemies.enemies) {
          if (!e.dead && e.pos.distanceTo(pos) < 5.4 + e.rig.radius) {
            this.damageEnemy(e, st.attack * this.atkBuff * 3, pos, 10)
          }
        }
      }
    }
    // باران تیر
    for (let i = this.volleys.length - 1; i >= 0; i--) {
      const vl = this.volleys[i]
      vl.t += dt
      if (vl.t > 0.5 && vl.n > 0) {
        vl.n--
        const a = Math.random() * Math.PI * 2
        const r = Math.random() * 3.6
        const pos = vl.pos.clone().add(new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r))
        pos.y = this.world.height(pos.x, pos.z)
        this.vfx.hit(pos.clone().setY(pos.y + 0.4), 0xd8e8a8)
        const st = useGame.getState()
        for (const e of this.enemies.enemies) {
          if (!e.dead && Math.hypot(e.pos.x - pos.x, e.pos.z - pos.z) < 1.2 + e.rig.radius) {
            this.damageEnemy(e, st.attack * this.atkBuff * 0.55, pos, 1)
          }
        }
      }
      if (vl.n <= 0) this.volleys.splice(i, 1)
    }
    this.flashLight.intensity = damp(this.flashLight.intensity, 0, 10, dt)
  }

  private goldAcc = 0
  private goldAccT = 0
  private goldShowT = 0
  private updatePickups(dt: number) {
    const st = useGame.getState()
    this.goldShowT -= dt
    if (this.goldShowT <= 0) { this.goldAcc = 0; this.goldAccT = 0 }
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i]
      p.t += dt
      const mp = p.mesh.position
      const gh = this.world.height(mp.x, mp.z) + 0.25
      if (!p.magnet) {
        p.vel.y -= 14 * dt
        mp.addScaledVector(p.vel, dt)
        if (mp.y < gh) { mp.y = gh; p.vel.y *= -0.4; p.vel.x *= 0.7; p.vel.z *= 0.7 }
        p.mesh.rotation.y += dt * 3
        const d = mp.distanceTo(this.player.pos)
        if (d < 5.5 && p.t > 0.4) p.magnet = true
      } else {
        const target = this.player.pos.clone().setY(this.player.pos.y + 0.9)
        const to = target.sub(mp)
        const d = to.length()
        mp.addScaledVector(to.normalize(), Math.min(d, (14 + (5 - Math.min(d, 5)) * 6) * dt))
        p.mesh.rotation.y += dt * 8
        if (d < 0.7) {
          // جمع‌آوری
          if (p.kind === 'gold') {
            st.set({ gold: st.gold + p.value })
            this.audio.coin()
            // اعداد شناور سکه‌ها جمع می‌شوند تا هنگام کشتن چند دشمن صفحه پر نشود
            this.goldAcc += p.value
            this.goldAccT += 1
            if (this.goldAccT === 1) {
              this.vfx.damageNumber(this.player.pos.clone().setY(this.player.pos.y + 2.1), `+${faNum(this.goldAcc)} طلا`, 'text-amber-300', this.engine.camera)
              this.goldShowT = 0.55
            }
          } else if (p.kind === 'potion') {
            st.set({ potions: st.potions + 1, toast: 'معجون شفا +۱' })
            this.audio.potion()
          } else {
            this.gainXp(p.value)
          }
          this.engine.scene.remove(p.mesh)
          disposeObject(p.mesh)
          this.pickups.splice(i, 1)
        }
      }
      // محو پس از مدت
      if (p.t > 45) {
        this.engine.scene.remove(p.mesh)
        disposeObject(p.mesh)
        this.pickups.splice(i, 1)
      }
    }
  }

  private updateInteract() {
    const st = useGame.getState()
    let best: NpcEnt | null = null
    let bd = 3.4
    for (const n of this.npcs) {
      const d = n.pos.distanceTo(this.player.pos)
      if (d < bd) { best = n; bd = d }
    }
    this.interactTarget = best
    const hint = best && !st.dialog ? `گفت‌وگو با ${best.name}` : null
    if (hint !== st.interactHint) st.set({ interactHint: hint })
  }

  private updateQuestMarkers() {
    const st = useGame.getState()
    for (const n of this.npcs) {
      let show = false
      for (const qid of n.questIds) {
        const q = st.quests.find((x) => x.def.id === qid)
        if (!q) continue
        if (q.status === 'ready') show = true
        else if (q.status === 'available') {
          const idx = n.questIds.indexOf(qid)
          if (idx === 0 || st.quests.find((x) => x.def.id === n.questIds[idx - 1])?.status === 'done') show = true
        }
      }
      n.marker.visible = show
    }
  }

  private animateNpcs(dt: number, t: number) {
    for (const n of this.npcs) {
      n.body.position.y = 0.9 + Math.sin(t * 1.6 + n.pos.x) * 0.02
      if (this.player) {
        const d = n.pos.distanceTo(this.player.pos)
        if (d < 6) {
          const ty = Math.atan2(this.player.pos.x - n.pos.x, this.player.pos.z - n.pos.z)
          n.group.rotation.y = damp(n.group.rotation.y, ty, 4, dt)
        }
      }
      n.marker.position.y = 3 + Math.sin(t * 2.4) * 0.12
    }
  }

  private updateBossBar() {
    const st = useGame.getState()
    const b = this.enemies.activeBoss
    if (b) {
      if (st.bossName !== b.def.name || Math.abs(st.bossHp - b.hp) > 0.5) {
        st.set({ bossName: b.def.name, bossHp: Math.max(0, b.hp), bossHpMax: b.maxHp })
      }
    } else if (st.bossName) {
      st.set({ bossName: null })
    }
  }

  private zoneTimerAcc = 0
  private lampSortAcc = 1
  private updateEnvironment(dt: number, pos: THREE.Vector3, isTitle: boolean) {
    const st = useGame.getState()
    const biome = this.world.dominantBiome(pos.x, pos.z)
    const night = this.sky.nightFactor

    // مه (با رنگ‌های بازاستفاده‌شدنی — پیش‌تر هر فریم ۴ شیء Color تخصیص می‌یافت)
    _fogC.set(biome.fogColor).lerp(_nightC, night * 0.86)
    this.fog.color.lerp(_fogC, 1 - Math.exp(-1.6 * dt))
    this.fog.near = damp(this.fog.near, biome.fogNear * (1 - night * 0.3), 1.6, dt)
    this.fog.far = damp(this.fog.far, biome.fogFar * (1 - night * 0.35), 1.6, dt)
    ;(this.engine.scene.background as THREE.Color).copy(this.fog.color)

    // نور چراغ‌های شهر
    this.world.setNight(night)
    if (night > 0.05) {
      // مرتب‌سازی چراغ‌ها فقط چند بار در ثانیه و درجای آرایه‌ی موجود
      this.lampSortAcc += dt
      if (this.lampSortAcc > 0.25 || _lampOrder.length !== this.world.lamps.length) {
        this.lampSortAcc = 0
        _lampOrder.length = 0
        for (const l of this.world.lamps) _lampOrder.push(l)
        _lampOrder.sort((a, b) => a.distanceToSquared(pos) - b.distanceToSquared(pos))
      }
      const sorted = _lampOrder
      for (let i = 0; i < this.lampLights.length; i++) {
        const l = this.lampLights[i]
        if (i < sorted.length && sorted[i].distanceToSquared(pos) < 90 * 90) {
          l.position.copy(sorted[i])
          l.intensity = night * 1.6
        } else l.intensity = 0
      }
      this.playerLight.position.set(pos.x, pos.y + 2.6, pos.z)
      this.playerLight.intensity = night * 1.1
    } else {
      for (const l of this.lampLights) l.intensity = 0
      this.playerLight.intensity = 0
    }

    // آب
    this.world.waterMat.uniforms.uCam.value = this.engine.camera.position
    ;(this.world.oceanMat.uniforms.uCam.value as THREE.Vector3).copy(this.engine.camera.position)
    ;(this.world.waterMat.uniforms.uSky.value as THREE.Color).copy(this.fog.color).lerp(_whiteC, 0.3)
    ;(this.world.oceanMat.uniforms.uSky.value as THREE.Color).copy(this.fog.color).lerp(_whiteC, 0.3)
    ;(this.world.oceanMat.uniforms.uNight as { value: number }).value = night

    // ذرات محیطی بایوم
    this.vfx.ambient.setAnchor(pos)
    const mode = isTitle ? 'leaf'
      : biome.id === 'woods' ? (night > 0.4 ? 'firefly' : 'leaf')
      : biome.id === 'frozen' ? 'snow'
      : biome.id === 'blasted' ? 'ember'
      : biome.id === 'swamp' ? 'spore'
      : (biome.id as string) === 'meadow' ? 'leaf'
      : 'none'
    this.vfx.ambient.setMode(mode as 'none', pos)

    // اعلام ورود به ناحیه
    this.zoneTimerAcc += dt
    if (this.zoneTimerAcc > 0.5) {
      this.zoneTimerAcc = 0
      const key = biome.id
      if (key !== this.lastBiome && !isTitle) {
        this.lastBiome = key
        st.set({
          zoneName: biome.name,
          zoneSub: biome.sub,
          zoneDanger: biome.danger,
          zoneTick: st.zoneTick + 1,
        })
      }
    }
  }

  dispose() {
    this.save()
  }
}

export function getTip(i: number): string { return TIPS[i % TIPS.length] }
