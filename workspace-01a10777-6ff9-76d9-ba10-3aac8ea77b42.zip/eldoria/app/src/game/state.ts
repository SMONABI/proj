// ═══ وضعیت مشترک بازی و رابط کاربری (zustand) ═══
import { create } from 'zustand'
import type { ClassId, QuestDef } from './data'
import type { PadKind } from './gamepad'

export type GamePhase = 'title' | 'playing' | 'dead'

/** آخرین وسیله‌ای که بازیکن با آن ورودی داده — برای نمایش راهنمای درست */
export type InputMode = 'kb' | 'pad'

export interface QuestState {
  def: QuestDef
  count: number
  status: 'available' | 'active' | 'ready' | 'done'
}

export interface DialogState {
  npcId: string
  npcName: string
  npcRole: string
  text: string
  quest?: QuestState
  canAccept?: boolean
  canComplete?: boolean
}

interface GameState {
  phase: GamePhase
  classId: ClassId | null
  level: number
  xp: number
  xpNext: number
  hp: number
  hpMax: number
  mana: number
  manaMax: number
  gold: number
  potions: number
  attack: number
  zoneName: string
  zoneSub: string
  zoneDanger: boolean
  zoneTick: number
  kills: number
  quests: QuestState[]
  dialog: DialogState | null
  cooldowns: number[]
  buffT: number
  bossName: string | null
  bossHp: number
  bossHpMax: number
  companionName: string
  companionTier: number
  muted: boolean
  hasSave: boolean
  toast: string | null
  lowHp: boolean
  hurtTick: number
  levelUpTick: number
  interactHint: string | null
  showHelp: boolean
  /** آخرین وسیله‌ی ورودی — راهنماها بر این اساس عوض می‌شوند */
  inputMode: InputMode
  padConnected: boolean
  padKind: PadKind
  /** کلاس انتخاب‌شده در صفحه‌ی عنوان (دسته هم می‌تواند تغییرش دهد) */
  titleClass: ClassId

  set: (p: Partial<GameState>) => void
}

export const useGame = create<GameState>((set) => ({
  phase: 'title',
  classId: null,
  level: 1,
  xp: 0,
  xpNext: 80,
  hp: 100,
  hpMax: 100,
  mana: 50,
  manaMax: 50,
  gold: 0,
  potions: 3,
  attack: 10,
  zoneName: 'شهر الدوریا',
  zoneSub: 'منطقه امن',
  zoneDanger: false,
  zoneTick: 0,
  kills: 0,
  quests: [],
  dialog: null,
  cooldowns: [0, 0, 0, 0],
  buffT: 0,
  bossName: null,
  bossHp: 0,
  bossHpMax: 0,
  companionName: 'توله گرگ',
  companionTier: 0,
  muted: false,
  hasSave: false,
  toast: null,
  lowHp: false,
  hurtTick: 0,
  levelUpTick: 0,
  interactHint: null,
  showHelp: false,
  inputMode: 'kb',
  padConnected: false,
  padKind: 'generic',
  titleClass: 'warrior',

  set: (p) => set(p),
}))
