// ═══ دشمنان، باس‌ها، مدیر اسپان، همراه گرگ ═══
import * as THREE from 'three'
import { MOBS } from './data'
import type { MobDef, MobKind } from './data'
import { buildMob } from './charactergfx'
import type { MobRig } from './charactergfx'
import { World, makeLabel } from './world'
import { VFX } from './vfx'
import { clamp, damp } from './noise'
import { Player } from './player'
import { disposeObject } from './charactergfx'

export interface EnemyCtx {
  world: World
  vfx: VFX
  onPlayerHit: (dmg: number, from: THREE.Vector3) => void
  onKill: (e: Enemy) => void
  onAggro?: (e: Enemy) => void
}

let eid = 0

/**
 * کلید یکتای پد اسپان.
 * ⚠️ پیش‌تر در دو جا دو فرمول متفاوت استفاده می‌شد (یکی با Math.round و یکی بدون آن)
 * و چون مختصات پدها اعشاری‌اند، هیچ‌وقت تطابق نمی‌کردند؛ نتیجه: تایمر respawn
 * کاملاً بی‌اثر بود و نقشه‌ی respawn هم هرگز پاک نمی‌شد (نشتی حافظه).
 * حالا هر دو سمت از همین تابع استفاده می‌کنند.
 */
export const padKey = (x: number, z: number) => Math.round(x) * 1000 + Math.round(z)

export class Enemy {
  id = ++eid
  def: MobDef
  rig: MobRig
  hp: number
  maxHp: number
  pos: THREE.Vector3
  vel = new THREE.Vector3()
  yaw = 0
  state: 'idle' | 'chase' | 'windup' | 'recover' | 'dead' = 'idle'
  stateT = 0
  animT = Math.random() * 10
  wanderT = 0
  wanderDir = 0
  spawnPos: THREE.Vector3
  hpBar: THREE.Group
  hpFg: THREE.Sprite
  dead = false
  deadT = 0
  hitFlash = 0
  slow = 0
  /** تایمر respawn این دشمن ثبت شده است؟ (تا هر فریم دوباره نوشته نشود) */
  respawnLogged = false
  private colliders: { x: number; z: number; r: number }[] = []
  private ctx: EnemyCtx

  constructor(def: MobDef, x: number, z: number, ctx: EnemyCtx, scene: THREE.Scene) {
    this.ctx = ctx
    this.def = def
    this.hp = def.hp
    this.maxHp = def.hp
    this.rig = buildMob(def.kind, def.scale)
    this.pos = new THREE.Vector3(x, ctx.world.height(x, z), z)
    this.spawnPos = this.pos.clone()
    this.rig.group.position.copy(this.pos)
    scene.add(this.rig.group)

    // نوار جان
    this.hpBar = new THREE.Group()
    const bgMat = new THREE.SpriteMaterial({ color: 0x1a1210, depthWrite: false })
    const bg = new THREE.Sprite(bgMat)
    bg.scale.set(1.1, 0.13, 1)
    const fgMat = new THREE.SpriteMaterial({ color: def.boss ? 0xc8452c : 0xd84a3a, depthWrite: false })
    this.hpFg = new THREE.Sprite(fgMat)
    this.hpFg.scale.set(1.04, 0.085, 1)
    this.hpFg.position.z = 0.001
    this.hpBar.add(bg, this.hpFg)
    this.hpBar.position.y = this.rig.hitY + (def.boss ? 1.3 : 0.75)
    this.hpBar.visible = false
    this.rig.group.add(this.hpBar)
    if (def.boss) {
      const label = makeLabel(def.name, '#ffb0a0', 'rgba(30,8,6,0.75)')
      label.position.y = 1.05
      label.scale.multiplyScalar(1.6)
      this.hpBar.add(label)
    }
  }

  takeDamage(dmg: number, fromPos: THREE.Vector3, knock = 3): boolean {
    if (this.dead) return false
    this.hp -= dmg
    this.hitFlash = 0.18
    this.hpBar.visible = true
    const ratio = clamp(this.hp / this.maxHp, 0, 1)
    this.hpFg.scale.x = 1.04 * ratio
    this.hpFg.position.x = -(1.04 * (1 - ratio)) / 2
    const dir = this.pos.clone().sub(fromPos).setY(0).normalize()
    this.vel.addScaledVector(dir, knock)
    if (this.state === 'idle') this.state = 'chase'
    if (this.hp <= 0) {
      this.dead = true
      this.state = 'dead'
      this.deadT = 0
      this.hpBar.visible = false
      this.ctx.onKill(this)
      return true
    }
    return false
  }

  update(dt: number, player: Player, t: number) {
    this.animT += dt
    this.slow = Math.max(0, this.slow - dt)
    const rig = this.rig

    if (this.dead) {
      this.deadT += dt
      const k = this.deadT / 0.8
      rig.group.scale.setScalar(this.def.scale * Math.max(0.01, 1 - k))
      rig.group.rotation.z = k * 1.2
      rig.group.position.y = this.pos.y - k * 0.5
      return this.deadT > 0.8
    }

    // فلش قرمز برخورد
    if (this.hitFlash > 0) {
      this.hitFlash -= dt
      const f = this.hitFlash > 0 ? 1 : 0
      for (const m of rig.emissives) m.emissiveIntensity = (this.def.boss ? 1.8 : 1.4) + f * 2.5
    }

    const toPlayer = player.pos.clone().sub(this.pos)
    toPlayer.y = 0
    const dist = toPlayer.length()
    const distHome = this.pos.distanceTo(this.spawnPos)
    const speedMul = this.slow > 0 ? 0.45 : 1
    this.stateT += dt

    switch (this.state) {
      case 'idle': {
        // پرسه‌زدن
        this.wanderT -= dt
        if (this.wanderT <= 0) {
          this.wanderT = 2 + Math.random() * 3
          this.wanderDir = Math.random() * Math.PI * 2
        }
        if (this.wanderT > 1.2 && distHome < 12) {
          this.vel.x = damp(this.vel.x, Math.sin(this.wanderDir) * this.def.speed * 0.25, 4, dt)
          this.vel.z = damp(this.vel.z, Math.cos(this.wanderDir) * this.def.speed * 0.25, 4, dt)
        } else {
          this.vel.x = damp(this.vel.x, 0, 6, dt)
          this.vel.z = damp(this.vel.z, 0, 6, dt)
        }
        if (dist < this.def.aggroR && player.state !== 'dead') {
          this.state = 'chase'
          this.ctx.onAggro?.(this)
        }
        break
      }
      case 'chase': {
        if (dist > this.def.aggroR + 14 || distHome > 55 || player.state === 'dead') {
          this.state = 'idle'
          this.hpBar.visible = this.def.boss ? this.hpBar.visible : false
          break
        }
        const dir = toPlayer.normalize()
        if (dist > this.def.atkR * 0.9) {
          this.vel.x = damp(this.vel.x, dir.x * this.def.speed * speedMul, 7, dt)
          this.vel.z = damp(this.vel.z, dir.z * this.def.speed * speedMul, 7, dt)
        } else {
          this.vel.x = damp(this.vel.x, 0, 10, dt)
          this.vel.z = damp(this.vel.z, 0, 10, dt)
          this.state = 'windup'
          this.stateT = 0
        }
        break
      }
      case 'windup': {
        this.vel.x = damp(this.vel.x, 0, 12, dt)
        this.vel.z = damp(this.vel.z, 0, 12, dt)
        const dir = toPlayer.clone().normalize()
        this.yaw = dampAngle(this.yaw, Math.atan2(dir.x, dir.z), 8, dt)
        // خیز
        rig.parts.body.position.y += Math.sin(clamp(this.stateT / 0.45, 0, 1) * Math.PI) * 0.02
        if (this.stateT >= 0.45) {
          this.state = 'recover'
          this.stateT = 0
          if (dist < this.def.atkR + 0.8 && player.iframes <= 0) {
            this.ctx.onPlayerHit(this.def.dmg * (0.85 + Math.random() * 0.3), this.pos)
            this.ctx.vfx.blood(player.pos.clone().setY(player.pos.y + 1.1))
          } else {
            this.ctx.vfx.dust(this.pos, 3)
          }
          // ضربه سنگین باس: موج زمین
          if (this.def.boss) {
            this.ctx.vfx.ring(this.pos, 0xffaa66, 3.5, 0.45)
            this.ctx.vfx.shake(0.3)
          }
        }
        break
      }
      case 'recover': {
        if (this.stateT > 0.55 + (this.def.boss ? 0.35 : 0)) {
          this.state = dist < this.def.aggroR + 10 ? 'chase' : 'idle'
          this.stateT = 0
        }
        break
      }
    }

    // حرکت و برخورد
    this.pos.x += this.vel.x * dt
    this.pos.z += this.vel.z * dt
    this.resolveColliders()
    this.pos.y = this.ctx.world.height(this.pos.x, this.pos.z)
    // جدایی از بازیکن
    const sep = this.pos.clone().sub(player.pos).setY(0)
    const sepD = sep.length()
    const minD = this.rig.radius + 0.5
    if (sepD < minD && sepD > 0.001) {
      this.pos.addScaledVector(sep.normalize(), (minD - sepD))
    }

    // ─── منطقه‌ی امن شهر: هیچ هیولایی حق ورود ندارد ───
    // راهنما و نکته‌های بازی این را وعده می‌دادند اما هیچ‌جا اعمال نمی‌شد.
    const safeR = this.ctx.world.citySafeR + this.rig.radius
    const cdist = Math.hypot(this.pos.x, this.pos.z)
    if (cdist < safeR && cdist > 0.001) {
      const k = safeR / cdist
      this.pos.x *= k; this.pos.z *= k
      this.vel.x = 0; this.vel.z = 0
      if (this.state === 'chase') {
        this.state = 'idle'
        this.hpBar.visible = this.def.boss ? this.hpBar.visible : false
      }
    }

    const moveSp = Math.sqrt(this.vel.x ** 2 + this.vel.z ** 2)
    if (moveSp > 0.3 && this.state !== 'windup') {
      this.yaw = dampAngle(this.yaw, Math.atan2(this.vel.x, this.vel.z), 9, dt)
    }
    rig.anim(t, clamp(moveSp / this.def.speed, 0, 1.4), this.state !== 'idle')
    rig.group.position.copy(this.pos)
    rig.group.rotation.y = this.yaw
    return false
  }

  private resolveColliders() {
    const near = this.ctx.world.collidersNear(this.pos.x, this.pos.z, this.colliders)
    for (const c of near) {
      const dx = this.pos.x - c.x, dz = this.pos.z - c.z
      const min = c.r + this.rig.radius * 0.6
      const d2 = dx * dx + dz * dz
      if (d2 < min * min && d2 > 0.0001) {
        const d = Math.sqrt(d2)
        this.pos.x = c.x + (dx / d) * min
        this.pos.z = c.z + (dz / d) * min
      }
    }
  }

  dispose() {
    this.ctx.world
    this.rig.group.parent?.remove(this.rig.group)
    disposeObject(this.rig.group)
  }
}

function dampAngle(a: number, b: number, lambda: number, dt: number) {
  let d = (b - a) % (Math.PI * 2)
  if (d > Math.PI) d -= Math.PI * 2
  if (d < -Math.PI) d += Math.PI * 2
  return a + d * (1 - Math.exp(-lambda * dt))
}

// ═══ مدیر دشمنان ═══
export class EnemyManager {
  enemies: Enemy[] = []
  private respawn = new Map<number, number>()
  private scene: THREE.Scene
  private ctx: EnemyCtx
  activeBoss: Enemy | null = null

  constructor(ctx: EnemyCtx, scene: THREE.Scene) {
    this.ctx = ctx
    this.scene = scene
  }

  countOf(kind: MobKind): number {
    return this.enemies.filter((e) => !e.dead && e.def.kind === kind).length
  }

  update(dt: number, player: Player, t: number) {
    const world = this.ctx.world
    // اسپان
    let alive = 0
    for (const e of this.enemies) if (!e.dead) alive++
    if (alive < 15) {
      for (const pad of world.spawnPads) {
        const d = Math.hypot(pad.x - player.pos.x, pad.z - player.pos.z)
        if (d > 140 || d < 18) continue
        const key = padKey(pad.x, pad.z)
        const rt = this.respawn.get(key)
        if (rt !== undefined && t < rt) continue
        const def = MOBS.find((m) => m.kind === (pad.kind as MobKind))!
        if (def.boss && this.enemies.some((e) => !e.dead && e.def.kind === def.kind)) continue
        if (this.countOf(def.kind) >= (def.boss ? 1 : 8)) continue
        const e = new Enemy(def, pad.x, pad.z, this.ctx, this.scene)
        this.enemies.push(e)
        this.respawn.delete(key)
        alive++
        if (alive >= 15) break
      }
    }
    // به‌روزرسانی
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i]
      const remove = e.update(dt, player, t)
      if (remove) {
        e.dispose()
        this.enemies.splice(i, 1)
        continue
      }
      if (e.dead && !e.respawnLogged) {
        e.respawnLogged = true
        this.respawn.set(padKey(e.spawnPos.x, e.spawnPos.z), t + (e.def.boss ? 90 : 24))
      }
    }
    // پاک‌سازی تایمرهای منقضی تا نقشه بی‌نهایت رشد نکند
    if (this.respawn.size > 64) {
      for (const [k, until] of this.respawn) if (t >= until) this.respawn.delete(k)
    }
    // جدایی متقابل دشمنان (فقط نزدیک‌ها)
    for (let i = 0; i < this.enemies.length; i++) {
      const a = this.enemies[i]
      if (a.dead) continue
      for (let j = i + 1; j < this.enemies.length; j++) {
        const b = this.enemies[j]
        if (b.dead) continue
        const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z
        const d2 = dx * dx + dz * dz
        const min = (a.rig.radius + b.rig.radius) * 0.8
        if (d2 < min * min && d2 > 0.001) {
          const d = Math.sqrt(d2)
          const push = (min - d) / 2
          const nx = dx / d, nz = dz / d
          a.pos.x -= nx * push; a.pos.z -= nz * push
          b.pos.x += nx * push; b.pos.z += nz * push
        }
      }
    }
    // باس فعال
    this.activeBoss = null
    for (const e of this.enemies) {
      if (e.def.boss && !e.dead && e.state !== 'idle') {
        const d = e.pos.distanceTo(player.pos)
        if (d < 45) { this.activeBoss = e; break }
      }
    }
  }

  /** نزدیک‌ترین دشمن زنده در محدوده */
  nearest(pos: THREE.Vector3, maxR: number, coneDir?: THREE.Vector3, coneCos = -1): Enemy | null {
    let best: Enemy | null = null
    let bd = maxR
    for (const e of this.enemies) {
      if (e.dead) continue
      const d = e.pos.distanceTo(pos)
      if (d < bd) {
        if (coneDir) {
          // بدون تخصیص Vector3 (این تابع هر فریم برای هر دشمن صدا زده می‌شود)
          let dx = e.pos.x - pos.x, dz = e.pos.z - pos.z
          const len = Math.hypot(dx, dz)
          if (len > 0.0001) { dx /= len; dz /= len }
          if (dx * coneDir.x + dz * coneDir.z < coneCos) continue
        }
        best = e
        bd = d
      }
    }
    return best
  }

  inCone(pos: THREE.Vector3, dir: THREE.Vector3, range: number, cos: number): Enemy[] {
    const out: Enemy[] = []
    for (const e of this.enemies) {
      if (e.dead) continue
      const dx = e.pos.x - pos.x, dz = e.pos.z - pos.z
      const d = Math.hypot(dx, dz)
      if (d > range + e.rig.radius) continue
      if (d > 0.5 && (dx / d) * dir.x + (dz / d) * dir.z < cos) continue
      out.push(e)
    }
    return out
  }

  clear() {
    for (const e of this.enemies) e.dispose()
    this.enemies = []
    this.respawn.clear()
  }
}

// ═══ همراه: گرگ وفادار ═══
export class Companion {
  rig: MobRig
  pos = new THREE.Vector3()
  yaw = 0
  tier = 0
  atkCd = 0
  animT = 0
  private scene: THREE.Scene
  label: THREE.Sprite | null = null
  private ctx: { world: World; vfx: VFX }

  constructor(ctx: { world: World; vfx: VFX }, scene: THREE.Scene) {
    this.ctx = ctx
    this.scene = scene
    this.rig = buildMob('wolf', 0.72)
    this.tint(0x8a7a5c)
    scene.add(this.rig.group)
    this.setTier(0)
  }

  private tint(c: number) {
    this.rig.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        const m = o.material as THREE.MeshStandardMaterial
        if (m.color && !m.emissive?.getHex()) m.color.lerp(new THREE.Color(c), 0.4)
      }
    })
  }

  setTier(tier: number) {
    if (tier === this.tier && this.label) return
    this.tier = tier
    const scales = [0.72, 1.0, 1.35]
    const names = ['توله گرگ', 'گرگ جوان', 'گرگ آلفا']
    this.rig.group.scale.setScalar(scales[tier])
    if (this.label) {
      this.rig.group.remove(this.label)
      this.label.material.map?.dispose()
      this.label.material.dispose()
    }
    this.label = makeLabel(names[tier], '#cfe8b0', 'rgba(16,24,10,0.66)', 0.75)
    this.label.position.y = 1.9
    this.rig.group.add(this.label)
  }

  get damage(): number { return 6 + this.tier * 7 }

  update(dt: number, player: Player, target: Enemy | null, onHit: (e: Enemy, dmg: number) => void) {
    this.animT += dt
    this.atkCd -= dt
    // هدف: دشمن بازیکن یا نزدیک‌ترین
    let dest: THREE.Vector3
    if (target && !target.dead) {
      dest = target.pos
    } else {
      // کنار بازیکن
      const side = new THREE.Vector3(Math.sin(player.yaw + 2.4), 0, Math.cos(player.yaw + 2.4))
      dest = player.pos.clone().addScaledVector(side, 1.6)
    }
    const to = dest.clone().sub(this.pos)
    to.y = 0
    const dist = to.length()
    const chasing = !!(target && !target.dead)
    const stop = chasing ? 1.4 : 0.5
    let sp = 0
    if (dist > stop) {
      sp = chasing ? 8.2 : dist > 8 ? 9.2 : 5.6
      const dir = to.normalize()
      this.pos.addScaledVector(dir, Math.min(sp * dt, dist))
      this.yaw = dampAngle(this.yaw, Math.atan2(dir.x, dir.z), 10, dt)
    }
    // تلپورت اگر خیلی دور شد
    if (this.pos.distanceTo(player.pos) > 34) {
      this.pos.copy(player.pos).add(new THREE.Vector3(2, 0, 2))
      this.ctx.vfx.puff(this.pos, 0xbac8a8, 6, 1.6)
    }
    // حمله
    if (chasing && dist < 1.9 && this.atkCd <= 0 && target) {
      this.atkCd = 1.15
      onHit(target, this.damage)
      this.ctx.vfx.hit(target.pos.clone().setY(target.pos.y + target.rig.hitY * 0.6), 0xffe8b0)
    }
    this.pos.y = this.ctx.world.height(this.pos.x, this.pos.z)
    this.rig.anim(this.animT, clamp(sp / 6, 0, 1.4), chasing)
    this.rig.group.position.copy(this.pos)
    this.rig.group.rotation.y = this.yaw
  }

  dispose() {
    this.scene.remove(this.rig.group)
    disposeObject(this.rig.group)
  }
}
