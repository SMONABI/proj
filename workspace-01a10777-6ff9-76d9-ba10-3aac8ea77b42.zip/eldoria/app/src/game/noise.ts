// ═══ ابزارهای نویز و تصادف قطعی ═══

export function mulberry32(seed: number) {
  let a = seed >>> 0
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// هش صحیح قطعی برای نویز مقداری
function hash2(x: number, y: number): number {
  let h = Math.imul(x, 374761393) + Math.imul(y, 668265263)
  h = Math.imul(h ^ (h >>> 13), 1274126177)
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296
}

function smooth(t: number) { return t * t * (3 - 2 * t) }

// نویز مقداری دوبعدی نرم در بازه [0,1]
export function vnoise(x: number, y: number): number {
  const xi = Math.floor(x), yi = Math.floor(y)
  const xf = x - xi, yf = y - yi
  const u = smooth(xf), v = smooth(yf)
  const a = hash2(xi, yi), b = hash2(xi + 1, yi)
  const c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1)
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v
}

export function fbm(x: number, y: number, oct = 4, lac = 2, gain = 0.5): number {
  let amp = 0.5, freq = 1, sum = 0, norm = 0
  for (let i = 0; i < oct; i++) {
    sum += amp * vnoise(x * freq, y * freq)
    norm += amp
    amp *= gain; freq *= lac
  }
  return sum / norm
}

export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v))
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t
export const smoothstep = (a: number, b: number, t: number) => {
  const x = clamp((t - a) / (b - a), 0, 1)
  return x * x * (3 - 2 * x)
}
// درون‌یابی نرم با نرمی مشخص — برای دنبال‌کردن دوربین و حرکت
export const damp = (a: number, b: number, lambda: number, dt: number) =>
  lerp(a, b, 1 - Math.exp(-lambda * dt))

export function dist2d(x1: number, z1: number, x2: number, z2: number) {
  const dx = x2 - x1, dz = z2 - z1
  return Math.sqrt(dx * dx + dz * dz)
}

// اعداد فارسی
const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
export function faNum(n: number | string): string {
  return String(n).replace(/\d/g, (d) => FA_DIGITS[+d])
}
