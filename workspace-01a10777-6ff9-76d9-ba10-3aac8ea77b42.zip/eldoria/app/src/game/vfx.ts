// ═══ جلوه‌های بصری: ذرات، حلقه‌ها، اعداد خسارت، لرزش دوربین ═══
import * as THREE from 'three'
import { softTexture } from './charactergfx'
import { clamp } from './noise'

const pVert = /* glsl */ `
attribute float aSize;
attribute vec3 aColor;
attribute float aAlpha;
varying vec3 vColor;
varying float vAlpha;
void main() {
  vColor = aColor;
  vAlpha = aAlpha;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * (240.0 / -mv.z);
  gl_Position = projectionMatrix * mv;
}
`
const pFrag = /* glsl */ `
uniform sampler2D uTex;
varying vec3 vColor;
varying float vAlpha;
void main() {
  vec4 t = texture2D(uTex, gl_PointCoord);
  gl_FragColor = vec4(vColor, t.a * vAlpha);
}
`

interface Particle {
  alive: boolean
  x: number; y: number; z: number
  vx: number; vy: number; vz: number
  life: number; maxLife: number
  size: number
  r: number; g: number; b: number
  grav: number; drag: number
}

export class ParticlePool {
  points: THREE.Points
  private parts: Particle[]
  private posA: THREE.BufferAttribute
  private colA: THREE.BufferAttribute
  private sizeA: THREE.BufferAttribute
  private alphaA: THREE.BufferAttribute
  private cursor = 0

  constructor(scene: THREE.Scene, cap: number, additive = true) {
    this.parts = Array.from({ length: cap }, () => ({
      alive: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, size: 1, r: 1, g: 1, b: 1, grav: 0, drag: 0,
    }))
    const geo = new THREE.BufferGeometry()
    this.posA = new THREE.BufferAttribute(new Float32Array(cap * 3), 3)
    this.colA = new THREE.BufferAttribute(new Float32Array(cap * 3), 3)
    this.sizeA = new THREE.BufferAttribute(new Float32Array(cap), 1)
    this.alphaA = new THREE.BufferAttribute(new Float32Array(cap), 1)
    geo.setAttribute('position', this.posA)
    geo.setAttribute('aColor', this.colA)
    geo.setAttribute('aSize', this.sizeA)
    geo.setAttribute('aAlpha', this.alphaA)
    const mat = new THREE.ShaderMaterial({
      vertexShader: pVert, fragmentShader: pFrag,
      uniforms: { uTex: { value: softTexture() } },
      transparent: true, depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    })
    this.points = new THREE.Points(geo, mat)
    this.points.frustumCulled = false
    this.points.renderOrder = 20
    scene.add(this.points)
  }

  spawn(x: number, y: number, z: number, vx: number, vy: number, vz: number,
    color: THREE.Color, size: number, life: number, grav = 0, drag = 0) {
    const p = this.parts[this.cursor]
    this.cursor = (this.cursor + 1) % this.parts.length
    p.alive = true
    p.x = x; p.y = y; p.z = z
    p.vx = vx; p.vy = vy; p.vz = vz
    p.life = life; p.maxLife = life
    p.size = size
    p.r = color.r; p.g = color.g; p.b = color.b
    p.grav = grav; p.drag = drag
  }

  update(dt: number) {
    const pa = this.posA.array as Float32Array
    const ca = this.colA.array as Float32Array
    const sa = this.sizeA.array as Float32Array
    const aa = this.alphaA.array as Float32Array
    for (let i = 0; i < this.parts.length; i++) {
      const p = this.parts[i]
      if (!p.alive) { aa[i] = 0; sa[i] = 0; continue }
      p.life -= dt
      if (p.life <= 0) { p.alive = false; aa[i] = 0; sa[i] = 0; continue }
      p.vy -= p.grav * dt
      const dr = 1 - p.drag * dt
      p.vx *= dr; p.vy *= dr; p.vz *= dr
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt
      const t = p.life / p.maxLife
      pa[i * 3] = p.x; pa[i * 3 + 1] = p.y; pa[i * 3 + 2] = p.z
      ca[i * 3] = p.r; ca[i * 3 + 1] = p.g; ca[i * 3 + 2] = p.b
      sa[i] = p.size * (0.5 + t * 0.5)
      aa[i] = clamp(t * 2, 0, 1)
    }
    this.posA.needsUpdate = true
    this.colA.needsUpdate = true
    this.sizeA.needsUpdate = true
    this.alphaA.needsUpdate = true
  }

  burst(pos: THREE.Vector3, color: number, n: number, speed: number, size: number, life: number, grav = 6, up = 2) {
    const c = new THREE.Color(color)
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      const el = Math.random() * Math.PI - Math.PI / 2
      const sp = speed * (0.4 + Math.random() * 0.8)
      this.spawn(
        pos.x, pos.y, pos.z,
        Math.cos(a) * Math.cos(el) * sp, Math.abs(Math.sin(el)) * sp + up, Math.sin(a) * Math.cos(el) * sp,
        c.clone().offsetHSL(0, 0, (Math.random() - 0.5) * 0.2),
        size * (0.7 + Math.random() * 0.7), life * (0.6 + Math.random() * 0.8), grav, 1.2,
      )
    }
  }
}

interface Ring {
  mesh: THREE.Mesh
  t: number
  dur: number
  maxR: number
}

export class VFX {
  sparks: ParticlePool
  smoke: ParticlePool
  private rings: Ring[] = []
  private ringGeo: THREE.RingGeometry
  private scene: THREE.Scene
  shakeAmp = 0
  private dmgLayer: HTMLDivElement
  ambient: AmbientFX

  constructor(scene: THREE.Scene, dmgLayer: HTMLDivElement, isMobile: boolean) {
    this.scene = scene
    this.dmgLayer = dmgLayer
    const cap = isMobile ? 420 : 900
    this.sparks = new ParticlePool(scene, cap, true)
    this.smoke = new ParticlePool(scene, Math.floor(cap / 2.4), false)
    this.ringGeo = new THREE.RingGeometry(0.86, 1, 42)
    this.ringGeo.rotateX(-Math.PI / 2)
    this.ambient = new AmbientFX(scene)
  }

  hit(pos: THREE.Vector3, color = 0xffd890, big = false) {
    this.sparks.burst(pos, color, big ? 26 : 13, big ? 9 : 6.5, big ? 1.5 : 1.05, 0.5, 12, 2.5)
    this.shake(big ? 0.32 : 0.13)
  }

  blood(pos: THREE.Vector3, color = 0xc8452c) {
    this.sparks.burst(pos, color, 10, 5, 0.9, 0.45, 14, 2)
  }

  soul(pos: THREE.Vector3, color = 0x9ce84a) {
    const c = new THREE.Color(color)
    for (let i = 0; i < 16; i++) {
      const a = Math.random() * Math.PI * 2
      const r = Math.random() * 0.6
      this.sparks.spawn(pos.x + Math.cos(a) * r, pos.y + Math.random() * 0.8, pos.z + Math.sin(a) * r,
        Math.cos(a) * 0.4, 2.4 + Math.random() * 2, Math.sin(a) * 0.4,
        c, 1.2, 1.1, -1.5, 0.6)
    }
  }

  dust(pos: THREE.Vector3, n = 5) {
    const c = new THREE.Color(0x9a8a72)
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      this.smoke.spawn(pos.x, pos.y + 0.08, pos.z, Math.cos(a) * (1 + Math.random()), 0.6 + Math.random(), Math.sin(a) * (1 + Math.random()),
        c, 1.6 + Math.random(), 0.7, -0.4, 2.2)
    }
  }

  puff(pos: THREE.Vector3, color: number, n = 8, size = 2.2) {
    const c = new THREE.Color(color)
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2
      this.smoke.spawn(pos.x, pos.y, pos.z, Math.cos(a) * 1.4, 1 + Math.random() * 1.5, Math.sin(a) * 1.4,
        c, size * (0.7 + Math.random() * 0.7), 0.9, -0.8, 1.8)
    }
  }

  trail(pos: THREE.Vector3, color: number, size = 0.9, life = 0.4) {
    this.sparks.spawn(pos.x, pos.y, pos.z, 0, 0, 0, new THREE.Color(color), size, life, 0, 0)
  }

  ring(pos: THREE.Vector3, color: number, maxR: number, dur = 0.5, y = 0.15) {
    const mat = new THREE.MeshBasicMaterial({
      color, transparent: true, opacity: 0.9, side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending, depthWrite: false,
    })
    const mesh = new THREE.Mesh(this.ringGeo, mat)
    mesh.position.set(pos.x, pos.y + y, pos.z)
    mesh.renderOrder = 15
    this.scene.add(mesh)
    this.rings.push({ mesh, t: 0, dur, maxR })
  }

  shake(amp: number) {
    this.shakeAmp = Math.min(this.shakeAmp + amp, 0.7)
  }

  damageNumber(worldPos: THREE.Vector3, text: string, cls = '', camera: THREE.PerspectiveCamera) {
    const v = worldPos.clone().project(camera)
    if (v.z > 1) return
    const x = (v.x * 0.5 + 0.5) * window.innerWidth
    const y = (-v.y * 0.5 + 0.5) * window.innerHeight
    const el = document.createElement('div')
    el.textContent = text
    el.className = `fixed pointer-events-none font-black z-30 ${cls}`
    el.style.cssText = `left:${x + (Math.random() - 0.5) * 46}px; top:${y - 10}px; transform:translate(-50%,0);
      animation:dmg-pop 0.85s ease-out forwards; text-shadow:0 2px 0 rgba(0,0,0,0.6), 0 0 12px rgba(0,0,0,0.4);
      font-size:${cls.includes('crit') ? '26px' : '17px'};`
    this.dmgLayer.appendChild(el)
    setTimeout(() => el.remove(), 900)
  }

  update(dt: number) {
    this.sparks.update(dt)
    this.smoke.update(dt)
    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i]
      r.t += dt
      const k = r.t / r.dur
      if (k >= 1) {
        this.scene.remove(r.mesh)
        ;(r.mesh.material as THREE.Material).dispose()
        this.rings.splice(i, 1)
        continue
      }
      const e = 1 - Math.pow(1 - k, 3)
      r.mesh.scale.setScalar(0.2 + e * r.maxR)
      ;(r.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - k)
    }
    this.shakeAmp = Math.max(0, this.shakeAmp - dt * 2.4)
    this.ambient.update(dt)
  }
}

// ═══ ذرات محیطی بایوم: کرم‌ شب‌تاب، برف، جرقه آتش، هاگ ═══
type AmbientMode = 'none' | 'firefly' | 'snow' | 'ember' | 'spore' | 'leaf'

export class AmbientFX {
  private pool: ParticlePool
  private mode: AmbientMode = 'none'
  private anchor = new THREE.Vector3()
  private timer = 0

  constructor(scene: THREE.Scene) {
    this.pool = new ParticlePool(scene, 260, true)
  }

  setMode(m: AmbientMode, anchor: THREE.Vector3) {
    this.mode = m
    this.anchor.copy(anchor)
  }

  setAnchor(a: THREE.Vector3) { this.anchor.copy(a) }

  update(dt: number) {
    this.timer -= dt
    const m = this.mode
    if (m !== 'none' && this.timer <= 0) {
      this.timer = m === 'snow' ? 0.03 : 0.09
      const a = Math.random() * Math.PI * 2
      const r = 6 + Math.random() * 26
      const x = this.anchor.x + Math.cos(a) * r
      const z = this.anchor.z + Math.sin(a) * r
      if (m === 'firefly') {
        this.pool.spawn(x, this.anchor.y + 0.5 + Math.random() * 2.5, z,
          (Math.random() - 0.5) * 0.5, (Math.random() - 0.3) * 0.3, (Math.random() - 0.5) * 0.5,
          new THREE.Color(0xbaff6a), 0.9, 3.4, -0.05, 0.2)
      } else if (m === 'snow') {
        this.pool.spawn(x, this.anchor.y + 9 + Math.random() * 6, z,
          (Math.random() - 0.5) * 0.8 + 1.2, -1.4 - Math.random(), (Math.random() - 0.5) * 0.8,
          new THREE.Color(0xf0f6ff), 0.85, 7, 0, 0)
      } else if (m === 'ember') {
        this.pool.spawn(x, this.anchor.y + 0.2, z,
          (Math.random() - 0.5) * 0.6, 1.4 + Math.random() * 1.8, (Math.random() - 0.5) * 0.6,
          new THREE.Color(Math.random() > 0.5 ? 0xff8a2c : 0xffc23c), 0.8, 2.6, -0.9, 0.4)
      } else if (m === 'spore') {
        this.pool.spawn(x, this.anchor.y + 0.3 + Math.random() * 1.6, z,
          (Math.random() - 0.5) * 0.4, 0.25 + Math.random() * 0.3, (Math.random() - 0.5) * 0.4,
          new THREE.Color(0x9ac86a), 0.75, 4, -0.04, 0.3)
      } else if (m === 'leaf') {
        this.pool.spawn(x, this.anchor.y + 4 + Math.random() * 4, z,
          (Math.random() - 0.5) * 1.4 + 0.8, -0.7 - Math.random() * 0.5, (Math.random() - 0.5) * 1.4,
          new THREE.Color(Math.random() > 0.5 ? 0x7aa84a : 0xc8a83c), 0.9, 6, 0.05, 0.35)
      }
    }
    this.pool.update(dt)
  }
}
