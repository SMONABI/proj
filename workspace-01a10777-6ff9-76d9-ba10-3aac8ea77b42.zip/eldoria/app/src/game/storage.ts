// ═══ دسترسی ایمن به ذخیره‌سازی ═══
// چرا این فایل لازم است:
// در iframe سندباکس‌شده (مثل پیش‌نمایش داخل همین محیط) و در برخی حالت‌های
// مرورگر با مسدودسازی کوکی، دسترسی به localStorage یک SecurityError پرتاب
// می‌کند. چون این کار داخل سازنده‌ی کلاس Game انجام می‌شد و آن هم در useEffect
// فراخوانی می‌شد، استثنا به React می‌رسید و کل درخت را از ریشه unmount می‌کرد
// → نتیجه: صفحه‌ی کاملاً سفید.
//
// این پوشش، بازی را هرگز به‌خاطر ذخیره‌سازی نمی‌خواباند: اگر localStorage
// در دسترس نباشد، به یک حافظه‌ی موقت درون‌برنامه‌ای سقوط می‌کند (بازی کار
// می‌کند، فقط پیشرفت بین رفرش‌ها ذخیره نمی‌شود).

const memory = new Map<string, string>()

let ls: Storage | null = null
try {
  // خودِ دسترسی ممکن است پرتاب کند (نه فقط فراخوانی متدها)
  ls = typeof window !== 'undefined' ? window.localStorage : null
  if (ls) {
    const probe = '__eldoria_probe__'
    ls.setItem(probe, '1')
    ls.removeItem(probe)
  }
} catch {
  ls = null
}

/** آیا ذخیره‌سازی پایدار در دسترس است؟ (برای اطلاع‌دادن به بازیکن) */
export const persistentStorage: boolean = ls !== null

export function loadRaw(key: string): string | null {
  try {
    if (ls) return ls.getItem(key)
  } catch { /* سقوط به حافظه */ }
  return memory.get(key) ?? null
}

export function saveRaw(key: string, value: string): void {
  try {
    if (ls) { ls.setItem(key, value); return }
  } catch { /* سقوط به حافظه */ }
  memory.set(key, value)
}

/** خواندن ایمن JSON — هر مقدار خراب یا ناقص را نادیده می‌گیرد */
export function loadJson<T>(key: string): T | null {
  const raw = loadRaw(key)
  if (!raw) return null
  try {
    return JSON.parse(raw) as T
  } catch {
    return null
  }
}
