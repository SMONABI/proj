// ═══ پشتیبانی از دسته‌بازی (Gamepad API) ═══
//
// چرا کلاس و نه توابع پراکنده: Gamepad API هیچ رویدادی برای «تغییر وضعیت» نمی‌دهد؛
// باید هر فریم `navigator.getGamepads()` را نظرسنجی کنیم. پس یک نمونه‌ی واحد
// (`pad`) داریم که حلقه‌ی بازی هر فریم `poll()` صدایش می‌زند و بقیه‌ی کد فقط
// از نتیجه‌اش می‌خواند.
//
// ── چیدمان دکمه‌ها (نگاشت استاندارد W3C) ──
//   A = پرش · X = حمله · B = معجون · Y = تعامل
//   LB/RB/LT/RT = مهارت‌های ۱ تا ۴ · Start = راهنما · Back = صدا
//   استیک چپ = حرکت (آنالوگ) · استیک راست = دوربین · D-pad = حرکت/ناوبری منو
//
// سازگاری با انواع دسته‌ها: مرورگرهای امروزی تقریباً همیشه `mapping === 'standard'`
// می‌دهند (ایکس‌باکس، پلی‌استیشن، و اکثر دسته‌های عمومی). برای دسته‌های قدیمی‌تر
// که نگاشت استاندارد ندارند، یک نگاشت محافظه‌کارانه‌ی جایگزین ساخته می‌شود و
// فقط دکمه‌هایی که واقعاً روی دسته وجود دارند فعال می‌شوند.

export type PadKind = 'xbox' | 'playstation' | 'generic'
export type PadButton =
  | 'a' | 'b' | 'x' | 'y'
  | 'lb' | 'rb' | 'lt' | 'rt'
  | 'back' | 'start' | 'l3' | 'r3'
  | 'dup' | 'ddown' | 'dleft' | 'dright'

const STANDARD: Record<PadButton, number> = {
  a: 0, b: 1, x: 2, y: 3,
  lb: 4, rb: 5, lt: 6, rt: 7,
  back: 8, start: 9, l3: 10, r3: 11,
  dup: 12, ddown: 13, dleft: 14, dright: 15,
}

const DEADZONE_MOVE = 0.16
const DEADZONE_LOOK = 0.13
/** آستانه‌ی «فشرده» برای دکمه‌های آنالوگ (تریگرها) */
const TRIGGER_ON = 0.4

/** بازمقیاس پس از منطقه‌ی مرده تا حرکت از صفر شروع شود و پرش نداشته باشد */
function deadzone(v: number, dz: number): number {
  const a = Math.abs(v)
  if (a <= dz) return 0
  const t = (a - dz) / (1 - dz)
  // منحنی ملایم: دقت بیشتر نزدیک مرکز، سرعت کامل در انتها
  return Math.sign(v) * t * t
}

/** نام دکمه‌ها روی دسته، برای نمایش در رابط کاربری */
export const GLYPH: Record<PadKind, Record<string, string>> = {
  xbox: { a: 'A', b: 'B', x: 'X', y: 'Y', lb: 'LB', rb: 'RB', lt: 'LT', rt: 'RT', start: '☰', back: '⧉', dup: '▲', ddown: '▼', dleft: '◀', dright: '▶' },
  playstation: { a: '✕', b: '◯', x: '□', y: '△', lb: 'L1', rb: 'R1', lt: 'L2', rt: 'R2', start: 'Options', back: 'Share', dup: '▲', ddown: '▼', dleft: '◀', dright: '▶' },
  generic: { a: 'A', b: 'B', x: 'X', y: 'Y', lb: 'L1', rb: 'R1', lt: 'L2', rt: 'R2', start: 'Start', back: 'Select', dup: '▲', ddown: '▼', dleft: '◀', dright: '▶' },
}

type Actuator = { playEffect?: (type: string, params: Record<string, number>) => Promise<string> | void }

export class GamepadInput {
  connected = false
  kind: PadKind = 'generic'
  id = ''
  /** حرکت — قرارداد صفحه: x = راست، y = جلو (بالای استیک = مثبت) */
  moveX = 0
  moveY = 0
  /** دوربین — محورهای خام استیک راست (راست و پایین مثبت، مثل حرکت ماوس) */
  lookX = 0
  lookY = 0
  sprint = false

  private buttons: boolean[] = []
  private prevButtons: boolean[] = []
  private justSet = new Set<number>()
  private map: Partial<Record<PadButton, number>> = {}
  private index: number | null = null
  private notices: string[] = []
  /** آخرین زمانی که کاربر از دسته استفاده کرد (برای تشخیص حالت ورودی) */
  lastActivity = -Infinity

  constructor() {
    if (typeof window === 'undefined' || !navigator.getGamepads) return
    window.addEventListener('gamepadconnected', (e) => {
      const g = (e as GamepadEvent).gamepad
      if (!g) return
      this.adopt(g)
      this.lastActivity = performance.now()
      this.notices.push(`🎮 دسته وصل شد — ${this.friendlyName(g)}`)
    })
    window.addEventListener('gamepaddisconnected', () => {
      this.reset()
      this.notices.push('🎮 دسته قطع شد')
    })
  }

  /** نام قابل‌خوان برای نمایش به بازیکن */
  private friendlyName(g: Gamepad): string {
    const id = g.id
    if (this.kind === 'playstation') return 'دسته پلی‌استیشن'
    if (this.kind === 'xbox') return 'دسته ایکس‌باکس'
    if (/Generic|Unknown|undefined/i.test(id)) return 'دسته‌بازی'
    return id.length > 34 ? id.slice(0, 32) + '…' : id
  }

  /** فعال‌کردن دسته و تشخیص نوع و چیدمان آن */
  private adopt(g: Gamepad) {
    this.connected = true
    this.id = g.id
    this.index = g.index
    const low = g.id.toLowerCase()
    this.kind = /xbox|xinput|045e|gamepad \(standard/i.test(low) ? 'xbox'
      : /dualsense|dualshock|playstation|054c|wireless controller/i.test(low) ? 'playstation'
      : 'generic'
    this.map = this.deriveMap(g)
  }

  /**
   * ساخت نگاشت دکمه‌ها.
   * حالت استاندارد مستقیم استفاده می‌شود؛ در غیر این صورت یک چیدمان حداقلی
   * بر پایه‌ی تعداد دکمه‌های موجود ساخته می‌شود تا دسته‌های قدیمی هم کار کنند.
   */
  private deriveMap(g: Gamepad): Partial<Record<PadButton, number>> {
    const n = g.buttons.length
    if (g.mapping === 'standard') return { ...STANDARD }
    const out: Partial<Record<PadButton, number>> = {}
    const order: PadButton[] = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'back', 'start', 'l3', 'r3', 'dup', 'ddown', 'dleft', 'dright']
    // چیدمان رایج: چهار دکمه‌ی صورت، دو شانه، دو تریگر، back/start
    for (let i = 0; i < order.length && i < n; i++) out[order[i]] = i
    return out
  }

  private reset() {
    this.connected = false
    this.index = null
    this.moveX = this.moveY = this.lookX = this.lookY = 0
    this.sprint = false
    this.buttons = []
    this.prevButtons = []
    this.justSet.clear()
  }

  /** آیا این دکمه همین حالا فشرده شده است؟ */
  held(b: PadButton): boolean {
    const i = this.map[b]
    return i !== undefined && !!this.buttons[i]
  }

  /** آیا این دکمه در همین فریم تازه فشرده شد؟ (لبه‌ی بالا) */
  just(b: PadButton): boolean {
    const i = this.map[b]
    return i !== undefined && this.justSet.has(i)
  }

  /** پیام‌های اتصال/قطع را برمی‌گرداند و صف را خالی می‌کند */
  drainNotices(): string[] {
    if (!this.notices.length) return []
    const out = this.notices
    this.notices = []
    return out
  }

  private current(): Gamepad | null {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return null
    const pads = navigator.getGamepads()
    if (this.index !== null && pads[this.index]?.connected) return pads[this.index]
    for (const p of pads) if (p?.connected) return p
    return null
  }

  /** نظرسنجی وضعیت دسته — هر فریم از حلقه‌ی بازی صدا زده می‌شود */
  poll() {
    this.justSet.clear()
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return

    const g = this.current()
    if (!g) {
      if (this.connected) { this.reset(); this.notices.push('🎮 دسته قطع شد') }
      return
    }
    if (!this.connected || this.id !== g.id) this.adopt(g)

    // ── محورها ──
    const ax = g.axes
    const lx = deadzone(ax[0] ?? 0, DEADZONE_MOVE)
    const ly = deadzone(ax[1] ?? 0, DEADZONE_MOVE)
    const rx = deadzone(ax[2] ?? 0, DEADZONE_LOOK)
    const ry = deadzone(ax[3] ?? 0, DEADZONE_LOOK)

    // ── دکمه‌ها ──
    const n = g.buttons.length
    const held: boolean[] = new Array(n)
    for (let i = 0; i < n; i++) {
      const b = g.buttons[i]
      held[i] = !!b && (b.pressed || b.value > TRIGGER_ON)
    }
    for (let i = 0; i < n; i++) {
      if (held[i] && !this.prevButtons[i]) this.justSet.add(i)
    }
    this.buttons = held
    this.prevButtons = held

    // ── D-pad به حرکت اضافه می‌شود (پشتیبان استیک) ──
    const dpX = (this.held('dright') ? 1 : 0) - (this.held('dleft') ? 1 : 0)
    const dpY = (this.held('dup') ? 1 : 0) - (this.held('ddown') ? 1 : 0)
    let mx = lx + dpX
    let my = -ly + dpY          // بالای استیک منفی است → جلو مثبت
    const m = Math.hypot(mx, my)
    if (m > 1) { mx /= m; my /= m }
    this.moveX = mx
    this.moveY = my

    // دوربین: محور خام (پایین = مثبت، مثل حرکت ماوس به پایین)
    this.lookX = rx
    this.lookY = ry

    // دویدن: فشار دادن استیک تا انتها (استاندارد بازی‌های کنسولی)
    this.sprint = Math.hypot(lx, ly) > 0.82

    // ── تشخیص فعالیت برای تشخیص حالت ورودی ──
    if (this.justSet.size || m > 0.25 || Math.hypot(rx, ry) > 0.25) {
      this.lastActivity = performance.now()
    }
  }

  /**
   * لرزش دسته. روی دسته‌های پشتیبان‌نشده بی‌صدا نادیده گرفته می‌شود.
   * `strong` = موتور سنگین، `weak` = موتور سبک، `ms` = مدت
   */
  rumble(strong: number, weak: number, ms: number) {
    const g = this.current() as (Gamepad & { vibrationActuator?: Actuator }) | null
    const act = g?.vibrationActuator
    if (!act?.playEffect) return
    try {
      void act.playEffect('dual-rumble', {
        startDelay: 0, duration: ms,
        weakMagnitude: Math.max(0, Math.min(1, weak)),
        strongMagnitude: Math.max(0, Math.min(1, strong)),
      })
    } catch { /* پشتیبانی نمی‌شود */ }
  }
}

/** نمونه‌ی واحد — همه‌ی بخش‌های بازی از همین می‌خوانند */
export const pad = new GamepadInput()
