// ═══ داده‌های ثابت بازی الدوریا سه‌بعدی ═══

export type ClassId = 'warrior' | 'mage' | 'ranger'

export interface SkillDef {
  id: string
  name: string
  desc: string
  icon: string
  mana: number
  cd: number
}

export interface ClassDef {
  id: ClassId
  name: string
  title: string
  desc: string
  hp: number
  mana: number
  atk: number
  range: number
  color: number
  trim: number
  skills: SkillDef[]
}

export const CLASSES: ClassDef[] = [
  {
    id: 'warrior',
    name: 'جنگجو',
    title: 'سپردار الدوریا',
    desc: 'استاد نبرد تن‌به‌تن با شمشیر و سپر. مقاوم، بی‌امان و خط‌شکن.',
    hp: 130, mana: 50, atk: 14, range: 3.2,
    color: 0x8a4a2a, trim: 0xe8b64a,
    skills: [
      { id: 'whirlwind', name: 'گردباد فولاد', desc: 'چرخشی مرگبار که همه دشمنان اطراف را می‌برد', icon: '🌀', mana: 20, cd: 6 },
      { id: 'charge', name: 'یورش شیر', desc: 'جهشی خروشان به سمت دشمن با ضربه سنگین', icon: '⚡', mana: 15, cd: 7 },
      { id: 'slam', name: 'شکاف زمین', desc: 'ضربه‌ای به زمین که موج شوک همه‌جانبه ایجاد می‌کند', icon: '💥', mana: 30, cd: 11 },
      { id: 'warcry', name: 'فریاد نبرد', desc: 'خشم نبرد: قدرت حمله و جان‌سازی برای مدتی کوتاه', icon: '🛡', mana: 25, cd: 16 },
    ],
  },
  {
    id: 'mage',
    name: 'جادوگر',
    title: 'بافنده شعله‌های کیهانی',
    desc: 'استاد عناصر با عصای جادویی. شکننده اما ویرانگر از راه دور.',
    hp: 90, mana: 110, atk: 17, range: 16,
    color: 0x3a4a8a, trim: 0x9cd2ff,
    skills: [
      { id: 'fireball', name: 'گوی آتشین', desc: 'پرتاب گویی از شعله که برخوردش انفجاری است', icon: '🔥', mana: 18, cd: 4 },
      { id: 'frostnova', name: 'حلقه یخ', desc: 'انفجار سرما که دشمنان اطراف را کند و مجروح می‌کند', icon: '❄', mana: 24, cd: 8 },
      { id: 'chain', name: 'صاعقه زنجیره‌ای', desc: 'برقی که از دشمنی به دشمن دیگر می‌جهد', icon: '⚡', mana: 28, cd: 9 },
      { id: 'meteor', name: 'شهاب‌باران', desc: 'احضار شهابی ویرانگر بر سر نزدیک‌ترین دشمنان', icon: '☄', mana: 45, cd: 15 },
    ],
  },
  {
    id: 'ranger',
    name: 'کماندار',
    title: 'چشم تیزبین باد',
    desc: 'شکارچی چابک با کمان و تیر. مرگ از راه دور، پیش از آنکه دشمن برسد.',
    hp: 105, mana: 70, atk: 15, range: 18,
    color: 0x3d5c34, trim: 0xc8e89a,
    skills: [
      { id: 'multishot', name: 'پنج‌تیر', desc: 'رهایی پنج تیر در قوسی وسیع به سوی دشمنان', icon: '🏹', mana: 18, cd: 5 },
      { id: 'volley', name: 'باران تیر', desc: 'بارش تیر بر سر نزدیک‌ترین دشمنان', icon: '🌧', mana: 26, cd: 9 },
      { id: 'roll', name: 'غلت باد', desc: 'غلتکی چابک که تو را بی‌آزار از میدان می‌گریزاند', icon: '💨', mana: 12, cd: 5 },
      { id: 'explosive', name: 'تیر انفجاری', desc: 'تیری سنگین که در برخورد منفجر می‌شود', icon: '💣', mana: 32, cd: 10 },
    ],
  },
]

// ═══ بایوم‌ها — مطابق نقشه الدوریا ═══
export type BiomeId = 'city' | 'woods' | 'swamp' | 'mountains' | 'blasted' | 'frozen'

export interface BiomeDef {
  id: BiomeId
  name: string
  sub: string
  level: number
  center: [number, number]
  radius: number
  fogColor: number
  fogNear: number
  fogFar: number
  ground: [number, number, number]
  danger: boolean
}

export const BIOMES: BiomeDef[] = [
  { id: 'city', name: 'شهر الدوریا', sub: 'منطقه امن', level: 1, center: [0, 0], radius: 62, fogColor: 0xb8c8dc, fogNear: 90, fogFar: 420, ground: [0.44, 0.37, 0.27], danger: false },
  { id: 'woods', name: 'جنگل نجواگر', sub: 'منطقه خطرناک', level: 1, center: [-20, -190], radius: 150, fogColor: 0x9fb8a2, fogNear: 40, fogFar: 260, ground: [0.16, 0.30, 0.13], danger: true },
  { id: 'swamp', name: 'باتلاق سایه‌فن', sub: 'منطقه خطرناک', level: 6, center: [-210, 60], radius: 130, fogColor: 0x5a6b52, fogNear: 26, fogFar: 190, ground: [0.20, 0.24, 0.15], danger: true },
  { id: 'mountains', name: 'کوهستان دندان اژدها', sub: 'منطقه خطرناک', level: 10, center: [200, -140], radius: 145, fogColor: 0xa8aab4, fogNear: 60, fogFar: 330, ground: [0.38, 0.36, 0.36], danger: true },
  { id: 'blasted', name: 'سرزمین‌های سوخته', sub: 'منطقه خطرناک', level: 15, center: [160, 190], radius: 135, fogColor: 0xc07850, fogNear: 45, fogFar: 280, ground: [0.24, 0.16, 0.12], danger: true },
  { id: 'frozen', name: 'برهوت یخی', sub: 'منطقه خطرناک', level: 20, center: [-90, -350], radius: 130, fogColor: 0xd8e4f0, fogNear: 35, fogFar: 240, ground: [0.82, 0.86, 0.92], danger: true },
]

// ═══ هیولاها — از فایل monsters.txt ═══
export type MobKind =
  | 'wolf' | 'spider' | 'slime' | 'broodmother'
  | 'orc' | 'golem' | 'ettin'
  | 'firelizard' | 'drake' | 'lavagolem'
  | 'bear' | 'frost' | 'frostgiant'
  | 'troll'

export interface MobDef {
  kind: MobKind
  name: string
  hp: number
  dmg: number
  speed: number
  xp: number
  gold: [number, number]
  scale: number
  boss?: boolean
  aggroR: number
  atkR: number
  biome: BiomeId
}

export const MOBS: MobDef[] = [
  { kind: 'wolf', name: 'گرگ وحشی', hp: 42, dmg: 8, speed: 5.4, xp: 18, gold: [2, 7], scale: 1, aggroR: 17, atkR: 2.1, biome: 'woods' },
  { kind: 'spider', name: 'عنکبوت غول‌پیکر', hp: 55, dmg: 10, speed: 4.2, xp: 24, gold: [3, 9], scale: 1, aggroR: 15, atkR: 2.2, biome: 'woods' },
  { kind: 'troll', name: 'ترول جنگل', hp: 420, dmg: 22, speed: 3.6, xp: 160, gold: [40, 70], scale: 2.5, boss: true, aggroR: 22, atkR: 3.4, biome: 'woods' },
  { kind: 'slime', name: 'اسلایم باتلاقی', hp: 95, dmg: 14, speed: 3.0, xp: 42, gold: [6, 14], scale: 1, aggroR: 14, atkR: 2.0, biome: 'swamp' },
  { kind: 'broodmother', name: 'مادر عنکبوت‌های سمی', hp: 620, dmg: 26, speed: 4.0, xp: 260, gold: [60, 95], scale: 2.2, boss: true, aggroR: 20, atkR: 3.2, biome: 'swamp' },
  { kind: 'orc', name: 'اورک وحشی', hp: 170, dmg: 20, speed: 4.6, xp: 68, gold: [10, 20], scale: 1, aggroR: 17, atkR: 2.3, biome: 'mountains' },
  { kind: 'golem', name: 'گولم سنگی', hp: 240, dmg: 24, speed: 2.8, xp: 85, gold: [12, 24], scale: 1, aggroR: 13, atkR: 2.6, biome: 'mountains' },
  { kind: 'ettin', name: 'اِتین کوهستان', hp: 950, dmg: 34, speed: 3.8, xp: 420, gold: [90, 140], scale: 2.6, boss: true, aggroR: 22, atkR: 3.6, biome: 'mountains' },
  { kind: 'firelizard', name: 'مارمولک آتشین', hp: 260, dmg: 28, speed: 5.0, xp: 105, gold: [16, 30], scale: 1, aggroR: 17, atkR: 2.4, biome: 'blasted' },
  { kind: 'drake', name: 'دریک ابسیدین', hp: 330, dmg: 32, speed: 4.4, xp: 130, gold: [20, 36], scale: 1, aggroR: 18, atkR: 2.6, biome: 'blasted' },
  { kind: 'lavagolem', name: 'گولم گدازه', hp: 1500, dmg: 42, speed: 3.2, xp: 620, gold: [130, 200], scale: 2.7, boss: true, aggroR: 22, atkR: 3.8, biome: 'blasted' },
  { kind: 'bear', name: 'خرس قطبی غول', hp: 420, dmg: 36, speed: 5.2, xp: 160, gold: [24, 42], scale: 1, aggroR: 16, atkR: 2.5, biome: 'frozen' },
  { kind: 'frost', name: 'عنصر یخی', hp: 380, dmg: 34, speed: 3.6, xp: 150, gold: [22, 40], scale: 1, aggroR: 18, atkR: 2.8, biome: 'frozen' },
  { kind: 'frostgiant', name: 'غول یخی', hp: 2100, dmg: 52, speed: 3.6, xp: 900, gold: [180, 260], scale: 2.9, boss: true, aggroR: 24, atkR: 4.0, biome: 'frozen' },
]

// ═══ ماموریت‌ها ═══
export interface QuestDef {
  id: string
  npc: string
  name: string
  brief: string
  acceptText: string
  progressText: string
  doneText: string
  target: MobKind
  targetName: string
  count: number
  gold: number
  xp: number
}

export const QUESTS: QuestDef[] = [
  {
    id: 'q_wolves', npc: 'کاپیتان روریک', name: 'گرگ‌های نجواگر',
    brief: 'گرگ‌های وحشی به کاروان‌های بازرگانان حمله می‌کنند. جنگل نجواگر در شمال شهر منتظر شمشیر توست.',
    acceptText: 'گرگ‌ها را بشمر و بازگرد — شهر مدیون تو خواهد شد.',
    progressText: 'هنوز زوزه‌ها از دل جنگل می‌آیند...',
    doneText: 'کاروان‌ها دیگر امن‌اند. الدوریا قهرمانی مثل تو را فراموش نمی‌کند!',
    target: 'wolf', targetName: 'گرگ وحشی', count: 5, gold: 60, xp: 120,
  },
  {
    id: 'q_slimes', npc: 'الارای کیمیاگر', name: 'جوهر باتلاق',
    brief: 'برای اکسیر شفایم به جوهر اسلایم‌های باتلاق سایه‌فن نیاز دارم. در غرب شهر، پشت تپه‌ها.',
    acceptText: 'مراقب باش، آب‌های باتلاق پایت را می‌بلعد!',
    progressText: 'شیشه‌هایم هنوز خالی‌اند، قهرمان...',
    doneText: 'عالیست! این جوهرها ده‌ها زخمی را شفا خواهند داد.',
    target: 'slime', targetName: 'اسلایم باتلاقی', count: 4, gold: 110, xp: 260,
  },
  {
    id: 'q_golems', npc: 'بالدور آهنگر', name: 'سنگ‌های زنده',
    brief: 'گولم‌های سنگی کوهستان دندان اژدها مسیر معدن را بسته‌اند. سندان من بدون سنگ‌معدن سرد می‌ماند.',
    acceptText: 'پتکت را بردار — به شرق، پشت ابرها!',
    progressText: 'سندان هنوز خاموش است...',
    doneText: 'ها! حالا فولاد الدوریا دوباره جلویی خواهد گرفت!',
    target: 'golem', targetName: 'گولم سنگی', count: 4, gold: 180, xp: 420,
  },
  {
    id: 'q_boss', npc: 'کاپیتان روریک', name: 'ترول لانه‌سالار',
    brief: 'ترولی کهن‌سال در اعماق جنگل نجواگر لانه کرده. شکارچیان زیادی را بلعیده... وقتش رسیده بیدارش کنی و برای همیشه بخوابانیش.',
    acceptText: 'جرم جنگل را پاک کن، قهرمان!',
    progressText: 'ترول هنوز نفس می‌کشد. بوی تعفنش تا شهر می‌آید...',
    doneText: 'لانه ترول ساکت شد! نام تو در تالار قهرمانان حک خواهد شد.',
    target: 'troll', targetName: 'ترول جنگل', count: 1, gold: 400, xp: 800,
  },
]

// ═══ NPCهای شهر ═══
export interface NpcDef {
  id: string
  name: string
  role: string
  pos: [number, number]
  color: number
  greet: string
  quest?: string
}

export const NPCS: NpcDef[] = [
  { id: 'rorik', name: 'کاپیتان روریک', role: 'فرمانده نگهبانان', pos: [10, 14], color: 0x7a2e2e, greet: 'به الدوریا خوش آمدی، ماجراجو. شهر امن است، اما فراتر از دیوارها...', quest: 'q_wolves' },
  { id: 'rorik2', name: 'کاپیتان روریک', role: 'فرمانده نگهبانان', pos: [10, 14], color: 0x7a2e2e, greet: 'قهرمان! خبرهایت را بده.', quest: 'q_boss' },
  { id: 'baldur', name: 'بالدور آهنگر', role: 'استاد آهنگری', pos: [-16, 6], color: 0x5a4632, greet: 'صدای سندانم را می‌شنوی؟ فولاد الدوریا هرگز سرد نمی‌شود!', quest: 'q_golems' },
  { id: 'elara', name: 'الارای کیمیاگر', role: 'کیمیاگر شهر', pos: [16, -8], color: 0x3e5c4a, greet: 'آآه... بوی گیاهان تازه! به دنبال اکسیر هستی یا ماجرایی؟', quest: 'q_slimes' },
  { id: 'mira', name: 'میرا', role: 'مهماندار مسافرخانه', pos: [-8, -16], color: 0x6a5a8a, greet: 'به مسافرخانه «ماجراجوی خسته» خوش آمدی! یک ظرف خورش داغ برات می‌آورم؟' },
  { id: 'agustus', name: 'شهردار آگوستوس', role: 'شهردار الدوریا', pos: [0, 22], color: 0x8a7a3a, greet: 'الدوریا به ماجراجویانی چون تو مديون است. سرنوشت شهر در دستان توست!' },
]

export const TIPS = [
  'شهر الدوریا منطقه امن است — هیچ هیولایی وارد آن نمی‌شود.',
  'گرگ همراهت با تو بزرگ می‌شود؛ در سطح ۱۵ به «گرگ جوان» تکامل می‌یابد!',
  'معجون‌های شفا را با کلید H (یا دکمه شیشه‌ای) بنوش.',
  'هر بایوم هیولاها و باس مخصوص خود را دارد — سطح خودت را ببر بالا پیش از آنکه به شمال عمیق بروی.',
  'با Shift (یا دکمه دویدن) بدون خستگی بدوی.',
  'شب‌ها در شهر چراغ‌ها روشن می‌شوند — و در جنگل، چشم‌هایی در تاریکی می‌درخشند...',
  'سقوط از ارتفاع آسیب نمی‌زند، اما گدازه‌های سرزمین‌های سوخته می‌سوزانت!',
  'باس‌ها غنیمت پادشاهان را می‌بارانند: طلا، معجون و تجربه فراوان.',
]

export function xpForLevel(level: number): number {
  return Math.round(80 * Math.pow(level, 1.55))
}

export const SAVE_KEY = 'eldoria3d_save_v1'
