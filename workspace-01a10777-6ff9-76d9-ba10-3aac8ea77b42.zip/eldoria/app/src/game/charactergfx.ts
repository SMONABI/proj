// ═══ ساخت مدل‌های سه‌بعدی: قهرمان، هیولاها، NPC ═══
import * as THREE from 'three'
import type { ClassId, MobKind } from './data'

export function std(color: number, opts: Partial<THREE.MeshStandardMaterialParameters> = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.82, metalness: 0.05, flatShading: true, ...opts })
}

function M(geo: THREE.BufferGeometry, mat: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat)
  m.position.set(x, y, z)
  m.castShadow = true
  return m
}

export interface HeroRig {
  group: THREE.Group
  body: THREE.Group
  head: THREE.Group
  armL: THREE.Group
  armR: THREE.Group
  foreL: THREE.Group
  foreR: THREE.Group
  legL: THREE.Group
  legR: THREE.Group
  shinL: THREE.Group
  shinR: THREE.Group
  cape: THREE.Mesh
  weapon: THREE.Group
  orbMat?: THREE.MeshStandardMaterial
  trimMats: THREE.MeshStandardMaterial[]
}

export function buildHero(cls: ClassId, color: number, trim: number): HeroRig {
  const group = new THREE.Group()
  const body = new THREE.Group()
  body.position.y = 0.95
  group.add(body)

  const skin = std(0xd8a880)
  const armor = std(color, { metalness: cls === 'warrior' ? 0.45 : 0.1, roughness: 0.55 })
  const cloth = std(new THREE.Color(color).offsetHSL(0, 0.05, -0.08).getHex())
  const trimMat = std(trim, { emissive: trim, emissiveIntensity: 0.55, metalness: 0.6, roughness: 0.3 })
  const trimMats = [trimMat]

  // تنه
  const torsoGeo = cls === 'mage'
    ? new THREE.CylinderGeometry(0.24, 0.42, 0.78, 8)
    : new THREE.BoxGeometry(0.52, 0.62, 0.3)
  const torso = M(torsoGeo, cls === 'mage' ? cloth : armor, 0, 0.32, 0)
  body.add(torso)
  // کمربند + نشان کلاس
  const belt = M(new THREE.CylinderGeometry(0.27, 0.3, 0.09, 8), std(0x2c2018), 0, 0.02, 0)
  body.add(belt)
  const sigil = M(new THREE.OctahedronGeometry(0.06), trimMat, 0, 0.42, 0.17)
  body.add(sigil)
  if (cls === 'warrior') {
    // شانه‌های زرهی
    for (const s of [-1, 1]) {
      const p = M(new THREE.SphereGeometry(0.16, 8, 5, 0, Math.PI * 2, 0, Math.PI / 2), armor, s * 0.33, 0.56, 0)
      p.scale.set(1, 0.75, 1)
      body.add(p)
      const spike = M(new THREE.ConeGeometry(0.05, 0.16, 5), trimMat, s * 0.38, 0.68, 0)
      body.add(spike)
    }
  }

  // سر
  const head = new THREE.Group()
  head.position.y = 0.78
  const face = M(new THREE.SphereGeometry(0.17, 10, 8), skin, 0, 0.1, 0)
  head.add(face)
  for (const s of [-1, 1]) {
    const eye = M(new THREE.SphereGeometry(0.022, 5, 4), std(0x1a140e), s * 0.06, 0.12, 0.145)
    head.add(eye)
  }
  if (cls === 'warrior') {
    const helm = M(new THREE.SphereGeometry(0.19, 9, 6, 0, Math.PI * 2, 0, Math.PI / 1.8), armor, 0, 0.12, 0)
    head.add(helm)
    const plume = M(new THREE.ConeGeometry(0.05, 0.22, 6), trimMat, 0, 0.32, -0.03)
    plume.rotation.x = -0.4
    head.add(plume)
  } else {
    const hood = M(new THREE.ConeGeometry(0.21, 0.34, 8), cloth, 0, 0.2, -0.02)
    head.add(hood)
  }
  body.add(head)

  // بازوها
  const mkArm = (side: number): [THREE.Group, THREE.Group] => {
    const sh = new THREE.Group()
    sh.position.set(side * 0.34, 0.55, 0)
    const upper = M(new THREE.CapsuleGeometry(0.07, 0.24, 3, 6), cls === 'warrior' ? armor : cloth, 0, -0.16, 0)
    sh.add(upper)
    const el = new THREE.Group()
    el.position.y = -0.34
    const fore = M(new THREE.CapsuleGeometry(0.06, 0.22, 3, 6), skin, 0, -0.13, 0)
    el.add(fore)
    const glove = M(new THREE.SphereGeometry(0.075, 6, 5), std(0x2c2018), 0, -0.28, 0)
    el.add(glove)
    sh.add(el)
    body.add(sh)
    return [sh, el]
  }
  const [armL, foreL] = mkArm(-1)
  const [armR, foreR] = mkArm(1)

  // پاها
  const mkLeg = (side: number): [THREE.Group, THREE.Group] => {
    const hip = new THREE.Group()
    hip.position.set(side * 0.14, 0.02, 0)
    const thigh = M(new THREE.CapsuleGeometry(0.085, 0.28, 3, 6), cls === 'mage' ? cloth : std(0x3a3028), 0, -0.2, 0)
    hip.add(thigh)
    const knee = new THREE.Group()
    knee.position.y = -0.44
    const shin = M(new THREE.CapsuleGeometry(0.07, 0.26, 3, 6), std(0x2c2620), 0, -0.18, 0)
    knee.add(shin)
    const boot = M(new THREE.BoxGeometry(0.14, 0.09, 0.24), std(0x201a14), 0, -0.36, 0.05)
    knee.add(boot)
    hip.add(knee)
    body.add(hip)
    return [hip, knee]
  }
  const [legL, shinL] = mkLeg(-1)
  const [legR, shinR] = mkLeg(1)

  // سلاح
  const weapon = new THREE.Group()
  weapon.position.set(0, -0.3, 0.02)
  let orbMat: THREE.MeshStandardMaterial | undefined
  if (cls === 'warrior') {
    const blade = M(new THREE.BoxGeometry(0.055, 0.85, 0.13), std(0xc8ccd4, { metalness: 0.85, roughness: 0.25 }), 0, -0.62, 0)
    const edge = M(new THREE.BoxGeometry(0.02, 0.82, 0.145), trimMat, 0, -0.62, 0)
    const guard = M(new THREE.BoxGeometry(0.2, 0.05, 0.07), trimMat, 0, -0.18, 0)
    const grip = M(new THREE.CylinderGeometry(0.028, 0.032, 0.16, 6), std(0x3a2418), 0, -0.08, 0)
    weapon.add(blade, edge, guard, grip)
    // سپر روی بازوی چپ
    const shield = M(new THREE.CylinderGeometry(0.26, 0.26, 0.05, 10), armor, 0, -0.18, 0)
    shield.rotation.x = Math.PI / 2
    shield.rotation.z = Math.PI / 2
    const boss = M(new THREE.SphereGeometry(0.07, 7, 6), trimMat, -0.05, -0.18, 0)
    foreL.add(shield, boss)
  } else if (cls === 'mage') {
    const rod = M(new THREE.CylinderGeometry(0.03, 0.04, 1.15, 6), std(0x4a3220), 0, -0.5, 0)
    orbMat = std(trim, { emissive: trim, emissiveIntensity: 2.2 })
    const orb = M(new THREE.IcosahedronGeometry(0.1, 1), orbMat, 0, -1.12, 0)
    const crown = M(new THREE.ConeGeometry(0.07, 0.12, 5), trimMat, 0, -1.0, 0)
    weapon.add(rod, orb, crown)
    weapon.rotation.x = Math.PI
  } else {
    const bowMat = std(0x5a4028)
    const arc = M(new THREE.TorusGeometry(0.42, 0.028, 5, 12, Math.PI), bowMat, 0, -0.25, 0)
    arc.rotation.z = Math.PI / 2
    arc.rotation.y = Math.PI / 2
    const strMat = new THREE.MeshBasicMaterial({ color: 0xd8d0b8 })
    const string = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.82, 3), strMat)
    string.position.set(-0.02, -0.25, 0)
    weapon.add(arc, string)
    // تیردان پشت
    const quiver = M(new THREE.CylinderGeometry(0.07, 0.08, 0.4, 6), std(0x4a3826), -0.18, 0.35, -0.2)
    quiver.rotation.z = 0.3
    body.add(quiver)
    for (let i = 0; i < 3; i++) {
      const ar = M(new THREE.CylinderGeometry(0.012, 0.012, 0.5, 3), std(0x8a6c44), -0.18 + i * 0.035, 0.55, -0.2)
      ar.rotation.z = 0.3
      body.add(ar)
    }
  }
  foreR.add(weapon)

  // شنل
  const capeGeo = new THREE.PlaneGeometry(0.52, 0.95, 5, 7)
  capeGeo.translate(0, -0.475, 0)
  const capeMat = std(new THREE.Color(color).offsetHSL(0, 0.1, -0.04).getHex(), { side: THREE.DoubleSide, roughness: 0.95 })
  const cape = new THREE.Mesh(capeGeo, capeMat)
  cape.position.set(0, 0.62, -0.19)
  cape.castShadow = true
  body.add(cape)

  return { group, body, head, armL, armR, foreL, foreR, legL, legR, shinL, shinR, cape, weapon, orbMat, trimMats }
}

// ═══ هیولاها ═══
export interface MobRig {
  group: THREE.Group
  parts: Record<string, THREE.Object3D>
  anim: (t: number, moveSpeed: number, aggro: boolean) => void
  hitY: number
  radius: number
  emissives: THREE.MeshStandardMaterial[]
}

function legsAnim(legs: THREE.Group[], t: number, sp: number, amp = 0.7) {
  for (let i = 0; i < legs.length; i++) {
    const ph = (i % 2) * Math.PI + (i > 1 ? 0.5 : 0)
    legs[i].rotation.x = Math.sin(t * 8 * sp + ph) * amp * Math.min(sp, 1.4)
  }
}

export function buildMob(kind: MobKind, scale: number): MobRig {
  const group = new THREE.Group()
  const parts: Record<string, THREE.Object3D> = {}
  const emissives: THREE.MeshStandardMaterial[] = []
  let anim: MobRig['anim'] = () => {}
  let hitY = 1
  let radius = 0.8

  const glow = (color: number, intensity = 1.6) => {
    const m = std(color, { emissive: color, emissiveIntensity: intensity })
    emissives.push(m)
    return m
  }

  const quadruped = (bodyColor: number, len: number, hgt: number, headColor?: number) => {
    const bodyMat = std(bodyColor)
    const body = new THREE.Group()
    body.position.y = hgt
    const trunk = M(new THREE.BoxGeometry(0.62, 0.55, len), bodyMat)
    body.add(trunk)
    const head = new THREE.Group()
    head.position.set(0, 0.14, len / 2 + 0.1)
    const skull = M(new THREE.BoxGeometry(0.4, 0.36, 0.42), std(headColor ?? bodyColor), 0, 0, 0.1)
    const snout = M(new THREE.BoxGeometry(0.2, 0.18, 0.26), std(headColor ?? bodyColor), 0, -0.06, 0.4)
    head.add(skull, snout)
    const eyeMat = glow(0xffd23c, 2.4)
    for (const s of [-1, 1]) head.add(M(new THREE.SphereGeometry(0.045, 6, 5), eyeMat, s * 0.13, 0.06, 0.28))
    for (const s of [-1, 1]) {
      const ear = M(new THREE.ConeGeometry(0.07, 0.16, 4), bodyMat, s * 0.13, 0.24, 0.05)
      head.add(ear)
    }
    body.add(head)
    parts.head = head
    const legs: THREE.Group[] = []
    for (const [sx, sz] of [[-0.24, len / 2 - 0.18], [0.24, len / 2 - 0.18], [-0.24, -len / 2 + 0.18], [0.24, -len / 2 + 0.18]]) {
      const leg = new THREE.Group()
      leg.position.set(sx, -0.2, sz)
      const l = M(new THREE.CapsuleGeometry(0.075, hgt - 0.35, 3, 5), bodyMat, 0, -(hgt - 0.4) / 2, 0)
      leg.add(l)
      body.add(leg)
      legs.push(leg)
    }
    const tail = new THREE.Group()
    tail.position.set(0, 0.1, -len / 2)
    const tm = M(new THREE.ConeGeometry(0.09, 0.6, 5), bodyMat, 0, 0, -0.28)
    tm.rotation.x = -Math.PI / 2.3
    tail.add(tm)
    body.add(tail)
    parts.tail = tail
    group.add(body)
    parts.body = body
    anim = (t, sp, aggro) => {
      legsAnim(legs, t, sp)
      body.position.y = hgt + Math.abs(Math.sin(t * 8 * sp)) * 0.05
      tail.rotation.y = Math.sin(t * (aggro ? 9 : 3)) * 0.5
      head.rotation.x = aggro ? 0.28 : Math.sin(t * 1.4) * 0.08
    }
    hitY = hgt + 0.3
    radius = len * 0.55
    return body
  }

  const humanoid = (skinC: number, w: number, h: number, opts: { twoHeads?: boolean; club?: boolean; glowEyes?: number } = {}) => {
    const mat = std(skinC)
    const body = new THREE.Group()
    body.position.y = h
    const torso = M(new THREE.BoxGeometry(w, h * 0.75, w * 0.62), mat, 0, h * 0.24, 0)
    body.add(torso)
    const mkHead = (x: number) => {
      const head = new THREE.Group()
      head.position.set(x, h * 0.75, 0)
      head.add(M(new THREE.BoxGeometry(w * 0.4, w * 0.36, w * 0.4), mat, 0, w * 0.16, 0))
      const eyeMat = glow(opts.glowEyes ?? 0xff5a2c, 2)
      for (const s of [-1, 1]) head.add(M(new THREE.SphereGeometry(0.05 * w, 6, 5), eyeMat, s * w * 0.11, w * 0.18, w * 0.2))
      for (const s of [-1, 1]) {
        const tusk = M(new THREE.ConeGeometry(0.04 * w, 0.16 * w, 4), std(0xe8e0c8), s * w * 0.14, w * 0.02, w * 0.22)
        tusk.rotation.x = 0.5
        head.add(tusk)
      }
      body.add(head)
      return head
    }
    parts.head = mkHead(opts.twoHeads ? -w * 0.26 : 0)
    if (opts.twoHeads) parts.head2 = mkHead(w * 0.26)
    const arms: THREE.Group[] = []
    for (const s of [-1, 1]) {
      const arm = new THREE.Group()
      arm.position.set(s * (w / 2 + 0.08), h * 0.52, 0)
      const a = M(new THREE.CapsuleGeometry(w * 0.13, h * 0.5, 3, 6), mat, 0, -h * 0.3, 0)
      arm.add(a)
      body.add(arm)
      arms.push(arm)
    }
    if (opts.club) {
      const club = M(new THREE.CylinderGeometry(0.09 * w, 0.16 * w, h * 0.85, 6), std(0x4a3826), 0, -h * 0.62, 0.1)
      arms[1].add(club)
    }
    const legs: THREE.Group[] = []
    for (const s of [-1, 1]) {
      const leg = new THREE.Group()
      leg.position.set(s * w * 0.24, -h * 0.12, 0)
      leg.add(M(new THREE.CapsuleGeometry(w * 0.12, h * 0.4, 3, 6), std(0x33302c), 0, -h * 0.28, 0))
      body.add(leg)
      legs.push(leg)
    }
    group.add(body)
    parts.body = body
    anim = (t, sp, aggro) => {
      legsAnim(legs, t, sp, 0.5)
      body.rotation.x = 0.16 + Math.sin(t * 2) * 0.02 + (aggro ? 0.12 : 0)
      body.position.y = h + Math.abs(Math.sin(t * 8 * sp)) * 0.05
      arms[0].rotation.x = Math.sin(t * 8 * sp) * 0.5 * Math.min(sp, 1)
      arms[1].rotation.x = -Math.sin(t * 8 * sp) * 0.5 * Math.min(sp, 1)
      if (!aggro) {
        arms[0].rotation.z = 0.12; arms[1].rotation.z = -0.12
      }
    }
    hitY = h + h * 0.5
    radius = w * 0.75
    return body
  }

  const spider = (bodyC: number, legC: number, big: boolean) => {
    const mat = std(bodyC)
    const body = new THREE.Group()
    body.position.y = 0.62
    const abd = M(new THREE.SphereGeometry(0.5, 9, 7), mat, 0, 0.12, -0.42)
    abd.scale.set(1, 0.85, 1.2)
    const ceph = M(new THREE.SphereGeometry(0.3, 8, 6), mat, 0, 0, 0.18)
    body.add(abd, ceph)
    const eyeMat = glow(0xff2c2c, 2.6)
    for (const [ex, ey] of [[-0.12, 0.1], [0, 0.14], [0.12, 0.1], [-0.06, 0.02], [0.06, 0.02]])
      body.add(M(new THREE.SphereGeometry(0.045, 6, 5), eyeMat, ex, ey + 0.1, 0.42))
    for (const s of [-1, 1]) {
      const fang = M(new THREE.ConeGeometry(0.05, 0.2, 5), std(0xd8d0b8), s * 0.1, -0.12, 0.45)
      fang.rotation.x = Math.PI
      body.add(fang)
    }
    const legs: THREE.Group[] = []
    for (let i = 0; i < 8; i++) {
      const s = i < 4 ? -1 : 1
      const k = i % 4
      const leg = new THREE.Group()
      leg.position.set(s * 0.3, 0.05, 0.28 - k * 0.26)
      const upper = M(new THREE.CylinderGeometry(0.035, 0.05, 0.72, 4), std(legC), 0, 0.28, 0)
      upper.rotation.z = s * 1.0
      const lower = M(new THREE.CylinderGeometry(0.02, 0.035, 0.62, 4), std(legC), s * 0.62, 0.14, 0)
      lower.rotation.z = s * -0.5
      leg.add(upper, lower)
      leg.rotation.y = s * (k - 1.5) * 0.35
      body.add(leg)
      legs.push(leg)
    }
    group.add(body)
    parts.body = body
    anim = (t, sp) => {
      for (let i = 0; i < 8; i++) legs[i].position.y = 0.05 + Math.max(0, Math.sin(t * 10 * sp + i * 1.7)) * 0.14 * Math.min(sp, 1)
      body.position.y = 0.62 + Math.sin(t * 3) * 0.03
      if (big) abd.scale.setScalar(1 + Math.sin(t * 2.2) * 0.05)
    }
    hitY = 0.9
    radius = big ? 1.2 : 0.75
  }

  switch (kind) {
    case 'wolf': quadruped(0x4a4642, 1.15, 0.72); break
    case 'bear': {
      quadruped(0xe8e4dc, 1.35, 0.95)
      const hump = M(new THREE.SphereGeometry(0.4, 8, 6), std(0xdcd8d0), 0, 0.32, 0.2)
      hump.scale.set(1.1, 0.7, 1)
      ;(parts.body as THREE.Group).add(hump)
      hitY = 1.3; radius = 0.95
      break
    }
    case 'firelizard': {
      quadruped(0x8a3c22, 1.3, 0.62, 0x9a482c)
      const belly = glow(0xff8a2c, 1.2)
      const b = M(new THREE.BoxGeometry(0.5, 0.14, 1.1), belly, 0, -0.24, 0)
      ;(parts.body as THREE.Group).add(b)
      for (let i = 0; i < 5; i++) {
        const spike = M(new THREE.ConeGeometry(0.07, 0.22, 4), glow(0xffb03c, 0.9), 0, 0.32, 0.45 - i * 0.24)
        ;(parts.body as THREE.Group).add(spike)
      }
      break
    }
    case 'drake': {
      quadruped(0x2c2c34, 1.25, 0.7, 0x383844)
      const wingMat = std(0x1e1e28, { side: THREE.DoubleSide })
      const wings: THREE.Group[] = []
      for (const s of [-1, 1]) {
        const wing = new THREE.Group()
        wing.position.set(s * 0.3, 0.28, 0)
        const membrane = M(new THREE.PlaneGeometry(1.15, 0.6, 3, 1), wingMat, s * 0.6, 0, 0)
        membrane.rotation.x = -0.3
        wing.add(membrane)
        ;(parts.body as THREE.Group).add(wing)
        wings.push(wing)
      }
      for (const s of [-1, 1]) {
        const horn = M(new THREE.ConeGeometry(0.06, 0.3, 4), std(0xc8c8d0), s * 0.12, 0.28, -0.1)
        horn.rotation.x = -0.6
        ;(parts.head as THREE.Group).add(horn)
      }
      const baseAnim = anim
      anim = (t, sp, aggro) => {
        baseAnim(t, sp, aggro)
        const f = Math.sin(t * (aggro ? 9 : 4)) * 0.55
        wings[0].rotation.z = 0.3 + f
        wings[1].rotation.z = -0.3 - f
      }
      break
    }
    case 'spider': spider(0x3a2e28, 0x2c221c, false); break
    case 'broodmother': {
      spider(0x4a3a4e, 0x382c3c, true)
      const sac = M(new THREE.SphereGeometry(0.42, 8, 6), glow(0x9ae84a, 0.5), 0, 0.28, -0.72)
      ;(parts.body as THREE.Group).add(sac)
      hitY = 1.2; radius = 1.25
      break
    }
    case 'slime': {
      const outer = new THREE.MeshStandardMaterial({
        color: 0x5caa3c, roughness: 0.25, transparent: true, opacity: 0.75, flatShading: false,
        emissive: 0x2c5c1c, emissiveIntensity: 0.4,
      })
      emissives.push(outer)
      const body = new THREE.Group()
      body.position.y = 0.05
      const blob = M(new THREE.SphereGeometry(0.62, 12, 9), outer, 0, 0.5, 0)
      blob.scale.y = 0.82
      const core = M(new THREE.IcosahedronGeometry(0.22, 1), glow(0xb8ff5c, 1.4), 0, 0.42, 0)
      body.add(blob, core)
      for (const s of [-1, 1]) body.add(M(new THREE.SphereGeometry(0.06, 6, 5), std(0x142808), s * 0.2, 0.62, 0.45))
      group.add(body)
      parts.body = body
      parts.blob = blob
      anim = (t, sp) => {
        const sq = Math.sin(t * (4 + sp * 6))
        blob.scale.set(1 + sq * 0.12, 0.82 - sq * 0.1, 1 + sq * 0.12)
        body.position.y = 0.05 + Math.max(0, Math.sin(t * (2 + sp * 7))) * 0.28 * Math.min(sp, 1)
        core.rotation.y = t * 1.5
      }
      hitY = 0.6; radius = 0.7
      break
    }
    case 'orc': humanoid(0x5c7a3a, 0.85, 1.05, { club: true }); break
    case 'ettin': humanoid(0x8a7a5c, 1.15, 1.35, { twoHeads: true, club: true }); break
    case 'troll': {
      humanoid(0x6a7a5a, 1.25, 1.5, { club: true, glowEyes: 0xffd23c })
      const moss = std(0x3c5c2c)
      for (let i = 0; i < 4; i++) {
        const m = M(new THREE.IcosahedronGeometry(0.16, 0), moss, (Math.random() - 0.5) * 1, 0.6 + Math.random() * 0.9, -0.42)
        ;(parts.body as THREE.Group).add(m)
      }
      break
    }
    case 'golem':
    case 'lavagolem':
    case 'frostgiant': {
      const isLava = kind === 'lavagolem'
      const isFrost = kind === 'frostgiant'
      const rockC = isLava ? 0x2e2422 : isFrost ? 0x9ab8cc : 0x6e6a64
      const crackC = isLava ? 0xff6a1c : isFrost ? 0x6ad8ff : 0x8a86a0
      const mat = std(rockC, { roughness: 0.95 })
      const crackMat = glow(crackC, isLava ? 2.2 : 1.4)
      const body = new THREE.Group()
      body.position.y = 1.15
      const torso = M(new THREE.IcosahedronGeometry(0.72, 1), mat, 0, 0.45, 0)
      torso.scale.set(1.15, 1.05, 0.9)
      body.add(torso)
      for (const s of [-1, 1]) body.add(M(new THREE.BoxGeometry(0.34, 0.06, 0.1), crackMat, s * 0.3, 0.62, 0.52))
      body.add(M(new THREE.BoxGeometry(0.06, 0.5, 0.08), crackMat, 0.1, 0.35, 0.55))
      const headG = new THREE.Group()
      headG.position.y = 1.15
      headG.add(M(new THREE.IcosahedronGeometry(0.3, 0), mat, 0, 0.1, 0))
      const eyeMat = glow(crackC, 2.6)
      for (const s of [-1, 1]) headG.add(M(new THREE.SphereGeometry(0.06, 6, 5), eyeMat, s * 0.12, 0.1, 0.24))
      body.add(headG)
      parts.head = headG
      const arms: THREE.Group[] = []
      for (const s of [-1, 1]) {
        const arm = new THREE.Group()
        arm.position.set(s * 0.95, 0.75, 0)
        arm.add(M(new THREE.IcosahedronGeometry(0.3, 0), mat, 0, -0.3, 0))
        arm.add(M(new THREE.IcosahedronGeometry(0.38, 0), mat, 0, -0.85, 0))
        body.add(arm)
        arms.push(arm)
      }
      const legs: THREE.Group[] = []
      for (const s of [-1, 1]) {
        const leg = new THREE.Group()
        leg.position.set(s * 0.42, -0.1, 0)
        leg.add(M(new THREE.IcosahedronGeometry(0.34, 0), mat, 0, -0.5, 0))
        body.add(leg)
        legs.push(leg)
      }
      group.add(body)
      parts.body = body
      anim = (t, sp) => {
        legsAnim(legs, t, sp, 0.35)
        body.position.y = 1.15 + Math.abs(Math.sin(t * 6 * sp)) * 0.08
        body.rotation.z = Math.sin(t * 6 * sp) * 0.06
        arms[0].rotation.x = Math.sin(t * 6 * sp) * 0.4 * Math.min(sp, 1)
        arms[1].rotation.x = -Math.sin(t * 6 * sp) * 0.4 * Math.min(sp, 1)
      }
      hitY = 1.9; radius = 1.05
      break
    }
    case 'frost': {
      const iceMat = std(0xb8e4f4, { roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.92 })
      const coreMat = glow(0x5cc8ff, 2.4)
      const body = new THREE.Group()
      body.position.y = 1.1
      const shards: THREE.Mesh[] = []
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2
        const sh = M(new THREE.OctahedronGeometry(0.22 + Math.random() * 0.14), iceMat, Math.cos(a) * 0.4, Math.sin(i * 2.3) * 0.25, Math.sin(a) * 0.4)
        sh.scale.y = 2.1
        sh.rotation.set(Math.random(), Math.random(), Math.random())
        body.add(sh)
        shards.push(sh)
      }
      body.add(M(new THREE.IcosahedronGeometry(0.3, 1), coreMat, 0, 0, 0))
      const crown = new THREE.Group()
      for (let i = 0; i < 5; i++) {
        const sh = M(new THREE.ConeGeometry(0.09, 0.5, 4), iceMat, (i - 2) * 0.18, 0.75 + Math.abs(i - 2) * -0.06, 0)
        sh.rotation.z = (i - 2) * 0.25
        crown.add(sh)
      }
      body.add(crown)
      group.add(body)
      parts.body = body
      anim = (t) => {
        body.position.y = 1.1 + Math.sin(t * 1.8) * 0.16
        body.rotation.y = t * 0.6
        for (let i = 0; i < shards.length; i++) shards[i].rotation.y += 0.01 * (i % 2 ? 1 : -1)
      }
      hitY = 1.2; radius = 0.75
      break
    }
  }

  group.scale.setScalar(scale)
  group.traverse((o) => { if (o instanceof THREE.Mesh) o.castShadow = true })
  return { group, parts, anim, hitY: hitY * scale, radius: radius * scale, emissives }
}

// NPC ساده
export function buildNPC(color: number): { group: THREE.Group; body: THREE.Group; head: THREE.Group } {
  const group = new THREE.Group()
  const body = new THREE.Group()
  body.position.y = 0.9
  const robe = M(new THREE.CylinderGeometry(0.22, 0.38, 0.95, 8), std(color), 0, 0.25, 0)
  const head = new THREE.Group()
  head.position.y = 0.92
  head.add(M(new THREE.SphereGeometry(0.16, 10, 8), std(0xd8a880), 0, 0.08, 0))
  const hair = M(new THREE.SphereGeometry(0.17, 9, 6, 0, Math.PI * 2, 0, Math.PI / 2), std(0x4a3626), 0, 0.1, 0)
  head.add(hair)
  for (const s of [-1, 1]) head.add(M(new THREE.SphereGeometry(0.02, 5, 4), std(0x1a140e), s * 0.055, 0.09, 0.14))
  body.add(robe, head)
  for (const s of [-1, 1]) {
    const arm = M(new THREE.CapsuleGeometry(0.06, 0.3, 3, 5), std(color), s * 0.28, 0.45, 0)
    arm.rotation.z = s * 0.2
    body.add(arm)
  }
  group.add(body)
  group.traverse((o) => { if (o instanceof THREE.Mesh) o.castShadow = true })
  return { group, body, head }
}

// بافت نرم ذره‌ای
let _softTex: THREE.CanvasTexture | null = null
export function softTexture(): THREE.CanvasTexture {
  if (_softTex) return _softTex
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const ctx = c.getContext('2d')!
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
  g.addColorStop(0, 'rgba(255,255,255,1)')
  g.addColorStop(0.4, 'rgba(255,255,255,0.5)')
  g.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 64, 64)
  _softTex = new THREE.CanvasTexture(c)
  return _softTex
}

export function disposeObject(root: THREE.Object3D) {
  root.traverse((o) => {
    if (o instanceof THREE.Mesh) {
      o.geometry?.dispose()
      const m = o.material as THREE.Material | THREE.Material[]
      if (Array.isArray(m)) m.forEach((x) => x.dispose())
      else m?.dispose()
    }
  })
}
