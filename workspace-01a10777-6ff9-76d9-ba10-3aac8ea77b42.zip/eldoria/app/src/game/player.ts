// ═══ بازیکن: کنترلر سوم‌شخص، انیمیشن رویه‌ای، دوربین ═══
import * as THREE from 'three'
import { buildHero } from './charactergfx'
import type { HeroRig } from './charactergfx'
import type { ClassDef } from './data'
import { World } from './world'
import { VFX } from './vfx'
import { clamp, damp, lerp } from './noise'

export type AnimState = 'idle' | 'run' | 'air' | 'attack' | 'cast' | 'roll' | 'dead'

/**
 * تبدیل ورودی صفحه به جهت روی زمین، نسبت به دوربین.
 * قرارداد ورودی: x = راستِ صفحه، y = جلو (دور از دوربین) — هر دو با علامت مثبت.
 *
 * چرا لازم است: دوربین در `updateCamera` در نقطه‌ی
 * `head + (-sin(camYaw)·cy, sy, -cos(camYaw)·cy)·dist` قرار می‌گیرد و به `head`
 * نگاه می‌کند. پس روی زمین:
 *     جلو  = ( sin(camYaw), 0,  cos(camYaw))
 *     راست = (-cos(camYaw), 0,  sin(camYaw))
 * چرخش ساده‌ی (x, z) حول محور Y با زاویه‌ی camYaw این نگاشت را نمی‌دهد و نتیجه‌اش
 * کنترل‌های کاملاً معکوس بود (جلو → عقب، راست → چپ). با آزمون واقعی مرورگر
 * تأیید شد: هر هفت ورودی هم‌جهتی ‎-1.00‎ می‌دادند.
 */
export function screenDirToWorld(x: number, y: number, camYaw: number, out: THREE.Vector3): THREE.Vector3 {
  const c = Math.cos(camYaw), s = Math.sin(camYaw)
  // جلو·y + راست·x
  return out.set(y * s - x * c, 0, y * c + x * s)
}

export interface PlayerCtx {
  world: World
  vfx: VFX
  camera: THREE.PerspectiveCamera
  onMeleeHit?: (combo: number) => void
  onRangedShot?: (from: THREE.Vector3, dir: THREE.Vector3, heavy: boolean) => void
  onStep?: (run: boolean) => void
  isBuffed?: () => boolean
}

export class Player {
  rig: HeroRig
  pos = new THREE.Vector3(0, 0, 4)
  vel = new THREE.Vector3()
  yaw = Math.PI // چرخش مدل
  camYaw = Math.PI
  camPitch = 0.32
  camDist = 7.4
  grounded = true
  state: AnimState = 'idle'
  speed = 0
  attackT = 0
  attackDur = 0.44
  combo = 0
  comboQueued = false
  hitFired = false
  castT = 0
  rollT = 0
  rollDir = new THREE.Vector3()
  animT = 0
  private stepT = 0
  private capeBase: Float32Array
  private camTarget = new THREE.Vector3()
  private camPos = new THREE.Vector3(0, 4, 12)
  private tipPrev = new THREE.Vector3()
  private fov = 55
  private aura: THREE.Mesh
  cls: ClassDef
  iframes = 0
  private ctx: PlayerCtx
  private sprinting = false

  constructor(cls: ClassDef, ctx: PlayerCtx, scene: THREE.Scene) {
    this.cls = cls
    this.ctx = ctx
    this.rig = buildHero(cls.id, cls.color, cls.trim)
    this.rig.group.position.copy(this.pos)
    scene.add(this.rig.group)
    const capePos = this.rig.cape.geometry.attributes.position
    this.capeBase = new Float32Array(capePos.array as Float32Array)
    const auraGeo = new THREE.RingGeometry(0.7, 1.05, 32)
    auraGeo.rotateX(-Math.PI / 2)
    this.aura = new THREE.Mesh(auraGeo, new THREE.MeshBasicMaterial({
      color: cls.trim, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false,
    }))
    this.aura.position.y = 0.12
    this.rig.group.add(this.aura)
  }

  teleport(x: number, z: number) {
    this.pos.set(x, this.ctx.world.height(x, z), z)
    this.vel.set(0, 0, 0)
  }

  get attackPower() {
    return this.attackDur
  }

  look(dx: number, dy: number) {
    this.camYaw -= dx * 0.0046
    this.camPitch = clamp(this.camPitch + dy * 0.0042, -0.5, 1.15)
  }

  zoom(d: number) {
    this.camDist = clamp(this.camDist + d, 4.2, 11)
  }

  tryAttack(): boolean {
    if (this.state === 'dead' || this.rollT > 0) return false
    if (this.state === 'attack' || this.state === 'cast') {
      if (this.attackT > 0.45) this.comboQueued = true
      return false
    }
    this.startSwing(0)
    return true
  }

  private startSwing(combo: number) {
    this.state = this.cls.id === 'warrior' ? 'attack' : 'cast'
    this.combo = combo
    this.attackT = 0
    this.hitFired = false
    this.comboQueued = false
    this.attackDur = this.cls.id === 'warrior' ? (combo === 2 ? 0.52 : 0.42) : 0.4
  }

  tryRoll(dir: THREE.Vector3): boolean {
    if (this.state === 'dead' || this.rollT > 0 || !this.grounded) return false
    this.rollT = 0.38
    this.state = 'roll'
    this.rollDir.copy(dir.lengthSq() > 0.01 ? dir : new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw))).normalize()
    this.iframes = 0.42
    this.ctx.vfx.dust(this.pos, 6)
    return true
  }

  /** انیمیشن استفاده از مهارت بدون کامبو */
  playCastAnim(dur = 0.5) {
    if (this.state === 'dead') return
    this.state = 'cast'
    this.attackT = 0
    this.attackDur = dur
    this.hitFired = true
  }

  update(dt: number, move: THREE.Vector2, sprint: boolean, jump: boolean, facing: THREE.Vector3 | null) {
    const { world, vfx } = this.ctx
    this.iframes = Math.max(0, this.iframes - dt)
    this.animT += dt

    // ─── حمله ───
    if (this.state === 'attack' || this.state === 'cast') {
      this.attackT += dt / this.attackDur
      const firePoint = this.cls.id === 'warrior' ? 0.42 : 0.38
      if (!this.hitFired && this.attackT >= firePoint) {
        this.hitFired = true
        if (this.cls.id === 'warrior') this.ctx.onMeleeHit?.(this.combo)
        else this.ctx.onRangedShot?.(this.muzzlePos(), this.aimDir(facing), this.combo >= 2)
      }
      if (this.attackT >= 1) {
        if (this.comboQueued && this.combo < 2) {
          this.startSwing(this.combo + 1)
        } else {
          this.state = 'idle'
          this.combo = 0
        }
      }
    }

    // ─── غلت ───
    let rolling = false
    if (this.rollT > 0) {
      this.rollT -= dt
      rolling = true
      if (this.rollT <= 0) this.state = 'idle'
    }

    // ─── حرکت ───
    const attacking = this.state === 'attack' || this.state === 'cast'
    const buffed = this.ctx.isBuffed?.() ?? false
    this.sprinting = sprint
    let targetSpeed = 0
    const moveLen = Math.min(move.length(), 1)
    if (moveLen > 0.05 && this.state !== 'dead') {
      targetSpeed = (sprint ? 9.4 : 5.8) * moveLen * (buffed ? 1.12 : 1)
      if (attacking) targetSpeed *= this.cls.id === 'warrior' ? 0.32 : 0.5
    }
    // جهت حرکت نسبت به دوربین
    // move.x = راستِ صفحه، move.y = جلو (این قرارداد در Game.inputVector ساخته می‌شود)
    const dir = new THREE.Vector3()
    if (targetSpeed > 0) {
      screenDirToWorld(move.x, move.y, this.camYaw, dir).normalize()
    }
    if (rolling) {
      this.vel.x = this.rollDir.x * 13.5
      this.vel.z = this.rollDir.z * 13.5
    } else {
      const accel = this.grounded ? 34 : 10
      this.vel.x = damp(this.vel.x, dir.x * targetSpeed, accel / 6, dt)
      this.vel.z = damp(this.vel.z, dir.z * targetSpeed, accel / 6, dt)
    }

    // جهت‌گیری مدل
    if (facing && attacking) {
      const ty = Math.atan2(facing.x, facing.z)
      this.yaw = dampAngle(this.yaw, ty, 18, dt)
    } else if (targetSpeed > 0.1) {
      const ty = Math.atan2(this.vel.x, this.vel.z)
      this.yaw = dampAngle(this.yaw, ty, 12, dt)
    }

    // ─── گرانش و پرش ───
    if (jump && this.grounded && this.state !== 'dead' && !rolling) {
      this.vel.y = 8.4
      this.grounded = false
      vfx.dust(this.pos, 4)
    }
    this.vel.y -= 23 * dt
    this.pos.x += this.vel.x * dt
    this.pos.z += this.vel.z * dt
    this.pos.y += this.vel.y * dt
    const gh = world.height(this.pos.x, this.pos.z)
    if (this.pos.y <= gh) {
      if (!this.grounded && this.vel.y < -9) vfx.dust(new THREE.Vector3(this.pos.x, gh, this.pos.z), 8)
      this.pos.y = gh
      this.vel.y = 0
      this.grounded = true
    } else if (this.pos.y > gh + 0.05) {
      this.grounded = false
    }

    // ─── برخوردها ───
    this.resolveColliders(world)

    // محدوده جهان
    const r = Math.sqrt(this.pos.x ** 2 + this.pos.z ** 2)
    if (r > 470) {
      const k = 470 / r
      this.pos.x *= k; this.pos.z *= k
    }

    this.speed = Math.sqrt(this.vel.x ** 2 + this.vel.z ** 2)
    if (!attacking && !rolling && this.state !== 'dead') {
      this.state = !this.grounded ? 'air' : this.speed > 0.6 ? 'run' : 'idle'
    }

    // صدا و غبار قدم‌ها
    if (this.state === 'run' && this.grounded) {
      this.stepT -= dt * this.speed
      if (this.stepT <= 0) {
        this.stepT = 2.6
        this.ctx.onStep?.(this.speed > 7)
        if (this.speed > 7) vfx.dust(this.pos, 2)
      }
    }

    this.animate(dt, buffed)
    this.rig.group.position.copy(this.pos)
    this.rig.group.rotation.y = this.yaw

    this.updateCamera(dt)
  }

  private resolveColliders(world: World) {
    const near = world.collidersNear(this.pos.x, this.pos.z, this._colliders)
    for (const c of near) {
      const dx = this.pos.x - c.x, dz = this.pos.z - c.z
      const d2 = dx * dx + dz * dz
      const min = c.r + 0.42
      if (d2 < min * min && d2 > 0.0001) {
        const d = Math.sqrt(d2)
        this.pos.x = c.x + (dx / d) * min
        this.pos.z = c.z + (dz / d) * min
      }
    }
    for (const b of world.boxColliders) {
      const cx = clamp(this.pos.x, b.minX, b.maxX)
      const cz = clamp(this.pos.z, b.minZ, b.maxZ)
      const dx = this.pos.x - cx, dz = this.pos.z - cz
      const d2 = dx * dx + dz * dz
      if (d2 < 0.42 * 0.42) {
        if (d2 < 0.0001) {
          // داخل جعبه: هل به نزدیک‌ترین لبه
          const dl = this.pos.x - b.minX, dr = b.maxX - this.pos.x
          const dn = this.pos.z - b.minZ, df = b.maxZ - this.pos.z
          const m = Math.min(dl, dr, dn, df)
          if (m === dl) this.pos.x = b.minX - 0.42
          else if (m === dr) this.pos.x = b.maxX + 0.42
          else if (m === dn) this.pos.z = b.minZ - 0.42
          else this.pos.z = b.maxZ + 0.42
        } else {
          const d = Math.sqrt(d2)
          this.pos.x = cx + (dx / d) * 0.42
          this.pos.z = cz + (dz / d) * 0.42
        }
      }
    }
  }
  private _colliders: { x: number; z: number; r: number }[] = []

  muzzlePos(): THREE.Vector3 {
    const p = this.pos.clone()
    p.y += 1.35
    p.addScaledVector(new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw)), 0.7)
    return p
  }

  aimDir(facing: THREE.Vector3 | null): THREE.Vector3 {
    if (facing) return facing.clone().normalize()
    return new THREE.Vector3(Math.sin(this.yaw), 0.02, Math.cos(this.yaw))
  }

  // ─── انیمیشن رویه‌ای ───
  private animate(dt: number, buffed: boolean) {
    const r = this.rig
    const t = this.animT
    const sp = clamp(this.speed / 6, 0, 1.6)
    const runF = t * 9.5

    const L = (o: THREE.Object3D, x: number, y = 0, z = 0, k = 14) => {
      o.rotation.x = damp(o.rotation.x, x, k, dt)
      o.rotation.y = damp(o.rotation.y, y, k, dt)
      o.rotation.z = damp(o.rotation.z, z, k, dt)
    }

    if (this.state === 'dead') {
      L(r.body, -Math.PI / 2.2, 0, 0, 4)
      L(r.armL, -0.4, 0, 0.5, 4); L(r.armR, -0.4, 0, -0.5, 4)
      r.body.position.y = damp(r.body.position.y, 0.35, 4, dt)
      this.animateCape(dt, 0.2)
      return
    }

    if (this.state === 'run') {
      const swing = Math.sin(runF) * (0.75 + sp * 0.2)
      L(r.legL, swing); L(r.legR, -swing)
      L(r.shinL, Math.max(0, -Math.sin(runF)) * 1.1)
      L(r.shinR, Math.max(0, Math.sin(runF)) * 1.1)
      L(r.armL, -swing * 0.8, 0, 0.08); L(r.armR, swing * 0.8, 0, -0.08)
      L(r.foreL, -0.4); L(r.foreR, -0.4)
      L(r.body, 0.14 + sp * 0.12, Math.sin(runF) * 0.04, Math.sin(runF * 0.5) * 0.02)
      r.body.position.y = 0.95 + Math.abs(Math.sin(runF)) * 0.07
      L(r.head, -0.1)
    } else if (this.state === 'air') {
      L(r.legL, 0.5); L(r.legR, -0.3)
      L(r.shinL, 0.8); L(r.shinR, 0.5)
      L(r.armL, -0.6, 0, 0.5); L(r.armR, -0.6, 0, -0.5)
      L(r.body, 0.05)
      r.body.position.y = damp(r.body.position.y, 1.0, 10, dt)
    } else if (this.state === 'roll') {
      const k = 1 - this.rollT / 0.38
      r.body.rotation.x = -k * Math.PI * 2
      r.body.position.y = 0.75
      L(r.legL, 0.9); L(r.legR, 0.9); L(r.shinL, 1.4); L(r.shinR, 1.4)
      L(r.armL, 0.6); L(r.armR, 0.6)
    } else if (this.state === 'attack') {
      const k = this.attackT
      const c = this.combo
      // فازها: کشش (0-0.3)، ضربه (0.3-0.55)، برگشت
      const strike = smooth01((k - 0.3) / 0.25)
      const rec = smooth01((k - 0.6) / 0.4)
      if (c === 0) {
        L(r.armR, lerp(lerp(-2.4, -0.7, strike), -0.2, rec), 0, lerp(-0.5, 0.15, strike), 26)
        L(r.foreR, lerp(lerp(-0.6, -0.05, strike), -0.35, rec), 0, 0, 26)
        L(r.body, 0.1 + strike * 0.28, lerp(0.5, -0.45, strike), 0, 20)
      } else if (c === 1) {
        L(r.armR, lerp(lerp(-1.1, -1.6, strike), -0.2, rec), 0, lerp(0.9, -0.9, strike), 26)
        L(r.foreR, lerp(-0.3, -0.05, strike), 0, 0, 26)
        L(r.body, 0.1 + strike * 0.24, lerp(-0.55, 0.5, strike), 0, 20)
      } else {
        // ضربه سوم: عمودی سنگین
        L(r.armR, lerp(lerp(-2.9, -0.5, strike), -0.2, rec), 0, 0, 24)
        L(r.foreR, lerp(-0.9, 0, strike), 0, 0, 24)
        L(r.body, lerp(-0.25, 0.5, strike), 0, 0, 20)
        r.body.position.y = 0.95 + strike * 0.12 - rec * 0.12
      }
      L(r.armL, -0.3, 0, 0.35)
      L(r.legL, 0.25); L(r.legR, -0.2)
      L(r.shinL, 0.3); L(r.shinR, 0.3)
      // رد شمشیر
      if (k > 0.3 && k < 0.62) {
        const tip = new THREE.Vector3()
        this.rig.weapon.children[0]?.getWorldPosition(tip)
        if (this.tipPrev.lengthSq() > 0) {
          for (let i = 1; i <= 3; i++) {
            const p = this.tipPrev.clone().lerp(tip, i / 3)
            this.ctx.vfx.trail(p, this.cls.trim, 1.3, 0.3)
          }
        }
        this.tipPrev.copy(tip)
      } else this.tipPrev.set(0, 0, 0)
    } else if (this.state === 'cast') {
      const k = this.attackT
      const raise = smooth01(k / 0.3)
      const push = smooth01((k - 0.3) / 0.2)
      const rec = smooth01((k - 0.6) / 0.4)
      L(r.armR, lerp(lerp(-2.2, -1.5, push), -0.15, rec), 0, lerp(0.3, -0.1, push), 24)
      L(r.foreR, lerp(-0.7, -0.1, push), 0, 0, 24)
      L(r.armL, -0.5 * raise, 0, 0.5 * raise, 18)
      L(r.body, 0.06 + push * 0.18, lerp(0.3, -0.15, push), 0, 18)
      L(r.legL, 0.15); L(r.legR, -0.15)
    } else {
      // idle: تنفس و حرکت‌های کوچک
      const b = Math.sin(t * 2.1)
      L(r.body, 0.02 + b * 0.015)
      r.body.position.y = 0.95 + b * 0.012
      L(r.armL, 0.05 + b * 0.03, 0, 0.1)
      L(r.armR, 0.05 - b * 0.03, 0, -0.1)
      L(r.foreL, -0.25); L(r.foreR, -0.25)
      L(r.legL, 0); L(r.legR, 0)
      L(r.shinL, 0.04); L(r.shinR, 0.04)
      L(r.head, Math.sin(t * 0.7) * 0.05, Math.sin(t * 0.43) * 0.12, 0, 6)
    }

    // هاله باف
    const auraMat = this.aura.material as THREE.MeshBasicMaterial
    auraMat.opacity = damp(auraMat.opacity, buffed ? 0.65 : 0, 8, dt)
    if (buffed) {
      this.aura.scale.setScalar(1 + Math.sin(t * 5) * 0.07)
      if (Math.random() < dt * 8) {
        const a = Math.random() * Math.PI * 2
        this.ctx.vfx.trail(new THREE.Vector3(this.pos.x + Math.cos(a) * 0.8, this.pos.y + 0.2, this.pos.z + Math.sin(a) * 0.8), this.cls.trim, 0.9, 0.7)
      }
    }

    this.animateCape(dt, sp)
  }

  private animateCape(dt: number, sp: number) {
    const cape = this.rig.cape
    const pos = cape.geometry.attributes.position as THREE.BufferAttribute
    const t = this.animT
    const amp = 0.05 + sp * 0.16 + (this.grounded ? 0 : 0.14)
    const arr = pos.array as Float32Array
    for (let i = 0; i < pos.count; i++) {
      const bx = this.capeBase[i * 3]
      const by = this.capeBase[i * 3 + 1]
      const bz = this.capeBase[i * 3 + 2]
      const rowK = clamp(-by / 0.95, 0, 1)
      const wave = Math.sin(t * (4 + sp * 4) + rowK * 3.2 + bx * 2) * amp * rowK
      const lift = rowK * rowK * (sp * 0.34 + (this.grounded ? 0 : 0.3))
      arr[i * 3] = bx + Math.sin(t * 3 + rowK * 4) * 0.02 * rowK
      arr[i * 3 + 1] = by
      arr[i * 3 + 2] = bz - wave - lift
    }
    pos.needsUpdate = true
    cape.geometry.computeVertexNormals()
    cape.rotation.x = damp(cape.rotation.x, 0.12 + sp * 0.34 + (this.grounded ? 0 : 0.4), 8, dt)
  }

  private updateCamera(dt: number) {
    const cam = this.ctx.camera
    const head = this.camTarget.set(this.pos.x, this.pos.y + 1.75, this.pos.z)
    const cy = Math.cos(this.camPitch), sy = Math.sin(this.camPitch)
    const off = new THREE.Vector3(
      -Math.sin(this.camYaw) * cy, sy, -Math.cos(this.camYaw) * cy,
    ).multiplyScalar(this.camDist)
    const want = head.clone().add(off)
    // برخورد دوربین با زمین
    const gh = this.ctx.world.height(want.x, want.z) + 0.5
    if (want.y < gh) want.y = gh
    const k = 1 - Math.exp(-16 * dt)
    this.camPos.lerp(want, k)
    // لرزش
    const shake = this.ctx.vfx.shakeAmp
    if (shake > 0.001) {
      const st = performance.now() / 1000
      this.camPos.x += Math.sin(st * 91) * shake * 0.22
      this.camPos.y += Math.cos(st * 113) * shake * 0.18
      this.camPos.z += Math.sin(st * 71) * shake * 0.22
    }
    cam.position.copy(this.camPos)
    cam.lookAt(head)
    const wantFov = this.sprinting && this.speed > 6.5 ? 62 : 55
    this.fov = damp(this.fov, wantFov, 6, dt)
    if (Math.abs(cam.fov - this.fov) > 0.05) {
      cam.fov = this.fov
      cam.updateProjectionMatrix()
    }
  }
}

function smooth01(x: number) {
  const t = clamp(x, 0, 1)
  return t * t * (3 - 2 * t)
}

function dampAngle(a: number, b: number, lambda: number, dt: number) {
  let d = (b - a) % (Math.PI * 2)
  if (d > Math.PI) d -= Math.PI * 2
  if (d < -Math.PI) d += Math.PI * 2
  return a + d * (1 - Math.exp(-lambda * dt))
}
