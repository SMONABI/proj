// ═══ آسمان: چرخه روز و شب، خورشید/ماه/ستاره‌ها، ابرها، نورپردازی ═══
import * as THREE from 'three'
import { lerp, clamp } from './noise'

const DAY_LENGTH = 360 // ثانیه برای یک چرخه کامل

const skyVert = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_Position.z = gl_Position.w; // همیشه در افق دور
}
`

const skyFrag = /* glsl */ `
varying vec3 vDir;
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunSize;
uniform vec3 uMoonDir;
uniform float uNight;
uniform float uTime;

float hash(vec3 p) {
  p = fract(p * 0.3183099 + 0.1);
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

void main() {
  vec3 d = normalize(vDir);
  float h = clamp(d.y, -0.12, 1.0);
  float t = pow(1.0 - max(h, 0.0), 1.35);
  vec3 col = mix(uZenith, uHorizon, t);

  // خورشید + هاله
  float sd = dot(d, uSunDir);
  float sun = smoothstep(1.0 - uSunSize, 1.0 - uSunSize * 0.35, sd);
  float glow = pow(max(sd, 0.0), 24.0) * 0.5 + pow(max(sd, 0.0), 6.0) * 0.18;
  col += uSunColor * (sun * 1.6 + glow);

  // ماه
  float md = dot(d, uMoonDir);
  float moon = smoothstep(0.9993, 0.9997, md);
  float mglow = pow(max(md, 0.0), 90.0) * 0.35;
  col += vec3(0.86, 0.9, 1.0) * (moon * 1.1 + mglow) * uNight;

  // ستاره‌ها
  if (uNight > 0.02 && d.y > 0.0) {
    vec3 sp = floor(d * 160.0);
    float star = step(0.9982, hash(sp));
    float tw = 0.6 + 0.4 * sin(uTime * 2.2 + hash(sp * 1.7) * 40.0);
    col += vec3(0.9, 0.93, 1.0) * star * tw * uNight * smoothstep(0.0, 0.25, d.y);
  }

  gl_FragColor = vec4(col, 1.0);
}
`

// پالت‌های کلیدی چرخه روز
const P = {
  dayZen: new THREE.Color(0x3d6fb8), dayHor: new THREE.Color(0xbfd6e8),
  duskZen: new THREE.Color(0x2c3a6e), duskHor: new THREE.Color(0xe8905a),
  nightZen: new THREE.Color(0x060a1c), nightHor: new THREE.Color(0x101c33),
  sunDay: new THREE.Color(0xfff2d8), sunDusk: new THREE.Color(0xff9a4a),
  fogDay: new THREE.Color(0xbcccda), fogNight: new THREE.Color(0x0c1420),
}

export class Sky {
  mesh: THREE.Mesh
  mat: THREE.ShaderMaterial
  sun: THREE.DirectionalLight
  hemi: THREE.HemisphereLight
  amb: THREE.AmbientLight
  clouds: THREE.Group
  /** 0..1 — 0.25 = ظهر، 0.75 = نیمه‌شب */
  time = 0.32
  dayFactor = 1
  nightFactor = 0
  sunDir = new THREE.Vector3()

  constructor(scene: THREE.Scene) {
    this.mat = new THREE.ShaderMaterial({
      vertexShader: skyVert,
      fragmentShader: skyFrag,
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uZenith: { value: new THREE.Color() },
        uHorizon: { value: new THREE.Color() },
        uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        uSunColor: { value: new THREE.Color(0xfff2d8) },
        uSunSize: { value: 0.004 },
        uMoonDir: { value: new THREE.Vector3(0, -1, 0) },
        uNight: { value: 0 },
        uTime: { value: 0 },
      },
    })
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(760, 32, 18), this.mat)
    this.mesh.frustumCulled = false
    this.mesh.renderOrder = -10
    scene.add(this.mesh)

    this.sun = new THREE.DirectionalLight(0xffedd0, 2.4)
    this.sun.castShadow = true
    const s = this.sun.shadow
    s.mapSize.set(2048, 2048)
    s.camera.near = 10; s.camera.far = 260
    s.camera.left = -60; s.camera.right = 60
    s.camera.top = 60; s.camera.bottom = -60
    s.bias = -0.0006
    s.normalBias = 0.35
    scene.add(this.sun, this.sun.target)

    this.hemi = new THREE.HemisphereLight(0xa8c4e0, 0x5a4c38, 0.7)
    scene.add(this.hemi)
    this.amb = new THREE.AmbientLight(0x405070, 0.25)
    scene.add(this.amb)

    this.clouds = this.buildClouds()
    scene.add(this.clouds)
  }

  private buildClouds(): THREE.Group {
    const g = new THREE.Group()
    const cnv = document.createElement('canvas')
    cnv.width = 256; cnv.height = 128
    const ctx = cnv.getContext('2d')!
    for (let i = 0; i < 26; i++) {
      const x = 30 + Math.random() * 196, y = 40 + Math.random() * 48
      const r = 16 + Math.random() * 30
      const gr = ctx.createRadialGradient(x, y, 0, x, y, r)
      gr.addColorStop(0, 'rgba(255,255,255,0.55)')
      gr.addColorStop(1, 'rgba(255,255,255,0)')
      ctx.fillStyle = gr
      ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill()
    }
    const tex = new THREE.CanvasTexture(cnv)
    const mat = new THREE.MeshBasicMaterial({
      map: tex, transparent: true, depthWrite: false, fog: false, opacity: 0.8,
    })
    for (let i = 0; i < 9; i++) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(150 + Math.random() * 130, 70 + Math.random() * 50), mat)
      m.position.set((Math.random() - 0.5) * 1100, 130 + Math.random() * 60, (Math.random() - 0.5) * 1100)
      m.rotation.x = -Math.PI / 2
      m.userData.speed = 1.2 + Math.random() * 1.4
      g.add(m)
    }
    return g
  }

  update(dt: number, playerPos: THREE.Vector3) {
    this.time = (this.time + dt / DAY_LENGTH) % 1
    const a = (this.time - 0.25) * Math.PI * 2 // زاویه خورشید
    const sunEl = Math.sin(a) // -1..1
    this.dayFactor = clamp(sunEl * 2.2 + 0.35, 0, 1)
    this.nightFactor = clamp(-sunEl * 2.4 + 0.15, 0, 1)
    const dusk = clamp(1 - Math.abs(sunEl) * 3.4, 0, 1) * (sunEl > -0.15 ? 1 : 0.4)

    const sd = this.sunDir.set(Math.cos(a) * 0.55, Math.max(sunEl, -0.25), Math.sin(a) * 0.75).normalize()
    const u = this.mat.uniforms
    ;(u.uSunDir.value as THREE.Vector3).copy(sd)
    ;(u.uMoonDir.value as THREE.Vector3).copy(sd).multiplyScalar(-1).setY(Math.max(-sunEl, 0.08))
    u.uNight.value = this.nightFactor
    u.uTime.value = performance.now() / 1000

    const zen = new THREE.Color().copy(P.nightZen).lerp(P.dayZen, this.dayFactor).lerp(P.duskZen, dusk * 0.55)
    const hor = new THREE.Color().copy(P.nightHor).lerp(P.dayHor, this.dayFactor).lerp(P.duskHor, dusk * 0.8)
    ;(u.uZenith.value as THREE.Color).copy(zen)
    ;(u.uHorizon.value as THREE.Color).copy(hor)
    ;(u.uSunColor.value as THREE.Color).copy(P.sunDay).lerp(P.sunDusk, dusk)

    // نور خورشید/ماه — جای ثابت نسبت به بازیکن برای پایداری سایه
    const lightDir = sunEl > -0.12 ? sd : sd.clone().multiplyScalar(-1)
    this.sun.position.copy(playerPos).addScaledVector(lightDir, 130)
    this.sun.target.position.copy(playerPos)
    const dayI = this.dayFactor
    const nightI = this.nightFactor
    this.sun.intensity = dayI > 0.02 ? lerp(0.25, 2.85, dayI) : 0.5 // ماه
    this.sun.color.copy(P.sunDay).lerp(P.sunDusk, dusk)
    if (dayI <= 0.02) this.sun.color.set(0x8fa8d8)

    this.hemi.intensity = lerp(0.26, 0.72, dayI) + nightI * 0.06
    this.hemi.color.copy(zen).lerp(new THREE.Color(0xffffff), 0.35)
    this.hemi.groundColor.set(0x4a4438).lerp(new THREE.Color(0x1a2030), nightI)
    this.amb.intensity = lerp(0.34, 0.18, dayI)

    // آسمان همراه بازیکن حرکت می‌کند
    this.mesh.position.set(playerPos.x, 0, playerPos.z)
    this.clouds.position.set(playerPos.x, 0, playerPos.z)
    for (const c of this.clouds.children) {
      c.position.x += (c.userData.speed as number) * dt
      if (c.position.x > 620) c.position.x = -620
    }
    const cloudMat = (this.clouds.children[0] as THREE.Mesh).material as THREE.MeshBasicMaterial
    cloudMat.opacity = lerp(0.06, 0.75, dayI)
  }
}
