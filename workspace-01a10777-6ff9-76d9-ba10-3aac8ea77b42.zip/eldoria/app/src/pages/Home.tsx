import { useEffect, useRef, useState } from 'react'
import { Game, touch } from '../game/game'
import { pad } from '../game/gamepad'
import { useGame } from '../game/state'
import TitleScreen from '../ui/TitleScreen'
import HUD from '../ui/HUD'
import { ErrorScreen, explainError } from '../ui/ErrorScreen'
import type { ClassId } from '../game/data'

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const dmgRef = useRef<HTMLDivElement>(null)
  const [game, setGame] = useState<Game | null>(null)
  const [fatal, setFatal] = useState<{ title: string; hint: string; detail: string } | null>(null)
  const phase = useGame((s) => s.phase)

  useEffect(() => {
    if (!canvasRef.current || !dmgRef.current) return
    let g: Game
    try {
      g = new Game(canvasRef.current, dmgRef.current)
    } catch (err) {
      // اگر ساخت بازی شکست بخورد (مثلاً WebGL در دسترس نباشد) باید پیام ببینیم،
      // نه صفحه‌ی سفید.
      setFatal(explainError(err))
      return
    }
    setGame(g)
    // قلاب‌های دیباگ مخصوص حالت توسعه — برای بازرسی از کنسول مرورگر و آزمون خودکار
    if (import.meta.env.DEV) {
      const w = window as unknown as Record<string, unknown>
      w.__eldoria = g
      w.__eldoriaTouch = touch
      w.__eldoriaPad = pad
      w.__eldoriaStore = useGame
    }
    let raf = 0
    let failed = false
    const loop = () => {
      if (failed) return
      try {
        g.loop()
      } catch (err) {
        // یک فریم خراب نباید کل بازی را با صفحه‌ی سفید از پا در بیاورد
        failed = true
        setFatal(explainError(err))
        return
      }
      raf = requestAnimationFrame(loop)
    }
    raf = requestAnimationFrame(loop)
    const onHide = () => { try { g.save() } catch { /* ذخیره‌ی ناموفق بی‌خطر است */ } }
    window.addEventListener('beforeunload', onHide)
    document.addEventListener('visibilitychange', onHide)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('beforeunload', onHide)
      document.removeEventListener('visibilitychange', onHide)
      g.dispose()
    }
  }, [])

  const start = (cls: ClassId, fromSave: boolean) => {
    try {
      game?.start(cls, fromSave)
    } catch (err) {
      setFatal(explainError(err))
    }
  }

  if (fatal) return <ErrorScreen title={fatal.title} hint={fatal.hint} detail={fatal.detail} />

  return (
    <div className="fixed inset-0 overflow-hidden" style={{ background: '#0d0b08' }}>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ touchAction: 'none' }} />
      <div className="vignette" />
      <div ref={dmgRef} className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 30 }} />
      {game && phase !== 'title' && <HUD game={game} />}
      {game && phase === 'title' && <TitleScreen onStart={start} />}
    </div>
  )
}
