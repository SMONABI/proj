import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// ⚠️ HashRouter و نه BrowserRouter:
// BrowserRouter به مسیر واقعی URL وابسته است و در دو حالت رایج صفحه‌ی سفید
// می‌دهد چون هیچ راوتی مطابقت نمی‌کند: (۱) باز کردن فایل با دابل‌کلیک روی
// file:// (۲) میزبانی روی زیرمسیر یا هاست استاتیک بدون تنظیم SPA fallback.
// HashRouter از بخش # استفاده می‌کند و همه‌جا بی‌تنظیم کار می‌کند.
import { HashRouter } from 'react-router'
import './index.css'
import App from './App.tsx'
import { ErrorBoundary, ErrorScreen, explainError } from './ui/ErrorScreen'

const root = document.getElementById('root')!

// ═══ شبکه‌ی ایمنی ═══
// خطاهای بیرون از درخت React (مثلاً داخل حلقه‌ی بازی که با requestAnimationFrame
// اجرا می‌شود) را می‌گیرد و به‌جای صفحه‌ی سفید، پیام قابل‌فهم نشان می‌دهد.
function showFatal(err: unknown) {
  const e = explainError(err)
  console.error('[الدوریا] خطای مهلک:', err)
  try {
    root.innerHTML = ''
    createRoot(root).render(
      <StrictMode>
        <ErrorScreen title={e.title} hint={e.hint} detail={e.detail} />
      </StrictMode>,
    )
  } catch {
    // اگر حتی همین هم شکست خورد، آخرین خط دفاعی: HTML خام
    root.innerHTML = `<div dir="rtl" style="font:16px Tahoma,sans-serif;color:#e8b64a;background:#0d0b08;padding:40px;height:100vh">
      <h2>خطای مهلک در بازی</h2><p style="color:#c9bfa6">${e.title}</p>
      <pre dir="ltr" style="font-size:11px;color:#d8a0a0;white-space:pre-wrap">${e.detail}</pre></div>`
  }
}

window.addEventListener('error', (ev) => showFatal(ev.error ?? ev.message))
window.addEventListener('unhandledrejection', (ev) => showFatal(ev.reason))

createRoot(root).render(
  <StrictMode>
    <ErrorBoundary>
      <HashRouter>
        <App />
      </HashRouter>
    </ErrorBoundary>
  </StrictMode>,
)
