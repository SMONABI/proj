// ═══ پنل گفت‌وگو با NPC ═══
import { useGame } from '../game/state'
import { faNum } from '../game/noise'
import type { Game } from '../game/game'

export default function Dialog({ game }: { game: Game }) {
  const d = useGame((s) => s.dialog)!
  return (
    <div className="absolute inset-x-0 bottom-0 z-40 flex justify-center pointer-events-auto p-3 md:p-6"
      style={{ background: 'linear-gradient(0deg, rgba(10,8,5,0.85), transparent)' }}>
      <div className="parchment-panel rounded-2xl w-full max-w-xl p-4 md:p-5" style={{ animation: 'rise-fade 0.35s ease' }}>
        <div className="flex items-center gap-3 mb-3">
          <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl font-black"
            style={{ background: 'linear-gradient(160deg, rgba(232,182,74,0.3), rgba(0,0,0,0.4))', border: '1px solid rgba(232,182,74,0.45)', color: 'var(--gold)' }}>
            {d.npcName[0]}
          </div>
          <div>
            <div className="font-black text-base md:text-lg engraved-cream">{d.npcName}</div>
            <div className="text-[11px]" style={{ color: 'var(--parchment-dim)' }}>{d.npcRole}</div>
          </div>
          {d.quest && (
            <div className="mr-auto text-left">
              <div className="text-[10px]" style={{ color: 'var(--parchment-dim)' }}>ماموریت</div>
              <div className="text-[12px] font-bold" style={{ color: 'var(--gold)' }}>{d.quest.def.name}</div>
            </div>
          )}
        </div>
        <p className="text-[13px] md:text-sm leading-7" style={{ color: 'var(--parchment)' }}>{d.text}</p>
        {d.quest && d.quest.status === 'active' && (
          <div className="mt-2 text-[12px]" style={{ color: 'var(--parchment-dim)' }}>
            پیشرفت: {faNum(d.quest.count)} از {faNum(d.quest.def.count)} {d.quest.def.targetName}
          </div>
        )}
        <div className="flex flex-wrap gap-2 mt-4">
          {d.canAccept && (
            <button onClick={() => game.acceptQuest()} className="gold-btn rounded-lg px-5 py-2.5 text-sm font-black">
              پذیرفتن ماموریت
            </button>
          )}
          {d.canComplete && (
            <button onClick={() => game.completeQuest()} className="gold-btn rounded-lg px-5 py-2.5 text-sm font-black">
              تحویل ماموریت (+{faNum(d.quest!.def.gold)} طلا)
            </button>
          )}
          <button onClick={() => game.closeDialog()} className="ghost-btn rounded-lg px-5 py-2.5 text-sm font-bold">
            خداحافظ
          </button>
        </div>
      </div>
    </div>
  )
}
