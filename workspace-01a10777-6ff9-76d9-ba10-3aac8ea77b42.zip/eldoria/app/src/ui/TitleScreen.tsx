// ═══ صفحه عنوان: انتخاب کلاس و شروع ═══
import { useEffect, useState } from 'react'
import { CLASSES, TIPS, SAVE_KEY } from '../game/data'
import type { ClassId } from '../game/data'
import { useGame } from '../game/state'
import { faNum } from '../game/noise'
import { loadJson } from '../game/storage'
import { GLYPH } from '../game/gamepad'

function SwordIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" className="w-8 h-8">
      <path d="M4 20 L14.5 9.5" />
      <path d="M13 4 L20 11 L17 13.5 L10.5 7 Z" fill="currentColor" stroke="none" opacity="0.9" />
      <path d="M10.5 7 L13 4 L20 11 L17 13.5" />
      <path d="M7 14 L10 17" />
      <path d="M5.5 18.5 L3 21" />
    </svg>
  )
}
function StaffIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" className="w-8 h-8">
      <path d="M7 21 L14 7" />
      <circle cx="16" cy="5" r="2.6" />
      <path d="M16 1.2 v1.2 M16 7.6 v1.2 M12.2 5 h1.2 M18.6 5 h1.2" opacity="0.8" />
    </svg>
  )
}
function BowIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" className="w-8 h-8">
      <path d="M6 3 C14 7 14 17 6 21" />
      <path d="M6 3 L6 21" opacity="0.7" />
      <path d="M6 12 L18 12" />
      <path d="M15.5 9.5 L18 12 L15.5 14.5" />
    </svg>
  )
}

const CLASS_ICONS = { warrior: <SwordIcon />, mage: <StaffIcon />, ranger: <BowIcon /> }

export default function TitleScreen({ onStart }: { onStart: (cls: ClassId, fromSave: boolean) => void }) {
  // انتخاب کلاس در استور نگه داشته می‌شود تا حلقه‌ی بازی (و در نتیجه دسته‌بازی)
  // هم بتواند آن را تغییر دهد و بازی را شروع کند.
  const sel = useGame((s) => s.titleClass)
  const setSel = (c: ClassId) => useGame.getState().set({ titleClass: c })
  const [tipIdx, setTipIdx] = useState(0)
  const hasSave = useGame((s) => s.hasSave)
  // خواندن ایمن: در iframe سندباکس‌شده localStorage پرتاب می‌کند
  const savedClass = loadJson<{ classId?: ClassId }>(SAVE_KEY)?.classId

  useEffect(() => {
    const t = setInterval(() => setTipIdx((i) => (i + 1) % TIPS.length), 5200)
    return () => clearInterval(t)
  }, [])

  const c = CLASSES.find((x) => x.id === sel)!

  return (
    <div dir="rtl" className="fixed inset-0 z-40 flex flex-col items-center justify-between overflow-y-auto scroll-thin"
      style={{ background: 'radial-gradient(90% 70% at 50% 30%, rgba(13,11,8,0.25), rgba(13,11,8,0.88) 100%)' }}>

      {/* سربرگ */}
      <div className="text-center pt-[7vh] px-4 select-none">
        <div className="text-[11px] md:text-xs tracking-[0.5em] mb-3" style={{ color: 'var(--parchment-dim)' }}>
          ELDORIA · نسخه سه‌بعدی سوم‌شخص
        </div>
        <h1 className="engraved font-black leading-none" style={{ fontSize: 'clamp(56px, 11vw, 120px)' }}>
          الدوریا
        </h1>
        <div className="mt-3 flex items-center justify-center gap-3 text-sm md:text-base" style={{ color: 'var(--parchment-dim)' }}>
          <span className="h-px w-10 md:w-16" style={{ background: 'linear-gradient(90deg, transparent, rgba(232,182,74,0.6))' }} />
          <span>سرنوشت خود را در تاریکی رقم بزن</span>
          <span className="h-px w-10 md:w-16" style={{ background: 'linear-gradient(270deg, transparent, rgba(232,182,74,0.6))' }} />
        </div>
      </div>

      {/* انتخاب کلاس */}
      <div className="w-full max-w-4xl px-4 mt-2">
        <div className="grid grid-cols-3 gap-2.5 md:gap-4">
          {CLASSES.map((cls) => (
            <button
              key={cls.id}
              onClick={() => setSel(cls.id)}
              className={`parchment-panel rounded-xl p-3 md:p-5 text-right transition-all duration-200 relative overflow-hidden ${
                sel === cls.id ? 'ring-2 scale-[1.02]' : 'opacity-80 hover:opacity-100'
              }`}
              style={sel === cls.id ? { ['--tw-ring-color' as string]: 'var(--gold)' } : {}}
            >
              <div className="flex items-center gap-2 md:gap-3" style={{ color: sel === cls.id ? 'var(--gold)' : 'var(--parchment-dim)' }}>
                {CLASS_ICONS[cls.id]}
                <div>
                  <div className="font-extrabold text-base md:text-xl engraved-cream">{cls.name}</div>
                  <div className="text-[10px] md:text-xs" style={{ color: 'var(--parchment-dim)' }}>{cls.title}</div>
                </div>
              </div>
              <p className="hidden md:block mt-3 text-[13px] leading-6" style={{ color: 'var(--parchment-dim)' }}>{cls.desc}</p>
              <div className="mt-2 md:mt-3 space-y-1">
                <Stat label="جان" v={cls.hp} max={130} color="#c8452c" />
                <Stat label="مانا" v={cls.mana} max={110} color="#4aa3e8" />
                <Stat label="قدرت" v={cls.atk} max={17} color="#e8b64a" />
              </div>
            </button>
          ))}
        </div>

        {/* مهارت‌های کلاس منتخب */}
        <div className="parchment-panel rounded-xl mt-3 md:mt-4 p-3 md:p-4">
          <div className="text-xs mb-2 font-bold" style={{ color: 'var(--gold)' }}>مهارت‌های {c.name}</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {c.skills.map((s, i) => (
              <div key={s.id} className="rounded-lg p-2" style={{ background: 'rgba(244,236,216,0.05)', border: '1px solid rgba(244,236,216,0.08)' }}>
                <div className="flex items-center gap-1.5 text-[13px] font-bold">
                  <span className="text-[10px] w-4 h-4 rounded-sm flex items-center justify-center" style={{ background: 'rgba(232,182,74,0.2)', color: 'var(--gold)' }}>{faNum(i + 1)}</span>
                  {s.name}
                </div>
                <div className="text-[11px] mt-1 leading-5" style={{ color: 'var(--parchment-dim)' }}>{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* دکمه‌ها و نکته */}
      <div className="w-full max-w-4xl px-4 pb-[4vh] mt-3">
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button onClick={() => onStart(sel, false)} className="gold-btn rounded-xl px-10 md:px-14 py-3.5 md:py-4 text-lg md:text-xl font-black">
            آغاز ماجراجویی
          </button>
          {hasSave && savedClass && (
            <button onClick={() => onStart(savedClass, true)} className="ghost-btn rounded-xl px-6 md:px-8 py-3.5 md:py-4 text-base md:text-lg font-bold">
              ادامه سفر قبلی
            </button>
          )}
        </div>
        <div className="text-center mt-4 text-[12px] md:text-sm h-6 transition-opacity" style={{ color: 'var(--parchment-dim)' }} key={tipIdx}>
          نکته: {TIPS[tipIdx]}
        </div>
        <ControlsHint />
      </div>
    </div>
  )
}

function Stat({ label, v, max, color }: { label: string; v: number; max: number; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] w-7" style={{ color: 'var(--parchment-dim)' }}>{label}</span>
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(0,0,0,0.5)' }}>
        <div className="h-full rounded-full" style={{ width: `${(v / max) * 100}%`, background: color }} />
      </div>
    </div>
  )
}

/** راهنمای کنترل‌ها در پایین صفحه‌ی عنوان — با دسته عوض می‌شود */
function ControlsHint() {
  const padConnected = useGame((s) => s.padConnected)
  const padKind = useGame((s) => s.padKind)
  const hasSave = useGame((s) => s.hasSave)
  const g = GLYPH[padKind]
  return (
    <div className="text-center mt-2 space-y-1">
      <div className="text-[10px] md:text-xs opacity-60">
        حرکت: WASD · حمله: کلیک · مهارت: ۱ تا ۴ · پرش: Space · دویدن: Shift · معجون: H
      </div>
      {padConnected && (
        <div className="text-[10px] md:text-xs" style={{ color: 'var(--gold)' }}>
          🎮 {g.a} شروع{hasSave ? ` · ${g.y} ادامه سفر قبلی` : ''} · {g.dleft}{g.dright} تغییر کلاس · استیک راست: دوربین
        </div>
      )}
    </div>
  )
}
