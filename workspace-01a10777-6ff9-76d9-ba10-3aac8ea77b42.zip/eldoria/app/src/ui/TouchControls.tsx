// ═══ کنترل‌های لمسی موبایل: جوی‌استیک + دکمه‌ها ═══
import { useRef, useState } from 'react'
import { touch } from '../game/game'
import { useGame } from '../game/state'
import { CLASSES } from '../game/data'
import { faNum } from '../game/noise'
import type { Game } from '../game/game'
import { Slot } from './HUD'

export default function TouchControls({ game }: { game: Game }) {
  return (
    <>
      <Joystick />
      <ActionButtons game={game} />
    </>
  )
}

function Joystick() {
  const zoneRef = useRef<HTMLDivElement>(null)
  const knobRef = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(false)
  const pid = useRef<number | null>(null)
  const origin = useRef({ x: 0, y: 0 })
  const R = 52

  const setKnob = (dx: number, dy: number) => {
    if (knobRef.current) knobRef.current.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`
  }

  const onDown = (e: React.PointerEvent) => {
    if (pid.current !== null) return
    pid.current = e.pointerId
    const rect = zoneRef.current!.getBoundingClientRect()
    origin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }
    setActive(true)
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
    onMove(e)
  }
  const onMove = (e: React.PointerEvent) => {
    if (pid.current !== e.pointerId) return
    let dx = e.clientX - origin.current.x
    let dy = e.clientY - origin.current.y
    const d = Math.hypot(dx, dy)
    if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R }
    setKnob(dx, dy)
    // در چیدمان RTL جوی‌استیک سمت چپ است؛ جهت مستقیم استفاده می‌شود
    touch.mx = dx / R
    touch.mz = dy / R
    touch.sprint = d > R * 0.92
  }
  const onUp = (e: React.PointerEvent) => {
    if (pid.current !== e.pointerId) return
    pid.current = null
    setActive(false)
    setKnob(0, 0)
    touch.mx = 0
    touch.mz = 0
    touch.sprint = false
  }

  return (
    <div ref={zoneRef}
      className="absolute left-4 bottom-24 w-36 h-36 rounded-full pointer-events-auto"
      style={{
        background: 'radial-gradient(circle, rgba(244,236,216,0.07), rgba(244,236,216,0.03))',
        border: `2px solid rgba(244,236,216,${active ? 0.35 : 0.18})`,
        touchAction: 'none',
      }}
      onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
      <div ref={knobRef} className="absolute left-1/2 top-1/2 w-14 h-14 rounded-full"
        style={{
          transform: 'translate(-50%, -50%)',
          background: 'linear-gradient(160deg, rgba(232,182,74,0.5), rgba(120,90,30,0.55))',
          border: '2px solid rgba(232,182,74,0.6)',
          boxShadow: '0 4px 14px rgba(0,0,0,0.5)',
        }} />
    </div>
  )
}

function ActionButtons({ game }: { game: Game }) {
  // سلکتورهای جدا تا این بخش با هر تغییرِ استور دوباره رندر نشود
  const classId = useGame((s) => s.classId)
  const cooldowns = useGame((s) => s.cooldowns)
  const mana = useGame((s) => s.mana)
  const potions = useGame((s) => s.potions)
  const interactHint = useGame((s) => s.interactHint)
  const cls = CLASSES.find((c) => c.id === classId)
  if (!cls) return null
  return (
    <div className="absolute right-3 bottom-20 flex flex-col items-center gap-2 pointer-events-auto">
      <div className="flex gap-2">
        <Slot label="پرش" onClick={() => { gamePress('jump') }} cd={0} maxCd={1} icon="⤴" />
        <Slot label="معجون" onClick={() => game.drinkPotion()} cd={0} maxCd={1} icon="🧪" badge={potions} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        {cls.skills.map((s, i) => (
          <Slot key={s.id} label={faNum(i + 1)} title={s.name}
            onClick={() => game.castSkill(i)} cd={cooldowns[i]} maxCd={s.cd} icon={s.icon}
            disabled={mana < s.mana} />
        ))}
      </div>
      <Slot label="حمله" big onClick={() => game.attack()} cd={0} maxCd={1} icon="⚔" />
      {interactHint && (
        <button onClick={() => game.tryInteract()}
          className="gold-btn rounded-xl px-5 py-3 text-sm font-black min-w-[88px] min-h-[48px]">
          گفت‌وگو
        </button>
      )}
    </div>
  )
}

// تزریق فشردن پرش به حلقه بازی
function gamePress(key: string) {
  window.dispatchEvent(new KeyboardEvent('keydown', { key: key === 'jump' ? ' ' : key }))
  setTimeout(() => window.dispatchEvent(new KeyboardEvent('keyup', { key: key === 'jump' ? ' ' : key })), 120)
}
