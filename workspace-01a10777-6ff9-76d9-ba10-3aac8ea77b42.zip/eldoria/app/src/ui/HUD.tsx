// ═══ HUD اصلی بازی ═══
// ⚡ نکته‌ی کارایی: هر بخش فقط به همان تکه از استور سابسکرایب می‌شود که لازم دارد.
// پیش‌تر کل HUD با useGame() به تمام استور وصل بود و چون مانا هر فریم بازیابی
// می‌شد، کل درخت ۶۰ بار در ثانیه دوباره رندر می‌شد.
import { useEffect, useRef, useState } from 'react'
import { useGame } from '../game/state'
import { CLASSES, BIOMES } from '../game/data'
import { faNum } from '../game/noise'
import type { Game } from '../game/game'
import { GLYPH } from '../game/gamepad'
import TouchControls from './TouchControls'
import Dialog from './Dialog'

export default function HUD({ game }: { game: Game }) {
  const phase = useGame((s) => s.phase)
  const hasDialog = useGame((s) => !!s.dialog)
  const showHelp = useGame((s) => s.showHelp)
  const hurtTick = useGame((s) => s.hurtTick)
  const lowHp = useGame((s) => s.lowHp)
  const interactHint = useGame((s) => s.interactHint)
  const set = useGame((s) => s.set)
  const isTouch = 'ontouchstart' in window

  return (
    <div dir="rtl" className="fixed inset-0 z-20 pointer-events-none select-none">
      <PlayerPanel />

      {/* دکمه‌های سیستمی */}
      <div className="absolute top-3 left-3 md:top-4 md:left-4 flex gap-2 pointer-events-auto">
        <MuteBtn game={game} />
        <SysBtn onClick={() => set({ showHelp: !showHelp })} title="راهنما">؟</SysBtn>
      </div>

      <Compass game={game} />
      <BossBar />
      <ZoneSplash />
      <QuestTracker />
      <LevelUpFlash />

      {/* راهنمای تعامل */}
      {interactHint && !hasDialog && <InteractHint text={interactHint} />}

      <SkillBar game={game} />
      <Toast />

      {/* لایه‌های آسیب */}
      {hurtTick > 0 && <div key={hurtTick} className="hurt-vignette" />}
      {lowHp && phase === 'playing' && <div className="lowhp-pulse" />}

      <DialogLayer game={game} />

      {showHelp && <HelpPanel onClose={() => set({ showHelp: false })} />}
      {phase === 'dead' && <DeathOverlay game={game} />}
      {isTouch && phase === 'playing' && !hasDialog && <TouchControls game={game} />}
    </div>
  )
}

/** قاب بازیکن — تنها بخشی که به جان/مانا/تجربه وابسته است */
function PlayerPanel() {
  const classId = useGame((s) => s.classId)
  const level = useGame((s) => s.level)
  const hp = useGame((s) => s.hp)
  const hpMax = useGame((s) => s.hpMax)
  const mana = useGame((s) => s.mana)
  const manaMax = useGame((s) => s.manaMax)
  const xp = useGame((s) => s.xp)
  const xpNext = useGame((s) => s.xpNext)
  const gold = useGame((s) => s.gold)
  const potions = useGame((s) => s.potions)
  const buffT = useGame((s) => s.buffT)
  const companionName = useGame((s) => s.companionName)

  const cls = CLASSES.find((c) => c.id === classId)
  if (!cls) return null

  return (
    <div className="absolute top-3 right-3 md:top-4 md:right-4 flex items-start gap-2.5">
      <div className="parchment-panel rounded-xl p-2.5 md:p-3 w-52 md:w-64">
        <div className="flex items-center gap-2 mb-1.5">
          <div className="w-8 h-8 md:w-9 md:h-9 rounded-lg flex items-center justify-center font-black text-lg"
            style={{ background: 'linear-gradient(160deg, rgba(232,182,74,0.25), rgba(0,0,0,0.4))', border: '1px solid rgba(232,182,74,0.4)', color: 'var(--gold)' }}>
            {faNum(level)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12px] md:text-sm font-extrabold engraved-cream truncate">{cls.name} الدوریا</div>
            <div className="text-[10px]" style={{ color: 'var(--parchment-dim)' }}>{companionName} همراه توست</div>
          </div>
        </div>
        <Bar ratio={hp / hpMax} color1="#e05a3a" color2="#8a2415" h="h-3.5" label={`${faNum(Math.ceil(hp))} / ${faNum(hpMax)}`} />
        <div className="mt-1" />
        <Bar ratio={mana / manaMax} color1="#5cb8f0" color2="#1c4a80" h="h-2.5" label={`${faNum(Math.ceil(mana))}`} />
        <div className="mt-1" />
        <Bar ratio={xp / xpNext} color1="#b8e85c" color2="#4a7a15" h="h-1.5" />
        <div className="flex items-center justify-between mt-1.5 text-[11px] md:text-xs">
          <span style={{ color: 'var(--gold)' }}>◈ {faNum(gold)} طلا</span>
          <span style={{ color: '#f08aa0' }}>🧪 {faNum(potions)}</span>
          {buffT > 0 && <span style={{ color: 'var(--xp)' }}>خشم {faNum(Math.ceil(buffT))}ث</span>}
        </div>
      </div>
    </div>
  )
}

function MuteBtn({ game }: { game: Game }) {
  const muted = useGame((s) => s.muted)
  return <SysBtn onClick={() => game.toggleMute()} title="صدا (M)">{muted ? '🔇' : '🔊'}</SysBtn>
}

/** راهنمای تعامل — دکمه‌ی درست را بسته به وسیله‌ی ورودی نشان می‌دهد */
function InteractHint({ text }: { text: string }) {
  const inputMode = useGame((s) => s.inputMode)
  const padKind = useGame((s) => s.padKind)
  const key = inputMode === 'pad' ? GLYPH[padKind].y : 'E'
  return (
    <div className="absolute bottom-[26vh] md:bottom-[24vh] left-1/2 -translate-x-1/2 parchment-panel rounded-lg px-4 py-2 text-sm pointer-events-auto">
      <span className="inline-block min-w-6 h-6 leading-6 px-1 text-center rounded-md ml-2 font-black"
        style={{ background: 'rgba(232,182,74,0.25)', color: 'var(--gold)', border: '1px solid rgba(232,182,74,0.5)' }}>{key}</span>
      {text}
    </div>
  )
}

function DialogLayer({ game }: { game: Game }) {
  const hasDialog = useGame((s) => !!s.dialog)
  if (!hasDialog) return null
  return <Dialog game={game} />
}

function BossBar() {
  const bossName = useGame((s) => s.bossName)
  const bossHp = useGame((s) => s.bossHp)
  const bossHpMax = useGame((s) => s.bossHpMax)
  if (!bossName) return null
  return (
    <div className="absolute top-14 md:top-16 left-1/2 -translate-x-1/2 w-[78vw] max-w-md">
      <div className="text-center text-[13px] md:text-sm font-black mb-1" style={{ color: '#ffb0a0', textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
        ☠ {bossName}
      </div>
      <div className="h-3 rounded-full overflow-hidden bar-sheen" style={{ background: 'rgba(10,6,4,0.75)', border: '1px solid rgba(200,69,44,0.5)' }}>
        <div className="h-full rounded-full transition-all duration-200" style={{ width: `${(bossHp / bossHpMax) * 100}%`, background: 'linear-gradient(90deg, #e05a3a, #8a2415)' }} />
      </div>
    </div>
  )
}

function ZoneSplash() {
  const zoneTick = useGame((s) => s.zoneTick)
  const zoneName = useGame((s) => s.zoneName)
  const zoneSub = useGame((s) => s.zoneSub)
  const zoneDanger = useGame((s) => s.zoneDanger)
  return (
    <div key={zoneTick} className="absolute top-[22vh] left-0 right-0 text-center pointer-events-none">
      {zoneTick > 0 && (
        <div className="zone-splash inline-block">
          <div className="text-3xl md:text-5xl font-black engraved-cream">{zoneName}</div>
          <div className={`text-xs md:text-sm mt-1 font-bold ${zoneDanger ? 'text-red-400' : 'text-emerald-300'}`}>
            {zoneDanger ? '⚔ ' : '🛡 '}{zoneSub}
          </div>
        </div>
      )}
    </div>
  )
}

function Bar({ ratio, color1, color2, h, label }: { ratio: number; color1: string; color2: string; h: string; label?: string }) {
  return (
    <div className={`relative ${h} rounded-full overflow-hidden bar-sheen`} style={{ background: 'rgba(8,6,4,0.8)', border: '1px solid rgba(0,0,0,0.6)' }}>
      <div className="h-full rounded-full transition-all duration-150" style={{ width: `${Math.max(0, Math.min(1, ratio)) * 100}%`, background: `linear-gradient(90deg, ${color1}, ${color2})` }} />
      {label && <span className="absolute inset-0 flex items-center justify-center text-[9px] md:text-[10px] font-bold" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.9)' }}>{label}</span>}
    </div>
  )
}

function SysBtn({ children, onClick, title }: { children: React.ReactNode; onClick: () => void; title: string }) {
  return (
    <button onClick={onClick} title={title}
      className="parchment-panel w-10 h-10 md:w-11 md:h-11 rounded-xl flex items-center justify-center text-base hover:brightness-125 transition-all">
      {children}
    </button>
  )
}

// قطب‌نما با به‌روزرسانی مستقیم DOM (بدون رندر مجدد)
function Compass({ game }: { game: Game }) {
  const stripRef = useRef<HTMLDivElement>(null)
  const markers = [
    { label: 'ش', ang: Math.PI },      // شمال = -Z
    { label: 'ج', ang: 0 },            // جنوب
    { label: 'ق', ang: -Math.PI / 2 }, // شرق = +X ... تنظیم با سیستم مختصات
    { label: 'غ', ang: Math.PI / 2 },
    ...BIOMES.filter((b) => b.id !== 'city').map((b) => ({
      label: b.name.split(' ')[0], ang: Math.atan2(b.center[0], b.center[1]), biome: true, color: b.danger ? '#e89a8a' : '#a8d8a0',
    })),
  ]

  useEffect(() => {
    let raf: number
    const tick = () => {
      raf = requestAnimationFrame(tick)
      const strip = stripRef.current
      if (!strip || !game.player) return
      const camYaw = game.player.camYaw
      const kids = strip.children
      for (let i = 0; i < kids.length && i < markers.length; i++) {
        const d = (markers[i].ang - camYaw + Math.PI * 3) % (Math.PI * 2) - Math.PI
        const el = kids[i] as HTMLElement
        if (Math.abs(d) > 1.35) { el.style.opacity = '0'; continue }
        const x = 50 + (d / 1.35) * 50
        el.style.opacity = '1'
        el.style.left = `${x}%`
      }
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game])

  return (
    <div className="absolute top-3 md:top-4 left-1/2 -translate-x-1/2 w-[46vw] max-w-xs h-7 rounded-full overflow-hidden parchment-panel">
      <div className="absolute inset-0" ref={stripRef}>
        {markers.map((m, i) => (
          <div key={i} className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 text-[10px] md:text-[11px] font-bold transition-opacity"
            style={{ color: (m as { color?: string }).color ?? 'var(--parchment-dim)', opacity: 0 }}>
            {m.label}
          </div>
        ))}
      </div>
      <div className="absolute top-0 bottom-0 left-1/2 w-px" style={{ background: 'var(--gold)' }} />
    </div>
  )
}

function QuestTracker() {
  const quests = useGame((s) => s.quests)
  const active = quests.filter((q) => q.status === 'active' || q.status === 'ready')
  if (!active.length) return null
  return (
    <div className="absolute top-[168px] md:top-[186px] right-3 md:right-4 w-52 md:w-64 space-y-2">
      {active.map((q) => (
        <div key={q.def.id} className="parchment-panel rounded-lg p-2.5 text-[11px] md:text-xs">
          <div className="flex items-center justify-between">
            <span className="font-extrabold" style={{ color: q.status === 'ready' ? 'var(--xp)' : 'var(--gold)' }}>{q.def.name}</span>
            {q.status === 'ready' && <span className="text-emerald-300">✓ آماده تحویل</span>}
          </div>
          <div className="mt-1" style={{ color: 'var(--parchment-dim)' }}>
            شکار {q.def.targetName}: {faNum(Math.min(q.count, q.def.count))} از {faNum(q.def.count)}
          </div>
          <div className="mt-1 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(0,0,0,0.5)' }}>
            <div className="h-full rounded-full" style={{ width: `${Math.min(1, q.count / q.def.count) * 100}%`, background: q.status === 'ready' ? 'var(--xp)' : 'var(--gold)' }} />
          </div>
        </div>
      ))}
    </div>
  )
}

function SkillBar({ game }: { game: Game }) {
  const classId = useGame((s) => s.classId)
  const cooldowns = useGame((s) => s.cooldowns)
  const mana = useGame((s) => s.mana)
  const potions = useGame((s) => s.potions)
  const inputMode = useGame((s) => s.inputMode)
  const padKind = useGame((s) => s.padKind)
  const isTouch = 'ontouchstart' in window
  const cls = CLASSES.find((c) => c.id === classId)
  if (isTouch || !cls) return null // در موبایل دکمه‌های لمسی جایگزین است

  // با دسته‌بازی، برچسب کلیدها به دکمه‌های دسته تبدیل می‌شود
  const g = GLYPH[padKind]
  const usePad = inputMode === 'pad'
  const skillLabels = usePad ? [g.lb, g.rb, g.lt, g.rt] : ['۱', '۲', '۳', '۴']

  return (
    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-end gap-2 pointer-events-auto">
      <Slot label={usePad ? g.x : 'کلیک'} big onClick={() => game.attack()} cd={0} maxCd={1} icon="⚔" />
      {cls.skills.map((s, i) => (
        <Slot key={s.id} label={skillLabels[i]} title={`${s.name} — ${s.desc} (مانا: ${faNum(s.mana)})`}
          onClick={() => game.castSkill(i)} cd={cooldowns[i]} maxCd={s.cd} icon={s.icon}
          disabled={mana < s.mana} />
      ))}
      <Slot label={usePad ? g.b : 'H'} title="معجون شفا" onClick={() => game.drinkPotion()} cd={0} maxCd={1} icon="🧪" badge={potions} />
    </div>
  )
}

export function Slot({ label, onClick, cd, maxCd, icon, title, disabled, big, badge }: {
  label: string; onClick: () => void; cd: number; maxCd: number; icon: string; title?: string; disabled?: boolean; big?: boolean; badge?: number
}) {
  const size = big ? 'w-14 h-14 md:w-16 md:h-16 text-2xl' : 'w-11 h-11 md:w-12 md:h-12 text-xl'
  return (
    <button onClick={onClick} title={title}
      className={`skill-key relative ${size} rounded-xl flex items-center justify-center transition-transform active:scale-90 ${disabled ? 'opacity-45 grayscale' : ''}`}
      style={{ background: 'linear-gradient(180deg, rgba(56,71,50,0.92), rgba(25,23,21,0.95))', border: '1px solid rgba(232,182,74,0.35)' }}>
      <span>{icon}</span>
      {cd > 0.05 && (
        <>
          <div className="cd-sweep" style={{ ['--cd' as string]: `${(cd / maxCd) * 100}%` }} />
          <span className="absolute inset-0 flex items-center justify-center text-sm font-black" style={{ textShadow: '0 1px 3px #000' }}>{faNum(Math.ceil(cd))}</span>
        </>
      )}
      {badge !== undefined && badge > 0 && (
        <span className="absolute -top-1.5 -left-1.5 text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center"
          style={{ background: 'var(--blood)', border: '1px solid rgba(255,255,255,0.3)' }}>{faNum(badge)}</span>
      )}
      <span className="absolute -bottom-1.5 text-[9px] px-1 rounded-sm font-bold"
        style={{ background: 'rgba(10,8,5,0.85)', color: 'var(--parchment-dim)', border: '1px solid rgba(244,236,216,0.15)' }}>{label}</span>
    </button>
  )
}

function Toast() {
  const toast = useGame((s) => s.toast)
  const set = useGame((s) => s.set)
  const [shown, setShown] = useState<string | null>(null)
  useEffect(() => {
    if (toast) {
      setShown(toast)
      const t = setTimeout(() => { setShown(null); set({ toast: null }) }, 2600)
      return () => clearTimeout(t)
    }
  }, [toast, set])
  if (!shown) return null
  return (
    <div className="absolute bottom-[13vh] left-1/2 -translate-x-1/2 parchment-panel rounded-lg px-5 py-2.5 text-sm font-bold"
      style={{ color: 'var(--gold)', animation: 'rise-fade 2.6s ease forwards' }}>
      {shown}
    </div>
  )
}

function LevelUpFlash() {
  const tick = useGame((s) => s.levelUpTick)
  const level = useGame((s) => s.level)
  if (tick === 0) return null
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div key={tick} className="text-center" style={{ animation: 'rise-fade 2.4s ease forwards' }}>
        <div className="text-4xl md:text-6xl font-black engraved">افزایش سطح!</div>
        <div className="text-xl md:text-2xl mt-2 engraved-cream">سطح {faNum(level)}</div>
      </div>
      <div key={`b${tick}`} className="absolute inset-0" style={{ background: 'radial-gradient(50% 40% at 50% 50%, rgba(232,182,74,0.35), transparent)', animation: 'levelup-burst 1.2s ease forwards' }} />
    </div>
  )
}

function HelpPanel({ onClose }: { onClose: () => void }) {
  const padConnected = useGame((s) => s.padConnected)
  const padKind = useGame((s) => s.padKind)
  const g = GLYPH[padKind]

  const kb: [string, string][] = [
    ['W A S D', 'حرکت'], ['کلیک چپ', 'حمله (کمبوی سه‌ضرب)'], ['۱ ۲ ۳ ۴', 'مهارت‌ها'],
    ['Space', 'پرش'], ['Shift', 'دویدن'], ['E', 'گفت‌وگو با اهالی'], ['H', 'نوشیدن معجون شفا'],
    ['درگ ماوس', 'چرخش دوربین'], ['اسکرول', 'بزرگ‌نمایی'], ['M', 'قطع/وصل صدا'],
  ]
  const gp: [string, string][] = [
    ['استیک چپ', 'حرکت (فشار کامل = دویدن)'], ['استیک راست', 'چرخش دوربین'],
    [g.a, 'پرش'], [g.x, 'حمله (نگه‌داشتن = حمله پیوسته)'],
    [g.y, 'گفت‌وگو با اهالی'], [g.b, 'نوشیدن معجون شفا'],
    [`${g.lb} ${g.rb} ${g.lt} ${g.rt}`, 'مهارت‌های ۱ تا ۴'],
    [g.dup + g.ddown + g.dleft + g.dright, 'حرکت / ناوبری منو'],
    [g.start, 'راهنما'], [g.back, 'قطع/وصل صدا'],
  ]

  const Row = ({ k, v }: { k: string; v: string }) => (
    <div className="flex items-center justify-between text-sm gap-2">
      <span className="px-2 py-0.5 rounded-md text-[12px] font-bold whitespace-nowrap" style={{ background: 'rgba(232,182,74,0.15)', border: '1px solid rgba(232,182,74,0.35)', color: 'var(--gold)' }}>{k}</span>
      <span className="text-left" style={{ color: 'var(--parchment-dim)' }}>{v}</span>
    </div>
  )

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center pointer-events-auto overflow-y-auto scroll-thin p-3" style={{ background: 'rgba(10,8,5,0.7)' }} onClick={onClose}>
      <div className="parchment-panel rounded-2xl p-5 max-w-lg w-full my-auto" onClick={(e) => e.stopPropagation()}>
        <div className="text-lg font-black engraved mb-4">راهنمای ماجراجو</div>

        <div className="grid md:grid-cols-2 gap-x-5 gap-y-4">
          <div>
            <div className="text-[12px] font-bold mb-2" style={{ color: 'var(--parchment-dim)' }}>⌨ کیبورد و ماوس</div>
            <div className="space-y-1.5">{kb.map(([k, v]) => <Row key={k} k={k} v={v} />)}</div>
          </div>
          <div>
            <div className="text-[12px] font-bold mb-2" style={{ color: 'var(--parchment-dim)' }}>
              🎮 دسته‌بازی {padConnected ? <span style={{ color: '#8fd48f' }}>— متصل</span> : <span style={{ opacity: 0.6 }}>— وصل نیست</span>}
            </div>
            <div className="space-y-1.5">{gp.map(([k, v]) => <Row key={k} k={k} v={v} />)}</div>
          </div>
        </div>

        {!padConnected && (
          <p className="mt-4 text-[12px] leading-6" style={{ color: 'var(--parchment-dim)' }}>
            برای بازی با دسته، آن را وصل کنید و یکی از دکمه‌هایش را بزنید تا مرورگر شناسایی‌اش کند.
          </p>
        )}
        <button onClick={onClose} className="gold-btn rounded-lg px-6 py-2 mt-5 w-full font-bold">بستن</button>
      </div>
    </div>
  )
}

function DeathOverlay({ game }: { game: Game }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center pointer-events-auto" style={{ background: 'radial-gradient(80% 70% at 50% 50%, rgba(60,10,5,0.55), rgba(8,4,3,0.9))' }}>
      <div className="text-center px-6">
        <div className="text-5xl md:text-7xl font-black" style={{ color: '#e05a3a', textShadow: '0 4px 0 rgba(0,0,0,0.6), 0 0 40px rgba(200,40,20,0.5)' }}>
          افتادی...
        </div>
        <p className="mt-4 text-sm md:text-base" style={{ color: 'var(--parchment-dim)' }}>
          اما روح الدوریا تو را رها نمی‌کند. در میدان شهر چشم باز خواهی کرد.
        </p>
        <button onClick={() => game.respawn()} className="gold-btn rounded-xl px-10 py-3.5 mt-6 text-lg font-black">
          بازگشت به میدان شهر
        </button>
      </div>
    </div>
  )
}
