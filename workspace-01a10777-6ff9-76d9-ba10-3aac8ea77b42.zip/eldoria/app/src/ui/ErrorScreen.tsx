// ═══ صفحه‌ی خطا: به‌جای «صفحه‌ی سفید» ═══
// اگر هر خطای غیرمنتظره‌ای رخ دهد، این صفحه با پیام فارسی و راهنمای رفع نمایش
// داده می‌شود. قبلاً هیچ خطاگیری‌ای وجود نداشت و هر استثنای زمان اجرا کل برنامه
// را unmount می‌کرد → صفحه‌ی کاملاً سفید و بدون هیچ سرنخی.
import { Component } from 'react'
import type { ErrorInfo, ReactNode } from 'react'

export function ErrorScreen({ title, detail, hint }: { title: string; detail?: string; hint?: string }) {
  return (
    <div dir="rtl" className="fixed inset-0 z-[999] flex items-center justify-center p-4"
      style={{ background: 'radial-gradient(90% 70% at 50% 30%, #17140f, #0a0806)' }}>
      <div className="max-w-lg w-full rounded-2xl p-6"
        style={{ background: 'rgba(244,236,216,0.06)', border: '1px solid rgba(232,182,74,0.35)' }}>
        <div className="text-2xl font-black mb-3" style={{ color: '#e8b64a' }}>⚠ {title}</div>
        {hint && <p className="text-sm leading-7 mb-3" style={{ color: '#c9bfa6' }}>{hint}</p>}
        {detail && (
          <pre dir="ltr" className="text-[11px] leading-5 p-3 rounded-lg overflow-auto max-h-40 mb-4"
            style={{ background: 'rgba(0,0,0,0.45)', color: '#d8a0a0', fontFamily: 'ui-monospace, monospace' }}>
            {detail}
          </pre>
        )}
        <div className="flex gap-2">
          <button onClick={() => location.reload()}
            className="rounded-lg px-5 py-2.5 font-bold text-sm"
            style={{ background: 'linear-gradient(180deg,#e8b64a,#b8862a)', color: '#241a08' }}>
            تلاش دوباره
          </button>
        </div>
      </div>
    </div>
  )
}

/** تشخیص خطای رایج WebGL و تبدیل آن به پیامی که کاربر بفهمد */
export function explainError(err: unknown): { title: string; hint: string; detail: string } {
  const msg = err instanceof Error ? err.message : String(err)
  const detail = err instanceof Error ? `${err.name}: ${err.message}\n\n${err.stack ?? ''}`.slice(0, 900) : msg

  if (/webgl|context|gpu/i.test(msg)) {
    return {
      title: 'مرورگر از گرافیک سه‌بعدی پشتیبانی نمی‌کند',
      hint: 'بازی برای رندر به WebGL نیاز دارد. لطفاً از مرورگر به‌روز (کروم، فایرفاکس یا اج) استفاده کنید و شتاب سخت‌افزاری را روشن بگذارید. اگر در محیط مجازی اجرا می‌کنید، ممکن است گرافیک شبیه‌سازی‌شده کافی نباشد.',
      detail,
    }
  }
  if (/localstorage|securityerror|sandbox/i.test(msg)) {
    return {
      title: 'دسترسی به حافظه‌ی مرورگر مسدود است',
      hint: 'این صفحه داخل یک iframe محدود اجرا می‌شود و اجازه‌ی ذخیره‌سازی ندارد. بازی باید بی‌ذخیره‌سازی هم اجرا شود — اگر این پیام را می‌بینید یعنی مشکل از جای دیگری است.',
      detail,
    }
  }
  if (/import|module|mime|failed to fetch|unexpected token/i.test(msg)) {
    return {
      title: 'فایل بازی درست بارگذاری نشد',
      hint: 'اگر فایل index.html را مستقیم با دوبار کلیک باز کرده‌اید، این طبیعی است: مرورگر نمی‌تواند فایل‌های TypeScript را اجرا کند. باید نسخه‌ی تک‌فایلی آماده (Eldoria-3D.html) را باز کنید یا سرور توسعه را اجرا کنید.',
      detail,
    }
  }
  return {
    title: 'خطای غیرمنتظره در بازی',
    hint: 'این خطا ثبت شد. با دکمه‌ی زیر دوباره تلاش کنید. اگر تکرار شد، متن خطای زیر را برایم بفرستید.',
    detail,
  }
}

interface Props { children: ReactNode }
interface State { error: unknown }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null }
  static getDerivedStateFromError(error: unknown): State { return { error } }
  componentDidCatch(error: unknown, info: ErrorInfo) {
    // برای دیباگ در کنسول مرورگر
    console.error('[الدوریا] خطای رابط کاربری:', error, info.componentStack)
  }
  render() {
    if (this.state.error) {
      const e = explainError(this.state.error)
      return <ErrorScreen title={e.title} hint={e.hint} detail={e.detail} />
    }
    return this.props.children
  }
}
