import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
import { inspectAttr } from 'kimi-plugin-inspect-react'

// https://vite.dev/config/
export default defineConfig({
  base: './',
  plugins: [inspectAttr(), react()],
  server: {
    host: true,
    port: 3000,
    strictPort: true,
    allowedHosts: true,
    cors: true,
    // ⚠️ عمداً hmr.clientPort تنظیم نشده. اگر روی ۴۴۳ قفلش کنیم، دسترسی مستقیم
    // به سرور محلی (http://localhost:3000) وب‌سوکت را به پورت اشتباه می‌فرستد و
    // یک خطای «WebSocket closed without opened» در کنسول ایجاد می‌کند.
    // پیش‌فرض Vite هم محلی و هم پشت پروکسی HTTPS درست کار می‌کند.
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
